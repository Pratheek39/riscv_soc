// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

void Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__u_mem_axi__DOT__req_pop_w = (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_arready_i) 
                                                   & (IData)(vlSelfRef.axi_i_arvalid_o)) 
                                                  | ((~ (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_9)) 
                                                     & (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_wready_i) 
                                                         | (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q)) 
                                                        & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_awready_i) 
                                                           | (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q)))));
    vlSelfRef.__VdfgRegularize_hebeb780c_0_12 = (1U 
                                                 & ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__bvalid_q)) 
                                                    | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_bready_i)));
    vlSelfRef.__PVT__u_axi_conv__DOT__write_active 
        = ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)) 
           & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i) 
              | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q)));
    vlSelfRef.__PVT__dcache_data_rd_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)
                                          ? vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read1_q
                                          : vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_rdata_i);
    vlSelfRef.__PVT__ext_out_ack_w = ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_rvalid_i) 
                                      | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_bvalid_i));
    vlSelfRef.axi_t_wready_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active) 
                                & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)) 
                                   & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_12)));
    vlSelfRef.axi_t_awready_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active) 
                                 & ((~ ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q) 
                                        | (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q))) 
                                    & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_12)));
    vlSelfRef.__PVT__conv_ram_wr_w = ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wstrb_i) 
                                      & (- (IData)(
                                                   ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i) 
                                                    & (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active)))));
    vlSelfRef.__PVT__conv_ram_rd_w = ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active)) 
                                      & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i) 
                                         | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)));
    vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i 
        = ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)) 
           & (IData)(vlSelfRef.__PVT__ext_out_ack_w));
    vlSelfRef.axi_t_arready_o = ((IData)(vlSelfRef.__PVT__conv_ram_rd_w) 
                                 & ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)) 
                                    & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)) 
                                       & ((~ (IData)(vlSelfRef.axi_t_rvalid_o)) 
                                          | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_rready_i)))));
}

void Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__icache_rd_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__active_q) 
                                    & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_busy_w)) 
                                       & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_accept_w)));
    vlSelfRef.__PVT__icache_pc_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_w)
                                     ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_pc_w
                                     : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__fetch_pc_q);
}

void Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    IData/*31:0*/ __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__Vfuncout;
    __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__addr;
    __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__addr = 0;
    IData/*31:0*/ __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__Vfuncout;
    __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__addr;
    __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__addr = 0;
    IData/*31:0*/ __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__Vfuncout;
    __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__addr;
    __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__addr = 0;
    CData/*0:0*/ __VdfgRegularize_hebeb780c_0_10;
    __VdfgRegularize_hebeb780c_0_10 = 0;
    CData/*0:0*/ __Vdly__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q;
    __Vdly__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q = 0;
    CData/*1:0*/ __Vdly__u_mem_axi__DOT__u_resp__DOT__count_q;
    __Vdly__u_mem_axi__DOT__u_resp__DOT__count_q = 0;
    CData/*0:0*/ __Vdly__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q;
    __Vdly__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q = 0;
    CData/*0:0*/ __Vdly__u_mem_axi__DOT__u_req__DOT__rd_ptr_q;
    __Vdly__u_mem_axi__DOT__u_req__DOT__rd_ptr_q = 0;
    CData/*1:0*/ __Vdly__u_mem_axi__DOT__u_req__DOT__count_q;
    __Vdly__u_mem_axi__DOT__u_req__DOT__count_q = 0;
    CData/*0:0*/ __Vdly__u_mem_axi__DOT__u_req__DOT__wr_ptr_q;
    __Vdly__u_mem_axi__DOT__u_req__DOT__wr_ptr_q = 0;
    CData/*7:0*/ __Vdly__u_axi_conv__DOT__req_len_q;
    __Vdly__u_axi_conv__DOT__req_len_q = 0;
    IData/*31:0*/ __Vdly__u_axi_conv__DOT__req_addr_q;
    __Vdly__u_axi_conv__DOT__req_addr_q = 0;
    CData/*0:0*/ __Vdly__u_axi_conv__DOT__req_wr_q;
    __Vdly__u_axi_conv__DOT__req_wr_q = 0;
    CData/*0:0*/ __Vdly__u_axi_conv__DOT__req_rd_q;
    __Vdly__u_axi_conv__DOT__req_rd_q = 0;
    SData/*10:0*/ __VdlyVal__u_mem_axi__DOT__u_resp__DOT__ram_q__v0;
    __VdlyVal__u_mem_axi__DOT__u_resp__DOT__ram_q__v0 = 0;
    CData/*0:0*/ __VdlyDim0__u_mem_axi__DOT__u_resp__DOT__ram_q__v0;
    __VdlyDim0__u_mem_axi__DOT__u_resp__DOT__ram_q__v0 = 0;
    CData/*0:0*/ __VdlySet__u_mem_axi__DOT__u_resp__DOT__ram_q__v0;
    __VdlySet__u_mem_axi__DOT__u_resp__DOT__ram_q__v0 = 0;
    VlWide<3>/*68:0*/ __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0;
    VL_ZERO_W(69, __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0);
    CData/*0:0*/ __VdlyDim0__u_mem_axi__DOT__u_req__DOT__ram_q__v0;
    __VdlyDim0__u_mem_axi__DOT__u_req__DOT__ram_q__v0 = 0;
    CData/*0:0*/ __VdlySet__u_mem_axi__DOT__u_req__DOT__ram_q__v0;
    __VdlySet__u_mem_axi__DOT__u_req__DOT__ram_q__v0 = 0;
    // Body
    __Vdly__u_mem_axi__DOT__u_req__DOT__rd_ptr_q = vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q;
    __Vdly__u_mem_axi__DOT__u_resp__DOT__count_q = vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q;
    __Vdly__u_mem_axi__DOT__u_req__DOT__count_q = vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q;
    __Vdly__u_axi_conv__DOT__req_len_q = vlSelfRef.__PVT__u_axi_conv__DOT__req_len_q;
    __Vdly__u_axi_conv__DOT__req_addr_q = vlSelfRef.__PVT__u_axi_conv__DOT__req_addr_q;
    __Vdly__u_axi_conv__DOT__req_wr_q = vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q;
    __Vdly__u_axi_conv__DOT__req_rd_q = vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q;
    __Vdly__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q = vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q;
    __Vdly__u_mem_axi__DOT__u_req__DOT__wr_ptr_q = vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q;
    __VdlySet__u_mem_axi__DOT__u_req__DOT__ram_q__v0 = 0U;
    __Vdly__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q = vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q;
    __VdlySet__u_mem_axi__DOT__u_resp__DOT__ram_q__v0 = 0U;
    if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_i) {
        __Vdly__u_mem_axi__DOT__u_req__DOT__rd_ptr_q = 0U;
        __Vdly__u_mem_axi__DOT__u_resp__DOT__count_q = 0U;
        __Vdly__u_mem_axi__DOT__u_req__DOT__count_q = 0U;
        __Vdly__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q = 0U;
        __Vdly__u_mem_axi__DOT__u_req__DOT__wr_ptr_q = 0U;
        __Vdly__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_data_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_last_q = 0U;
        vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q = 0U;
        vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__req_axburst_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__req_axlen_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__req_id_q = 0U;
        __Vdly__u_axi_conv__DOT__req_len_q = 0U;
        __Vdly__u_axi_conv__DOT__req_addr_q = 0U;
        __Vdly__u_axi_conv__DOT__req_wr_q = 0U;
        __Vdly__u_axi_conv__DOT__req_rd_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__bvalid_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__rvalid_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__rlast_q = 0U;
    } else {
        if (((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__req_pop_w) 
             & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))) {
            __Vdly__u_mem_axi__DOT__u_req__DOT__rd_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q)));
        }
        if ((((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__res_push_w) 
              & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q))) 
             & (~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i) 
                   & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)))))) {
            __Vdly__u_mem_axi__DOT__u_resp__DOT__count_q 
                = (3U & ((IData)(1U) + (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)));
        } else if (((~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__res_push_w) 
                        & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)))) 
                    & ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i) 
                       & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q))))) {
            __Vdly__u_mem_axi__DOT__u_resp__DOT__count_q 
                = (3U & ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q) 
                         - (IData)(1U)));
        }
        if ((((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__req_push_w) 
              & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q))) 
             & (~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__req_pop_w) 
                   & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))))) {
            __Vdly__u_mem_axi__DOT__u_req__DOT__count_q 
                = (3U & ((IData)(1U) + (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)));
        } else if (((~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__req_push_w) 
                        & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))) 
                    & ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__req_pop_w) 
                       & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q))))) {
            __Vdly__u_mem_axi__DOT__u_req__DOT__count_q 
                = (3U & ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q) 
                         - (IData)(1U)));
        }
        if (((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i) 
             & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)))) {
            __Vdly__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q)));
        }
        if (((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__req_push_w) 
             & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))) {
            __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0[0U] 
                = (IData)((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                            << 0x00000020U) | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
            __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0[1U] 
                = (IData)(((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                             << 0x00000020U) | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))) 
                           >> 0x00000020U));
            __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0[2U] 
                = (((IData)(vlSelfRef.__PVT__ext_out_rd_w) 
                    << 4U) | (IData)(vlSelfRef.__PVT__ext_out_wr_w));
            __VdlyDim0__u_mem_axi__DOT__u_req__DOT__ram_q__v0 
                = vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q;
            __VdlySet__u_mem_axi__DOT__u_req__DOT__ram_q__v0 = 1U;
            __Vdly__u_mem_axi__DOT__u_req__DOT__wr_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q)));
        }
        if (((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__res_push_w) 
             & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)))) {
            __VdlyVal__u_mem_axi__DOT__u_resp__DOT__ram_q__v0 
                = vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_req_tag_q;
            __VdlyDim0__u_mem_axi__DOT__u_resp__DOT__ram_q__v0 
                = vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q;
            __VdlySet__u_mem_axi__DOT__u_resp__DOT__ram_q__v0 = 1U;
            __Vdly__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q 
                = (1U & ((IData)(1U) + (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q)));
        }
        if (((IData)(vlSelfRef.axi_t_rvalid_o) & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_rready_i)))) {
            vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_data_q 
                = vlSelfRef.axi_t_rdata_o;
            vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_last_q 
                = vlSelfRef.axi_t_rlast_o;
        }
        if (((((IData)(vlSelfRef.axi_i_awvalid_o) & (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_awready_i)) 
              & (IData)(vlSelfRef.axi_i_wvalid_o)) 
             & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_wready_i)))) {
            vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q = 1U;
        } else if (((IData)(vlSelfRef.axi_i_wvalid_o) 
                    & (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_wready_i))) {
            vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q = 0U;
        }
        if (((((IData)(vlSelfRef.axi_i_wvalid_o) & (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_wready_i)) 
              & (IData)(vlSelfRef.axi_i_awvalid_o)) 
             & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_awready_i)))) {
            vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q = 1U;
        } else if (((IData)(vlSelfRef.axi_i_awvalid_o) 
                    & (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_awready_i))) {
            vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q = 0U;
        }
        vlSelfRef.__PVT__u_axi_conv__DOT__rvalid_q = 0U;
        vlSelfRef.__PVT__u_axi_conv__DOT__rlast_q = 0U;
        if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_bready_i) {
            vlSelfRef.__PVT__u_axi_conv__DOT__bvalid_q = 0U;
        }
        if (((((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q) 
               & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q))) 
              & (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_rready_i)) 
             | (((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q) 
                 & (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i)) 
                & (IData)(vlSelfRef.axi_t_wready_o)))) {
            vlSelfRef.__PVT__u_axi_conv__DOT__rvalid_q 
                = vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q;
            if ((0U == (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_len_q))) {
                vlSelfRef.__PVT__u_axi_conv__DOT__bvalid_q 
                    = vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q;
                vlSelfRef.__PVT__u_axi_conv__DOT__rlast_q 
                    = vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q;
                __Vdly__u_axi_conv__DOT__req_rd_q = 0U;
                __Vdly__u_axi_conv__DOT__req_wr_q = 0U;
            } else {
                __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__addr 
                    = vlSelfRef.__PVT__u_axi_conv__DOT__req_addr_q;
                __Vdly__u_axi_conv__DOT__req_len_q 
                    = (0x000000ffU & ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_len_q) 
                                      - (IData)(1U)));
                vlSelfRef.__PVT__u_axi_conv__DOT__calculate_addr_next__Vstatic__mask = 0U;
                __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__Vfuncout 
                    = ((IData)(4U) + __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__addr);
                __Vdly__u_axi_conv__DOT__req_addr_q 
                    = __Vfunc_u_axi_conv__DOT__calculate_addr_next__0__Vfuncout;
            }
        }
        if (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i) 
             & (IData)(vlSelfRef.axi_t_awready_o))) {
            vlSelfRef.__PVT__u_axi_conv__DOT__req_axburst_q 
                = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awburst_i;
            vlSelfRef.__PVT__u_axi_conv__DOT__req_axlen_q 
                = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awlen_i;
            vlSelfRef.__PVT__u_axi_conv__DOT__req_id_q 
                = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awid_i;
            if (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i) 
                 & (IData)(vlSelfRef.axi_t_wready_o))) {
                __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__addr 
                    = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i;
                vlSelfRef.__PVT__u_axi_conv__DOT__calculate_addr_next__Vstatic__mask = 0U;
                __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__Vfuncout 
                    = ((IData)(4U) + __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__addr);
                __Vdly__u_axi_conv__DOT__req_wr_q = 
                    (1U & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wlast_i)));
                __Vdly__u_axi_conv__DOT__req_len_q 
                    = (0x000000ffU & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awlen_i) 
                                      - (IData)(1U)));
                __Vdly__u_axi_conv__DOT__req_addr_q 
                    = __Vfunc_u_axi_conv__DOT__calculate_addr_next__1__Vfuncout;
                vlSelfRef.__PVT__u_axi_conv__DOT__bvalid_q 
                    = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wlast_i;
            } else {
                __Vdly__u_axi_conv__DOT__req_wr_q = 1U;
                __Vdly__u_axi_conv__DOT__req_len_q 
                    = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awlen_i;
                __Vdly__u_axi_conv__DOT__req_addr_q 
                    = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i;
            }
        } else if (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i) 
                    & (IData)(vlSelfRef.axi_t_arready_o))) {
            vlSelfRef.__PVT__u_axi_conv__DOT__req_axburst_q 
                = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arburst_i;
            vlSelfRef.__PVT__u_axi_conv__DOT__req_axlen_q 
                = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arlen_i;
            vlSelfRef.__PVT__u_axi_conv__DOT__req_id_q 
                = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arid_i;
            __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__addr 
                = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_araddr_i;
            vlSelfRef.__PVT__u_axi_conv__DOT__calculate_addr_next__Vstatic__mask = 0U;
            __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__Vfuncout 
                = ((IData)(4U) + __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__addr);
            __Vdly__u_axi_conv__DOT__req_rd_q = (0U 
                                                 != (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arlen_i));
            __Vdly__u_axi_conv__DOT__req_len_q = (0x000000ffU 
                                                  & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arlen_i) 
                                                     - (IData)(1U)));
            __Vdly__u_axi_conv__DOT__req_addr_q = __Vfunc_u_axi_conv__DOT__calculate_addr_next__2__Vfuncout;
            vlSelfRef.__PVT__u_axi_conv__DOT__rvalid_q = 1U;
            vlSelfRef.__PVT__u_axi_conv__DOT__rlast_q 
                = (0U == (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arlen_i));
        }
    }
    vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_valid_q 
        = ((1U & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_i))) 
           && ((IData)(vlSelfRef.axi_t_rvalid_o) & 
               (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_rready_i))));
    vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q 
        = __Vdly__u_mem_axi__DOT__u_req__DOT__rd_ptr_q;
    vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q 
        = __Vdly__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q;
    vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q 
        = __Vdly__u_mem_axi__DOT__u_req__DOT__wr_ptr_q;
    if (__VdlySet__u_mem_axi__DOT__u_req__DOT__ram_q__v0) {
        vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q[__VdlyDim0__u_mem_axi__DOT__u_req__DOT__ram_q__v0][0U] 
            = __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0[0U];
        vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q[__VdlyDim0__u_mem_axi__DOT__u_req__DOT__ram_q__v0][1U] 
            = __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0[1U];
        vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q[__VdlyDim0__u_mem_axi__DOT__u_req__DOT__ram_q__v0][2U] 
            = __VdlyVal__u_mem_axi__DOT__u_req__DOT__ram_q__v0[2U];
    }
    vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q 
        = __Vdly__u_mem_axi__DOT__u_req__DOT__count_q;
    vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q 
        = __Vdly__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q;
    vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q 
        = __Vdly__u_mem_axi__DOT__u_resp__DOT__count_q;
    if (__VdlySet__u_mem_axi__DOT__u_resp__DOT__ram_q__v0) {
        vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q[__VdlyDim0__u_mem_axi__DOT__u_resp__DOT__ram_q__v0] 
            = __VdlyVal__u_mem_axi__DOT__u_resp__DOT__ram_q__v0;
    }
    vlSelfRef.__PVT__u_axi_conv__DOT__req_len_q = __Vdly__u_axi_conv__DOT__req_len_q;
    vlSelfRef.__PVT__u_axi_conv__DOT__req_addr_q = __Vdly__u_axi_conv__DOT__req_addr_q;
    vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q = __Vdly__u_axi_conv__DOT__req_wr_q;
    vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q = __Vdly__u_axi_conv__DOT__req_rd_q;
    vlSelfRef.axi_i_awaddr_o = (0xfffffffcU & vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                                [vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][0U]);
    __VdfgRegularize_hebeb780c_0_10 = (1U & (vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                                             [vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][2U] 
                                             >> 4U));
    vlSelfRef.axi_t_rlast_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_valid_q)
                                ? (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_last_q)
                                : (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rlast_q));
    vlSelfRef.axi_t_rvalid_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rvalid_q) 
                                | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_valid_q));
    vlSelfRef.__VdfgRegularize_hebeb780c_0_12 = (1U 
                                                 & ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__bvalid_q)) 
                                                    | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_bready_i)));
    vlSelfRef.__PVT__u_axi_conv__DOT__write_active 
        = ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)) 
           & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i) 
              | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q)));
    vlSelfRef.axi_i_arvalid_o = ((IData)(__VdfgRegularize_hebeb780c_0_10) 
                                 & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)));
    vlSelfRef.__VdfgRegularize_hebeb780c_0_9 = ((IData)(__VdfgRegularize_hebeb780c_0_10) 
                                                | (0U 
                                                   == (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)));
    vlSelfRef.axi_i_wvalid_o = (1U & (~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q) 
                                         | (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_9))));
    vlSelfRef.axi_i_awvalid_o = (1U & (~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q) 
                                          | (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_9))));
    vlSelfRef.__PVT__u_mem_axi__DOT__req_pop_w = (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_arready_i) 
                                                   & (IData)(vlSelfRef.axi_i_arvalid_o)) 
                                                  | ((~ (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_9)) 
                                                     & (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_wready_i) 
                                                         | (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q)) 
                                                        & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_awready_i) 
                                                           | (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q)))));
}

void Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__conv_ram_wr_w = ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wstrb_i) 
                                      & (- (IData)(
                                                   ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i) 
                                                    & (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active)))));
    vlSelfRef.__PVT__conv_ram_rd_w = ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active)) 
                                      & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i) 
                                         | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)));
    vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i 
        = ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)) 
           & (IData)(vlSelfRef.__PVT__ext_out_ack_w));
    vlSelfRef.__PVT__dcache_resp_tag_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)
                                           ? (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_tag_q)
                                           : vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q
                                          [vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q]);
    vlSelfRef.axi_t_wready_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active) 
                                & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)) 
                                   & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_12)));
    vlSelfRef.axi_t_awready_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active) 
                                 & ((~ ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q) 
                                        | (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q))) 
                                    & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_12)));
    vlSelfRef.axi_t_arready_o = ((IData)(vlSelfRef.__PVT__conv_ram_rd_w) 
                                 & ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)) 
                                    & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)) 
                                       & ((~ (IData)(vlSelfRef.axi_t_rvalid_o)) 
                                          | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_rready_i)))));
}

void Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__2(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__2\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__ext_out_rd_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_rd_q) 
                                     & (0x80000000U 
                                        <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q));
    vlSelfRef.__PVT__ext_out_wr_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q) 
                                     & (- (IData)((0x80000000U 
                                                   <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
    vlSelfRef.__VdfgRegularize_hebeb780c_0_23 = ((0U 
                                                  != (IData)(vlSelfRef.__PVT__ext_out_wr_w)) 
                                                 | (IData)(vlSelfRef.__PVT__ext_out_rd_w));
}

void Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.axi_t_rdata_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_valid_q)
                                ? vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_data_q
                                : vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read1_q);
    vlSelfRef.__PVT__dcache_data_rd_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)
                                          ? vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read1_q
                                          : vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_rdata_i);
}

void Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__dcache_accept_w = ((0x80000000U 
                                         <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q)
                                         ? ((2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)) 
                                            & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))
                                         : (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q));
    vlSelfRef.__PVT__u_mem_axi__DOT__req_push_w = (
                                                   (2U 
                                                    != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)) 
                                                   & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_23));
    vlSelfRef.__PVT__u_mem_axi__DOT__res_push_w = (
                                                   (2U 
                                                    != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)) 
                                                   & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_23));
}

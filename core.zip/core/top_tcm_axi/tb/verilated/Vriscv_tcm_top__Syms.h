// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VRISCV_TCM_TOP__SYMS_H_
#define VERILATED_VRISCV_TCM_TOP__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vriscv_tcm_top.h"

// INCLUDE MODULE CLASSES
#include "Vriscv_tcm_top___024root.h"
#include "Vriscv_tcm_top_riscv_tcm_top.h"
#include "Vriscv_tcm_top_riscv_core.h"
#include "Vriscv_tcm_top_mem_tcm.h"
#include "Vriscv_tcm_top_riscv_exec.h"
#include "Vriscv_tcm_top_riscv_decode.h"
#include "Vriscv_tcm_top_ram_dp_64k.h"
#include "Vriscv_tcm_top_riscv_regfile.h"

// DPI TYPES for DPI Export callbacks (Internal use)

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) Vriscv_tcm_top__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vriscv_tcm_top* const __Vm_modelp;
    bool __Vm_activity = false;  ///< Used by trace routines to determine change occurred
    uint32_t __Vm_baseCode = 0;  ///< Used by trace routines when tracing multiple models
    VlDeleter __Vm_deleter;
    bool& __Vm_didInit;

    // MODULE INSTANCE STATE
    Vriscv_tcm_top___024root       TOP;
    Vriscv_tcm_top_riscv_tcm_top   TOP__riscv_tcm_top;
    Vriscv_tcm_top_riscv_core      TOP__riscv_tcm_top__u_core;
    Vriscv_tcm_top_riscv_decode    TOP__riscv_tcm_top__u_core__u_decode;
    Vriscv_tcm_top_riscv_regfile   TOP__riscv_tcm_top__u_core__u_decode__u_regfile;
    Vriscv_tcm_top_riscv_exec      TOP__riscv_tcm_top__u_core__u_exec;
    Vriscv_tcm_top_mem_tcm         TOP__riscv_tcm_top__u_mem_tcm;
    Vriscv_tcm_top_ram_dp_64k      TOP__riscv_tcm_top__u_mem_tcm__u_ram;

    // SCOPE NAMES
    VerilatedScope* __Vscopep_riscv_tcm_top__u_mem_tcm__u_ram;

    // CONSTRUCTORS
    Vriscv_tcm_top__Syms(VerilatedContext* contextp, const char* namep, Vriscv_tcm_top* modelp);
    ~Vriscv_tcm_top__Syms();

    // METHODS
    const char* name() const { return TOP.vlNamep; }
};

#endif  // guard

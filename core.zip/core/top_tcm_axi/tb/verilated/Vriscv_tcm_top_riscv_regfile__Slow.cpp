// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

void Vriscv_tcm_top_riscv_regfile___ctor_var_reset(Vriscv_tcm_top_riscv_regfile* vlSelf);

Vriscv_tcm_top_riscv_regfile::Vriscv_tcm_top_riscv_regfile() = default;
Vriscv_tcm_top_riscv_regfile::~Vriscv_tcm_top_riscv_regfile() = default;

void Vriscv_tcm_top_riscv_regfile::ctor(Vriscv_tcm_top__Syms* symsp, const char* namep) {
    vlSymsp = symsp;
    vlNamep = strdup(Verilated::catName(vlSymsp->name(), namep));
    // Reset structure values
    Vriscv_tcm_top_riscv_regfile___ctor_var_reset(this);
}

void Vriscv_tcm_top_riscv_regfile::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

void Vriscv_tcm_top_riscv_regfile::dtor() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}

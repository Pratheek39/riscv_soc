// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__u_lsu__DOT__wb_result_r = 0U;
    vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r = (0x0000001fU 
                                             & (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w));
    vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r = (3U & 
                                               ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                >> 5U));
    vlSelfRef.__PVT__u_lsu__DOT__load_byte_r = (1U 
                                                & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                   >> 7U));
    vlSelfRef.__PVT__u_lsu__DOT__load_half_r = (1U 
                                                & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                   >> 8U));
    vlSelfRef.__PVT__u_lsu__DOT__load_word_r = (1U 
                                                & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                   >> 9U));
    vlSelfRef.__PVT__u_lsu__DOT__load_signed_r = (1U 
                                                  & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                     >> 0x0aU));
    if ((((IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q) 
          | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_ack_w)) 
         & (((IData)(vlSelfRef.__PVT__u_lsu__DOT__load_byte_r) 
             | (IData)(vlSelfRef.__PVT__u_lsu__DOT__load_half_r)) 
            | (IData)(vlSelfRef.__PVT__u_lsu__DOT__load_word_r)))) {
        if (vlSelfRef.__PVT__u_lsu__DOT__load_byte_r) {
            vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                = ((2U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                    ? ((1U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                        ? (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                           >> 0x18U) : (0x000000ffU 
                                        & (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                                           >> 0x10U)))
                    : ((1U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                        ? (0x000000ffU & (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                                          >> 8U)) : 
                       (0x000000ffU & vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w)));
            if (((IData)(vlSelfRef.__PVT__u_lsu__DOT__load_signed_r) 
                 & (vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    >> 7U))) {
                vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    = (0xffffff00U | (0x000000ffU & vlSelfRef.__PVT__u_lsu__DOT__wb_result_r));
            }
        } else if (vlSelfRef.__PVT__u_lsu__DOT__load_half_r) {
            vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                = ((2U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                    ? (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                       >> 0x10U) : (0x0000ffffU & vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w));
            if (((IData)(vlSelfRef.__PVT__u_lsu__DOT__load_signed_r) 
                 & (vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    >> 0x0fU))) {
                vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    = (0xffff0000U | (0x0000ffffU & vlSelfRef.__PVT__u_lsu__DOT__wb_result_r));
            }
        } else {
            vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                = vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w;
        }
    } else {
        vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r = 0U;
    }
    vlSelfRef.__PVT__opcode_rb_operand_w = ((((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q) 
                                              == (0x0000001fU 
                                                  & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                     >> 0x00000014U))) 
                                             & (0U 
                                                != (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q)))
                                             ? vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__result_q
                                             : (((0U 
                                                  != (IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r)) 
                                                 & ((IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r) 
                                                    == 
                                                    (0x0000001fU 
                                                     & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x00000014U))))
                                                 ? vlSelfRef.__PVT__u_lsu__DOT__wb_result_r
                                                 : vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__rb_value_w));
    vlSelfRef.__PVT__opcode_ra_operand_w = ((((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q) 
                                              == (0x0000001fU 
                                                  & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                     >> 0x0000000fU))) 
                                             & (0U 
                                                != (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q)))
                                             ? vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__result_q
                                             : (((0U 
                                                  != (IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r)) 
                                                 & ((IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r) 
                                                    == 
                                                    (0x0000001fU 
                                                     & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x0000000fU))))
                                                 ? vlSelfRef.__PVT__u_lsu__DOT__wb_result_r
                                                 : vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ra_value_w));
    vlSelfRef.__PVT__branch_pc_w = ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                   >> 0x00000015U)))
                                     ? (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q 
                                        + (((- (IData)(
                                                       (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x0000001fU))) 
                                            << 0x00000014U) 
                                           | ((((0x000001feU 
                                                 & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                    >> 0x0000000bU)) 
                                                | (1U 
                                                   & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                      >> 0x00000014U))) 
                                               << 0x0000000bU) 
                                              | (0x000007feU 
                                                 & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                    >> 0x00000014U)))))
                                     : ((1U & (IData)(
                                                      (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                       >> 0x00000016U)))
                                         ? (0xfffffffeU 
                                            & (vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r 
                                               + vlSelfRef.__PVT__opcode_ra_operand_w))
                                         : (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q 
                                            + (((- (IData)(
                                                           (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                            >> 0x0000001fU))) 
                                                << 0x0000000dU) 
                                               | ((((2U 
                                                     & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x0000001eU)) 
                                                    | (1U 
                                                       & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                          >> 7U))) 
                                                   << 0x0000000bU) 
                                                  | ((0x000007e0U 
                                                      & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                         >> 0x00000014U)) 
                                                     | (0x0000001eU 
                                                        & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                           >> 7U))))))));
}

void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VdfgRegularize_hebeb780c_0_18;
    __VdfgRegularize_hebeb780c_0_18 = 0;
    VlWide<3>/*95:0*/ __Vtemp_2;
    VlWide<3>/*95:0*/ __Vtemp_3;
    VlWide<3>/*95:0*/ __Vtemp_4;
    // Body
    vlSelfRef.__PVT__lsu_opcode_valid_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) 
                                           & ((~ (IData)(vlSelfRef.__PVT__csr_stall_w)) 
                                              & (~ (IData)(vlSelfRef.__PVT__muldiv_stall_w))));
    __VdfgRegularize_hebeb780c_0_18 = ((~ (IData)(vlSelfRef.__PVT__lsu_stall_w)) 
                                       & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r));
    __Vtemp_2[0U] = (IData)((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_22)) 
                              << 0x00000020U) | (QData)((IData)(vlSelfRef.__PVT__opcode_ra_operand_w))));
    __Vtemp_2[1U] = (((- (IData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_22))) 
                      << 1U) | (IData)(((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_22)) 
                                          << 0x00000020U) 
                                         | (QData)((IData)(vlSelfRef.__PVT__opcode_ra_operand_w))) 
                                        >> 0x00000020U)));
    __Vtemp_2[2U] = ((- (IData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_22))) 
                     >> 0x0000001fU);
    __Vtemp_3[0U] = (IData)((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_21)) 
                              << 0x00000020U) | (QData)((IData)(vlSelfRef.__PVT__opcode_rb_operand_w))));
    __Vtemp_3[1U] = (((- (IData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_21))) 
                      << 1U) | (IData)(((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_21)) 
                                          << 0x00000020U) 
                                         | (QData)((IData)(vlSelfRef.__PVT__opcode_rb_operand_w))) 
                                        >> 0x00000020U)));
    __Vtemp_3[2U] = ((- (IData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_21))) 
                     >> 0x0000001fU);
    VL_MUL_W(3, __Vtemp_4, __Vtemp_2, __Vtemp_3);
    vlSelfRef.__PVT__u_muldiv__DOT__mult_result_w[0U] 
        = __Vtemp_4[0U];
    vlSelfRef.__PVT__u_muldiv__DOT__mult_result_w[1U] 
        = __Vtemp_4[1U];
    vlSelfRef.__PVT__u_muldiv__DOT__mult_result_w[2U] 
        = (1U & __Vtemp_4[2U]);
    vlSelfRef.__PVT__fetch_accept_w = (1U & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__stall_input_w)) 
                                             | (IData)(vlSelfRef.__PVT__u_csr__DOT__branch_q)));
    vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r = 0U;
    vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r = (((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                                                & (IData)(
                                                          (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                           >> 0x29U)))
                                                ? vlSelfRef.__PVT__opcode_ra_operand_w
                                                : (
                                                   ((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                                                    & (0U 
                                                       != 
                                                       (0x0000003fU 
                                                        & (IData)(
                                                                  (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                   >> 0x0000001dU)))))
                                                    ? 
                                                   (vlSelfRef.__PVT__opcode_ra_operand_w 
                                                    + 
                                                    (((- (IData)(
                                                                 (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                                  >> 0x1fU))) 
                                                      << 0x0000000cU) 
                                                     | (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x14U)))
                                                    : 
                                                   (vlSelfRef.__PVT__opcode_ra_operand_w 
                                                    + 
                                                    (((- (IData)(
                                                                 (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                                  >> 0x1fU))) 
                                                      << 0x0000000cU) 
                                                     | ((0x00000fe0U 
                                                         & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                            >> 0x00000014U)) 
                                                        | (0x0000001fU 
                                                           & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                              >> 7U)))))));
    if (((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
         & (IData)((0ULL != (0x0000002480000000ULL 
                             & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q))))) {
        vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r 
            = (0U != (3U & vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r));
    } else if (((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                & (IData)((0ULL != (0x0000001240000000ULL 
                                    & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q))))) {
        vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r 
            = (1U & vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r);
    }
    vlSelfRef.__PVT__exec_opcode_valid_w = ((~ (IData)(vlSelfRef.__PVT__lsu_stall_w)) 
                                            & (IData)(vlSelfRef.__PVT__lsu_opcode_valid_w));
    vlSelfRef.__PVT__muldiv_opcode_valid_w = ((~ (IData)(vlSelfRef.__PVT__csr_stall_w)) 
                                              & (IData)(__VdfgRegularize_hebeb780c_0_18));
    vlSelfRef.__PVT__csr_opcode_valid_w = ((~ (IData)(vlSelfRef.__PVT__muldiv_stall_w)) 
                                           & (IData)(__VdfgRegularize_hebeb780c_0_18));
    vlSelfRef.__PVT__u_fetch__DOT__stall_w = (1U & 
                                              ((~ (IData)(vlSelfRef.__PVT__fetch_accept_w)) 
                                               | (IData)(vlSelfRef.__PVT__u_fetch__DOT__icache_busy_w)));
    vlSelfRef.__PVT__branch_request_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__branch_r) 
                                         & (IData)(vlSelfRef.__PVT__exec_opcode_valid_w));
    vlSelfRef.__PVT__u_muldiv__DOT__div_start_w = ((IData)(vlSelfRef.__PVT__muldiv_opcode_valid_w) 
                                                   & ((~ (IData)(vlSelfRef.__PVT__muldiv_stall_w)) 
                                                      & (0U 
                                                         != 
                                                         (0x0000000fU 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                     >> 0x00000033U))))));
    vlSelfRef.__PVT__u_csr__DOT__valid_unit_inst_w 
        = ((IData)(((0ULL != (0x00007f0000000000ULL 
                              & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)) 
                    | (0U != (3U & ((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                             >> 0x00000026U)) 
                                    | (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                               >> 0x00000037U))))))) 
           & (IData)(vlSelfRef.__PVT__csr_opcode_valid_w));
    vlSelfRef.__PVT__fetch_branch_w = ((IData)(vlSelfRef.__PVT__u_csr__DOT__branch_q) 
                                       | (IData)(vlSelfRef.__PVT__branch_request_w));
    vlSelfRef.__PVT__u_fetch__DOT__branch_pc_w = ((
                                                   (~ (IData)(vlSelfRef.__PVT__fetch_branch_w)) 
                                                   & (IData)(vlSelfRef.__PVT__u_fetch__DOT__branch_valid_q))
                                                   ? vlSelfRef.__PVT__u_fetch__DOT__branch_pc_q
                                                   : 
                                                  ((IData)(vlSelfRef.__PVT__u_csr__DOT__branch_q)
                                                    ? vlSelfRef.__PVT__u_csr__DOT__branch_target_q
                                                    : vlSelfRef.__PVT__branch_pc_w));
    vlSelfRef.__PVT__u_fetch__DOT__branch_w = ((IData)(vlSelfRef.__PVT__u_fetch__DOT__branch_valid_q) 
                                               | (IData)(vlSelfRef.__PVT__fetch_branch_w));
    vlSelfRef.__PVT__fetch_valid_w = ((~ (IData)(vlSelfRef.__PVT__u_fetch__DOT__branch_w)) 
                                      & ((IData)(vlSelfRef.__PVT__u_fetch__DOT__skid_valid_q) 
                                         | (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_i_valid_q)));
}

void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__2(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__2\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_hebeb780c_0_17 = (((
                                                   ((((3U 
                                                       == (IData)(vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q)) 
                                                      & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_8)) 
                                                     << 5U) 
                                                    | (((1U 
                                                         == (IData)(vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q)) 
                                                        & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_8)) 
                                                       << 3U)) 
                                                   | ((((0U 
                                                         == (IData)(vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q)) 
                                                        & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_8)) 
                                                       << 2U) 
                                                      | (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_st_q))) 
                                                  << 6U) 
                                                 | ((((IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_ld_q) 
                                                      << 4U) 
                                                     | (((IData)(
                                                                 (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                  >> 0x00000027U)) 
                                                         & (IData)(vlSelfRef.__PVT__csr_opcode_valid_w)) 
                                                        << 3U)) 
                                                    | ((((IData)(
                                                                 (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                  >> 0x00000039U)) 
                                                         & (IData)(vlSelfRef.__PVT__csr_opcode_valid_w)) 
                                                        << 2U) 
                                                       | (((IData)(
                                                                   (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                    >> 0x00000037U)) 
                                                           & (IData)(vlSelfRef.__PVT__csr_opcode_valid_w)) 
                                                          << 1U))));
    vlSelfRef.__PVT__u_csr__DOT__take_exception_r = 0U;
    vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r = vlSelfRef.__PVT__u_csr__DOT__csr_mepc_q;
    vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = vlSelfRef.__PVT__u_csr__DOT__csr_sr_q;
    vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = vlSelfRef.__PVT__u_csr__DOT__csr_mcause_q;
    vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_r = vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q;
    vlSelfRef.__PVT__u_csr__DOT__csr_mip_r = vlSelfRef.__PVT__u_csr__DOT__csr_mip_q;
    vlSelfRef.__PVT__u_csr__DOT__csr_mie_r = vlSelfRef.__PVT__u_csr__DOT__csr_mie_q;
    vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_r = vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q;
    vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_r = vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_q;
    vlSelfRef.__PVT__u_csr__DOT__result_r = 0U;
    vlSelfRef.__PVT__u_csr__DOT__data_r = 0U;
    vlSelfRef.__PVT__u_csr__DOT__take_intr_r = (0U 
                                                != vlSelfRef.__PVT__u_csr__DOT__irq_masked_r);
    if ((IData)((0U != (0x00f6U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17))))) {
        vlSelfRef.__PVT__u_csr__DOT__take_exception_r = 1U;
    }
    if (vlSelfRef.__PVT__u_csr__DOT__take_exception_r) {
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = ((0xffffff7fU 
                                                  & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r) 
                                                 | (0x00000080U 
                                                    & (vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                                                       << 4U)));
        vlSelfRef.__PVT__u_csr__DOT__take_intr_r = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_r = 3U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r = (
                                                   (0U 
                                                    != 
                                                    (0x0050U 
                                                     & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17)))
                                                    ? vlSelfRef.__PVT__u_csr__DOT__pc_m_q
                                                    : 
                                                   ((IData)(vlSelfRef.__PVT__u_csr__DOT__branch_q)
                                                     ? vlSelfRef.__PVT__u_csr__DOT__branch_target_q
                                                     : 
                                                    ((IData)(vlSelfRef.__PVT__u_csr__DOT__valid_unit_inst_w)
                                                      ? vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q
                                                      : 
                                                     ((IData)(vlSelfRef.__PVT__branch_request_w)
                                                       ? vlSelfRef.__PVT__branch_pc_w
                                                       : 
                                                      ((IData)(vlSelfRef.__PVT__csr_opcode_valid_w)
                                                        ? 
                                                       ((IData)(4U) 
                                                        + vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q)
                                                        : vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q)))));
        if ((0x00000010U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17))) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 4U;
        } else if ((0x00000040U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17))) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 6U;
        } else if ((4U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17))) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 2U;
        } else if ((2U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17))) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 1U;
        } else if ((0x00000020U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17))) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 5U;
        } else if ((0x00000080U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17))) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 7U;
        }
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = ((0xffffe7ffU 
                                                  & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r) 
                                                 | ((IData)(vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q) 
                                                    << 0x0000000bU));
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = (0xfffffff7U 
                                                 & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r);
    } else if (vlSelfRef.__PVT__u_csr__DOT__take_intr_r) {
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = ((0xffffff7fU 
                                                  & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r) 
                                                 | (0x00000080U 
                                                    & (vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                                                       << 4U)));
        vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_r = 3U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r = ((IData)(vlSelfRef.__PVT__u_csr__DOT__branch_q)
                                                    ? vlSelfRef.__PVT__u_csr__DOT__branch_target_q
                                                    : 
                                                   ((IData)(vlSelfRef.__PVT__u_csr__DOT__valid_unit_inst_w)
                                                     ? vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q
                                                     : 
                                                    ((IData)(vlSelfRef.__PVT__branch_request_w)
                                                      ? vlSelfRef.__PVT__branch_pc_w
                                                      : 
                                                     ((IData)(vlSelfRef.__PVT__csr_opcode_valid_w)
                                                       ? 
                                                      ((IData)(4U) 
                                                       + vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q)
                                                       : vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q))));
        if ((2U & vlSelfRef.__PVT__u_csr__DOT__irq_masked_r)) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 0x80000001U;
        } else if ((8U & vlSelfRef.__PVT__u_csr__DOT__irq_masked_r)) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 0x80000003U;
        } else if ((0x00000020U & vlSelfRef.__PVT__u_csr__DOT__irq_masked_r)) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 0x80000005U;
        } else if ((0x00000080U & vlSelfRef.__PVT__u_csr__DOT__irq_masked_r)) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 0x80000007U;
        } else if ((0x00000200U & vlSelfRef.__PVT__u_csr__DOT__irq_masked_r)) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 0x80000009U;
        } else if ((0x00000800U & vlSelfRef.__PVT__u_csr__DOT__irq_masked_r)) {
            vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 0x8000000bU;
        }
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = ((0xffffe7ffU 
                                                  & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r) 
                                                 | ((IData)(vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q) 
                                                    << 0x0000000bU));
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = (0xfffffff7U 
                                                 & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r);
    } else if (((IData)(vlSelfRef.__PVT__csr_opcode_valid_w) 
                & ((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                   | (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r)))) {
        vlSelfRef.__PVT__u_csr__DOT__data_r = ((IData)(
                                                       (0ULL 
                                                        != 
                                                        (0x0000700000000000ULL 
                                                         & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)))
                                                ? (0x0000001fU 
                                                   & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                      >> 0x0000000fU))
                                                : vlSelfRef.__PVT__opcode_ra_operand_w);
        if (((((((((0x0340U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r)) 
                   | (0x0341U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) 
                  | (0x0305U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) 
                 | (0x0342U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) 
                | (0x0300U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) 
               | (0x0344U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) 
              | (0x0304U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) 
             | (0x0c00U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r)))) {
            if ((0x0340U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
                if (((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                     & (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_r 
                        = vlSelfRef.__PVT__u_csr__DOT__data_r;
                } else if (vlSelfRef.__PVT__u_csr__DOT__set_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_r 
                           | vlSelfRef.__PVT__u_csr__DOT__data_r);
                } else if (vlSelfRef.__PVT__u_csr__DOT__clr_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_r 
                           & (~ vlSelfRef.__PVT__u_csr__DOT__data_r));
                }
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_q;
            } else if ((0x0341U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
                if (((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                     & (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r 
                        = vlSelfRef.__PVT__u_csr__DOT__data_r;
                } else if (vlSelfRef.__PVT__u_csr__DOT__set_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r 
                           | vlSelfRef.__PVT__u_csr__DOT__data_r);
                } else if (vlSelfRef.__PVT__u_csr__DOT__clr_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r 
                           & (~ vlSelfRef.__PVT__u_csr__DOT__data_r));
                }
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = vlSelfRef.__PVT__u_csr__DOT__csr_mepc_q;
            } else if ((0x0305U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
                if (((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                     & (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_r 
                        = vlSelfRef.__PVT__u_csr__DOT__data_r;
                } else if (vlSelfRef.__PVT__u_csr__DOT__set_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_r 
                           | vlSelfRef.__PVT__u_csr__DOT__data_r);
                } else if (vlSelfRef.__PVT__u_csr__DOT__clr_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_r 
                           & (~ vlSelfRef.__PVT__u_csr__DOT__data_r));
                }
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q;
            } else if ((0x0342U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
                vlSelfRef.__PVT__u_csr__DOT__data_r 
                    = (0x8000000fU & vlSelfRef.__PVT__u_csr__DOT__data_r);
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = (0x8000000fU & vlSelfRef.__PVT__u_csr__DOT__csr_mcause_q);
                if (((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                     & (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r 
                        = vlSelfRef.__PVT__u_csr__DOT__data_r;
                } else if (vlSelfRef.__PVT__u_csr__DOT__set_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r 
                           | vlSelfRef.__PVT__u_csr__DOT__data_r);
                } else if (vlSelfRef.__PVT__u_csr__DOT__clr_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r 
                           & (~ vlSelfRef.__PVT__u_csr__DOT__data_r));
                }
            } else if ((0x0300U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
                if (((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                     & (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                        = vlSelfRef.__PVT__u_csr__DOT__data_r;
                } else if (vlSelfRef.__PVT__u_csr__DOT__set_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                           | vlSelfRef.__PVT__u_csr__DOT__data_r);
                } else if (vlSelfRef.__PVT__u_csr__DOT__clr_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                           & (~ vlSelfRef.__PVT__u_csr__DOT__data_r));
                }
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = vlSelfRef.__PVT__u_csr__DOT__csr_sr_q;
            } else if ((0x0344U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
                vlSelfRef.__PVT__u_csr__DOT__data_r 
                    = (0x00000aaaU & vlSelfRef.__PVT__u_csr__DOT__data_r);
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = (0x00000aaaU & vlSelfRef.__PVT__u_csr__DOT__csr_mip_r);
                if (((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                     & (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mip_r 
                        = vlSelfRef.__PVT__u_csr__DOT__data_r;
                } else if (vlSelfRef.__PVT__u_csr__DOT__set_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mip_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mip_r 
                           | vlSelfRef.__PVT__u_csr__DOT__data_r);
                } else if (vlSelfRef.__PVT__u_csr__DOT__clr_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mip_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mip_r 
                           & (~ vlSelfRef.__PVT__u_csr__DOT__data_r));
                }
            } else if ((0x0304U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
                vlSelfRef.__PVT__u_csr__DOT__data_r 
                    = (0x00000aaaU & vlSelfRef.__PVT__u_csr__DOT__data_r);
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = (0x00000aaaU & vlSelfRef.__PVT__u_csr__DOT__csr_mie_q);
                if (((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                     & (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mie_r 
                        = vlSelfRef.__PVT__u_csr__DOT__data_r;
                } else if (vlSelfRef.__PVT__u_csr__DOT__set_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mie_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mie_r 
                           | vlSelfRef.__PVT__u_csr__DOT__data_r);
                } else if (vlSelfRef.__PVT__u_csr__DOT__clr_r) {
                    vlSelfRef.__PVT__u_csr__DOT__csr_mie_r 
                        = (vlSelfRef.__PVT__u_csr__DOT__csr_mie_r 
                           & (~ vlSelfRef.__PVT__u_csr__DOT__data_r));
                }
            } else {
                vlSelfRef.__PVT__u_csr__DOT__result_r 
                    = vlSelfRef.__PVT__u_csr__DOT__csr_mcycle_q;
            }
        } else if ((0x0f14U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
            vlSelfRef.__PVT__u_csr__DOT__result_r = 0U;
        } else if ((0x0301U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r))) {
            vlSelfRef.__PVT__u_csr__DOT__result_r = 0x40001100U;
        }
    } else if (((IData)(vlSelfRef.__PVT__csr_opcode_valid_w) 
                & (IData)((0ULL != (0x000000c000000000ULL 
                                    & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q))))) {
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = ((0xffffff7fU 
                                                  & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r) 
                                                 | (0x00000080U 
                                                    & (vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                                                       << 4U)));
        vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_r = 3U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r = vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q;
        vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r = 
            ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                            >> 0x27U))) ? 3U : ((IData)(8U) 
                                                + (IData)(vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q)));
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = ((0xffffe7ffU 
                                                  & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r) 
                                                 | ((IData)(vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q) 
                                                    << 0x0000000bU));
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = (0xfffffff7U 
                                                 & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r);
    } else if (((IData)(vlSelfRef.__PVT__csr_opcode_valid_w) 
                & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                           >> 0x28U)))) {
        vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_r = 
            (3U & (vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                   >> 0x0bU));
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = ((0xfffffff7U 
                                                  & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r) 
                                                 | (8U 
                                                    & (vlSelfRef.__PVT__u_csr__DOT__csr_sr_r 
                                                       >> 4U)));
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = (0x00000080U 
                                                 | vlSelfRef.__PVT__u_csr__DOT__csr_sr_r);
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_r = (0xffffe7ffU 
                                                 & vlSelfRef.__PVT__u_csr__DOT__csr_sr_r);
    }
    if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__intr_i) {
        vlSelfRef.__PVT__u_csr__DOT__csr_mip_r = (0x00000800U 
                                                  | vlSelfRef.__PVT__u_csr__DOT__csr_mip_r);
    }
}

void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    QData/*62:0*/ __Vdly__u_muldiv__DOT__divisor_q;
    __Vdly__u_muldiv__DOT__divisor_q = 0;
    IData/*31:0*/ __Vdly__u_muldiv__DOT__q_mask_q;
    __Vdly__u_muldiv__DOT__q_mask_q = 0;
    CData/*0:0*/ __Vdly__u_lsu__DOT__mem_rd_q;
    __Vdly__u_lsu__DOT__mem_rd_q = 0;
    CData/*3:0*/ __Vdly__u_lsu__DOT__mem_wr_q;
    __Vdly__u_lsu__DOT__mem_wr_q = 0;
    CData/*0:0*/ __Vdly__u_lsu__DOT__mem_invalidate_q;
    __Vdly__u_lsu__DOT__mem_invalidate_q = 0;
    CData/*0:0*/ __Vdly__u_lsu__DOT__mem_flush_q;
    __Vdly__u_lsu__DOT__mem_flush_q = 0;
    // Body
    vlSelfRef.__Vdly__u_muldiv__DOT__dividend_q = vlSelfRef.__PVT__u_muldiv__DOT__dividend_q;
    __Vdly__u_muldiv__DOT__divisor_q = vlSelfRef.__PVT__u_muldiv__DOT__divisor_q;
    vlSelfRef.__Vdly__u_muldiv__DOT__quotient_q = vlSelfRef.__PVT__u_muldiv__DOT__quotient_q;
    __Vdly__u_muldiv__DOT__q_mask_q = vlSelfRef.__PVT__u_muldiv__DOT__q_mask_q;
    __Vdly__u_lsu__DOT__mem_rd_q = vlSelfRef.__PVT__u_lsu__DOT__mem_rd_q;
    __Vdly__u_lsu__DOT__mem_wr_q = vlSelfRef.__PVT__u_lsu__DOT__mem_wr_q;
    vlSelfRef.__Vdly__u_csr__DOT__reset_q = vlSelfRef.__PVT__u_csr__DOT__reset_q;
    __Vdly__u_lsu__DOT__mem_invalidate_q = vlSelfRef.__PVT__u_lsu__DOT__mem_invalidate_q;
    __Vdly__u_lsu__DOT__mem_flush_q = vlSelfRef.__PVT__u_lsu__DOT__mem_flush_q;
    vlSelfRef.__PVT__u_fetch__DOT__icache_invalidate_q = 0U;
    vlSelfRef.__PVT__u_fetch__DOT__skid_valid_q = (
                                                   (1U 
                                                    & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i))) 
                                                   && ((IData)(vlSelfRef.__PVT__fetch_valid_w) 
                                                       & (~ (IData)(vlSelfRef.__PVT__fetch_accept_w))));
    vlSelfRef.__PVT__u_csr__DOT__writeback_en_q = (
                                                   (1U 
                                                    & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i))) 
                                                   && (((IData)(vlSelfRef.__PVT__csr_opcode_valid_w) 
                                                        & (~ (IData)(vlSelfRef.__PVT__csr_stall_w))) 
                                                       && ((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                                                           | (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))));
    vlSelfRef.__PVT__u_csr__DOT__writeback_squash_q 
        = ((1U & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i))) 
           && (((IData)(vlSelfRef.__PVT__u_csr__DOT__valid_unit_inst_w) 
                & (((~ (0U != (0x0050U & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_17)))) 
                    & (IData)(vlSelfRef.__PVT__u_csr__DOT__take_exception_r)) 
                   | (IData)(vlSelfRef.__PVT__u_csr__DOT__take_intr_r))) 
               | (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_ld_q)));
    if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i) {
        vlSelfRef.__Vdly__u_muldiv__DOT__dividend_q = 0U;
        __Vdly__u_muldiv__DOT__divisor_q = 0ULL;
        vlSelfRef.__Vdly__u_muldiv__DOT__quotient_q = 0U;
        __Vdly__u_muldiv__DOT__q_mask_q = 0U;
        __Vdly__u_lsu__DOT__mem_rd_q = 0U;
        __Vdly__u_lsu__DOT__mem_wr_q = 0U;
        __Vdly__u_lsu__DOT__mem_invalidate_q = 0U;
        __Vdly__u_lsu__DOT__mem_flush_q = 0U;
        vlSelfRef.__PVT__u_fetch__DOT__fetch_pc_q = 0U;
        vlSelfRef.__PVT__u_fetch__DOT__pc_d_q = 0U;
        vlSelfRef.__PVT__u_fetch__DOT__skid_buffer_q = 0ULL;
        vlSelfRef.__PVT__u_fetch__DOT__icache_fetch_q = 0U;
        vlSelfRef.__PVT__u_fetch__DOT__branch_pc_q = 0U;
        vlSelfRef.__PVT__u_fetch__DOT__branch_valid_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__pc_m_q = 0U;
        vlSelfRef.__PVT__u_lsu__DOT__mem_cacheable_q = 0U;
        vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_st_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__writeback_idx_q = 0U;
        vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q = 0U;
        vlSelfRef.__PVT__u_lsu__DOT__mem_addr_q = 0U;
        vlSelfRef.__PVT__u_lsu__DOT__mem_req_tag_q = 0U;
        vlSelfRef.__PVT__u_fetch__DOT__active_q = 0U;
        vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_ld_q = 0U;
    } else {
        if (vlSelfRef.__PVT__u_muldiv__DOT__div_start_w) {
            vlSelfRef.__Vdly__u_muldiv__DOT__dividend_q 
                = (((IData)(vlSelfRef.__PVT__u_muldiv__DOT__signed_operation_w) 
                    & (vlSelfRef.__PVT__opcode_ra_operand_w 
                       >> 0x1fU)) ? (- vlSelfRef.__PVT__opcode_ra_operand_w)
                    : vlSelfRef.__PVT__opcode_ra_operand_w);
            __Vdly__u_muldiv__DOT__divisor_q = (((IData)(vlSelfRef.__PVT__u_muldiv__DOT__signed_operation_w) 
                                                 & (vlSelfRef.__PVT__opcode_rb_operand_w 
                                                    >> 0x1fU))
                                                 ? 
                                                ((QData)((IData)(
                                                                 (- vlSelfRef.__PVT__opcode_rb_operand_w))) 
                                                 << 0x0000001fU)
                                                 : 
                                                ((QData)((IData)(vlSelfRef.__PVT__opcode_rb_operand_w)) 
                                                 << 0x0000001fU));
            vlSelfRef.__Vdly__u_muldiv__DOT__quotient_q = 0U;
            __Vdly__u_muldiv__DOT__q_mask_q = 0x80000000U;
        } else if ((1U & (~ (IData)(vlSelfRef.__PVT__u_muldiv__DOT__div_complete_w)))) {
            if (vlSelfRef.__PVT__u_muldiv__DOT__div_busy_q) {
                if ((vlSelfRef.__PVT__u_muldiv__DOT__divisor_q 
                     <= (QData)((IData)(vlSelfRef.__PVT__u_muldiv__DOT__dividend_q)))) {
                    vlSelfRef.__Vdly__u_muldiv__DOT__dividend_q 
                        = (vlSelfRef.__PVT__u_muldiv__DOT__dividend_q 
                           - (IData)(vlSelfRef.__PVT__u_muldiv__DOT__divisor_q));
                    vlSelfRef.__Vdly__u_muldiv__DOT__quotient_q 
                        = (vlSelfRef.__PVT__u_muldiv__DOT__quotient_q 
                           | vlSelfRef.__PVT__u_muldiv__DOT__q_mask_q);
                }
                __Vdly__u_muldiv__DOT__divisor_q = 
                    (0x3fffffffffffffffULL & (vlSelfRef.__PVT__u_muldiv__DOT__divisor_q 
                                              >> 1U));
                __Vdly__u_muldiv__DOT__q_mask_q = (vlSelfRef.__PVT__u_muldiv__DOT__q_mask_q 
                                                   >> 1U);
            }
        }
        if ((1U & (~ (((((IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_invalidate_q) 
                         | (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_flush_q)) 
                        | (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_rd_q)) 
                       | (0U != (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_wr_q))) 
                      & (~ (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_accept_w)))))) {
            __Vdly__u_lsu__DOT__mem_rd_q = 0U;
            __Vdly__u_lsu__DOT__mem_rd_q = (((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                                             & (0U 
                                                != 
                                                (0x0000003fU 
                                                 & (IData)(
                                                           (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                            >> 0x0000001dU))))) 
                                            & (~ (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r)));
            __Vdly__u_lsu__DOT__mem_wr_q = 0U;
            __Vdly__u_lsu__DOT__mem_invalidate_q = 0U;
            __Vdly__u_lsu__DOT__mem_invalidate_q = 
                ((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                 & ((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                             >> 0x00000029U)) & (0x03a2U 
                                                 == 
                                                 (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                  >> 0x00000014U))));
            __Vdly__u_lsu__DOT__mem_flush_q = 0U;
            __Vdly__u_lsu__DOT__mem_flush_q = ((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                                               & ((IData)(
                                                          (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                           >> 0x00000029U)) 
                                                  & (0x03a0U 
                                                     == 
                                                     (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                      >> 0x00000014U))));
            vlSelfRef.__PVT__u_lsu__DOT__mem_cacheable_q = 0U;
            vlSelfRef.__PVT__u_lsu__DOT__mem_cacheable_q 
                = (0x7fffffffU >= vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r);
            vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_st_q 
                = ((~ (0U != (0x0000003fU & (IData)(
                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                     >> 0x0000001dU))))) 
                   & (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r));
            vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q = 0U;
            if ((((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                  & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                             >> 0x25U))) & (~ (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r)))) {
                __Vdly__u_lsu__DOT__mem_wr_q = 0x0fU;
                vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q 
                    = vlSelfRef.__PVT__opcode_rb_operand_w;
            } else if ((((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                         & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                    >> 0x24U))) & (~ (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r)))) {
                if ((2U == (3U & vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r))) {
                    __Vdly__u_lsu__DOT__mem_wr_q = 0x0cU;
                    vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q 
                        = (vlSelfRef.__PVT__opcode_rb_operand_w 
                           << 0x00000010U);
                } else {
                    __Vdly__u_lsu__DOT__mem_wr_q = 3U;
                    vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q 
                        = (0x0000ffffU & vlSelfRef.__PVT__opcode_rb_operand_w);
                }
            } else if (((IData)(vlSelfRef.__PVT__lsu_opcode_valid_w) 
                        & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                   >> 0x23U)))) {
                if ((2U & vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r)) {
                    if ((1U & vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r)) {
                        __Vdly__u_lsu__DOT__mem_wr_q = 8U;
                        vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q 
                            = (vlSelfRef.__PVT__opcode_rb_operand_w 
                               << 0x00000018U);
                    } else {
                        __Vdly__u_lsu__DOT__mem_wr_q = 4U;
                        vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q 
                            = (0x00ff0000U & (vlSelfRef.__PVT__opcode_rb_operand_w 
                                              << 0x00000010U));
                    }
                } else if ((1U & vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r)) {
                    __Vdly__u_lsu__DOT__mem_wr_q = 2U;
                    vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q 
                        = (0x0000ff00U & (vlSelfRef.__PVT__opcode_rb_operand_w 
                                          << 8U));
                } else {
                    __Vdly__u_lsu__DOT__mem_wr_q = 1U;
                    vlSelfRef.__PVT__u_lsu__DOT__mem_data_wr_q 
                        = (0x000000ffU & vlSelfRef.__PVT__opcode_rb_operand_w);
                }
            } else {
                __Vdly__u_lsu__DOT__mem_wr_q = 0U;
            }
            vlSelfRef.__PVT__u_lsu__DOT__mem_addr_q = 0U;
            vlSelfRef.__PVT__u_lsu__DOT__mem_addr_q 
                = vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r;
            vlSelfRef.__PVT__u_lsu__DOT__mem_req_tag_q = 0U;
            vlSelfRef.__PVT__u_lsu__DOT__mem_req_tag_q 
                = ((0x0700U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_req_tag_q)) 
                   | (((IData)((0ULL != (0x0000000120000000ULL 
                                         & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q))) 
                       << 7U) | ((0x00000060U & (vlSelfRef.__PVT__u_lsu__DOT__mem_addr_r 
                                                 << 5U)) 
                                 | (0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                   >> 7U)))));
            vlSelfRef.__PVT__u_lsu__DOT__mem_req_tag_q 
                = ((0x00ffU & (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_req_tag_q)) 
                   | (((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                             >> 0x0000001dU)))) 
                       << 0x0000000aU) | (0x00000300U 
                                          & (((IData)(
                                                      (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                       >> 0x0000001eU)) 
                                              | (IData)(
                                                        (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                         >> 0x00000021U))) 
                                             << 8U))));
            vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_ld_q 
                = ((0U != (0x0000003fU & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x0000001dU)))) 
                   & (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_r));
        }
        if ((1U & (~ (IData)(vlSelfRef.__PVT__u_fetch__DOT__stall_w)))) {
            vlSelfRef.__PVT__u_fetch__DOT__fetch_pc_q 
                = ((IData)(4U) + vlSymsp->TOP__riscv_tcm_top.__PVT__icache_pc_w);
        }
        if (vlSymsp->TOP__riscv_tcm_top.__PVT__icache_rd_w) {
            vlSelfRef.__PVT__u_fetch__DOT__pc_d_q = vlSymsp->TOP__riscv_tcm_top.__PVT__icache_pc_w;
            vlSelfRef.__PVT__u_fetch__DOT__icache_fetch_q = 1U;
        } else if (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_i_valid_q) {
            vlSelfRef.__PVT__u_fetch__DOT__icache_fetch_q = 0U;
        }
        vlSelfRef.__PVT__u_fetch__DOT__skid_buffer_q 
            = (((IData)(vlSelfRef.__PVT__fetch_valid_w) 
                & (~ (IData)(vlSelfRef.__PVT__fetch_accept_w)))
                ? (((QData)((IData)(vlSelfRef.__PVT__fetch_pc_w)) 
                    << 0x00000020U) | (QData)((IData)(vlSelfRef.__PVT__fetch_instr_w)))
                : 0ULL);
        if ((1U & ((IData)(vlSelfRef.__PVT__u_fetch__DOT__stall_w) 
                   | (~ (IData)(vlSelfRef.__PVT__u_fetch__DOT__active_q))))) {
            vlSelfRef.__PVT__u_fetch__DOT__branch_valid_q 
                = vlSelfRef.__PVT__u_fetch__DOT__branch_w;
            vlSelfRef.__PVT__u_fetch__DOT__branch_pc_q 
                = vlSelfRef.__PVT__u_fetch__DOT__branch_pc_w;
        } else {
            vlSelfRef.__PVT__u_fetch__DOT__branch_valid_q = 0U;
            vlSelfRef.__PVT__u_fetch__DOT__branch_pc_q = 0U;
        }
        if (((IData)(vlSelfRef.__PVT__csr_opcode_valid_w) 
             & (~ (IData)(vlSelfRef.__PVT__csr_stall_w)))) {
            vlSelfRef.__PVT__u_csr__DOT__pc_m_q = vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q;
            vlSelfRef.__PVT__u_csr__DOT__writeback_idx_q 
                = (0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                  >> 7U));
        }
        if (vlSelfRef.__PVT__u_fetch__DOT__branch_w) {
            vlSelfRef.__PVT__u_fetch__DOT__active_q = 1U;
        }
    }
    vlSelfRef.__PVT__u_muldiv__DOT__divisor_q = __Vdly__u_muldiv__DOT__divisor_q;
    vlSelfRef.__PVT__u_muldiv__DOT__q_mask_q = __Vdly__u_muldiv__DOT__q_mask_q;
    vlSelfRef.__PVT__writeback_csr_idx_w = ((IData)(vlSelfRef.__PVT__u_csr__DOT__writeback_idx_q) 
                                            & (- (IData)(
                                                         ((IData)(vlSelfRef.__PVT__u_csr__DOT__writeback_en_q) 
                                                          | (IData)(vlSelfRef.__PVT__u_csr__DOT__writeback_squash_q)))));
    vlSelfRef.__PVT__u_lsu__DOT__mem_invalidate_q = __Vdly__u_lsu__DOT__mem_invalidate_q;
    vlSelfRef.__PVT__u_lsu__DOT__mem_flush_q = __Vdly__u_lsu__DOT__mem_flush_q;
    vlSelfRef.__PVT__u_lsu__DOT__mem_rd_q = __Vdly__u_lsu__DOT__mem_rd_q;
    vlSelfRef.__PVT__u_lsu__DOT__mem_wr_q = __Vdly__u_lsu__DOT__mem_wr_q;
}

void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__fetch_pc_w = ((IData)(vlSelfRef.__PVT__u_fetch__DOT__skid_valid_q)
                                    ? (IData)((vlSelfRef.__PVT__u_fetch__DOT__skid_buffer_q 
                                               >> 0x00000020U))
                                    : vlSelfRef.__PVT__u_fetch__DOT__pc_d_q);
    if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i) {
        vlSelfRef.__PVT__u_csr__DOT__writeback_value_q = 0U;
        vlSelfRef.__PVT__u_muldiv__DOT__wb_result_q = 0U;
        vlSelfRef.__PVT__u_muldiv__DOT__wb_rd_q = 0U;
        vlSelfRef.__PVT__u_muldiv__DOT__mult_result_q = 0U;
        vlSelfRef.__PVT__u_muldiv__DOT__div_inst_q = 0U;
        vlSelfRef.__PVT__u_muldiv__DOT__invert_res_q = 0U;
        vlSelfRef.__PVT__u_muldiv__DOT__rd_q = 0U;
        vlSelfRef.__PVT__u_muldiv__DOT__div_busy_q = 0U;
    } else {
        if (((IData)(vlSelfRef.__PVT__csr_opcode_valid_w) 
             & (~ (IData)(vlSelfRef.__PVT__csr_stall_w)))) {
            vlSelfRef.__PVT__u_csr__DOT__writeback_value_q 
                = vlSelfRef.__PVT__u_csr__DOT__result_r;
        }
        vlSelfRef.__PVT__u_muldiv__DOT__wb_result_q 
            = ((IData)(vlSelfRef.__PVT__u_muldiv__DOT__div_complete_w)
                ? ((IData)(vlSelfRef.__PVT__u_muldiv__DOT__div_inst_q)
                    ? ((IData)(vlSelfRef.__PVT__u_muldiv__DOT__invert_res_q)
                        ? (- vlSelfRef.__PVT__u_muldiv__DOT__quotient_q)
                        : vlSelfRef.__PVT__u_muldiv__DOT__quotient_q)
                    : ((IData)(vlSelfRef.__PVT__u_muldiv__DOT__invert_res_q)
                        ? (- vlSelfRef.__PVT__u_muldiv__DOT__dividend_q)
                        : vlSelfRef.__PVT__u_muldiv__DOT__dividend_q))
                : vlSelfRef.__PVT__u_muldiv__DOT__mult_result_q);
        vlSelfRef.__PVT__u_muldiv__DOT__wb_rd_q = ((IData)(vlSelfRef.__PVT__u_muldiv__DOT__mult_busy_q)
                                                    ? (IData)(vlSelfRef.__PVT__u_muldiv__DOT__rd_q)
                                                    : 
                                                   ((IData)(vlSelfRef.__PVT__u_muldiv__DOT__div_complete_w)
                                                     ? (IData)(vlSelfRef.__PVT__u_muldiv__DOT__rd_q)
                                                     : 0U));
        vlSelfRef.__PVT__u_muldiv__DOT__mult_result_q 
            = ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                     >> 0x00000030U))))
                ? vlSelfRef.__PVT__u_muldiv__DOT__mult_result_w[1U]
                : vlSelfRef.__PVT__u_muldiv__DOT__mult_result_w[0U]);
        if ((((IData)(vlSelfRef.__PVT__muldiv_opcode_valid_w) 
              & (IData)((0ULL != (0x007f800000000000ULL 
                                  & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)))) 
             & (~ (IData)(vlSelfRef.__PVT__muldiv_stall_w)))) {
            vlSelfRef.__PVT__u_muldiv__DOT__rd_q = 
                (0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                >> 7U));
        } else if ((1U & (~ (IData)(vlSelfRef.__PVT__u_muldiv__DOT__div_busy_q)))) {
            vlSelfRef.__PVT__u_muldiv__DOT__rd_q = 0U;
        }
        if (vlSelfRef.__PVT__u_muldiv__DOT__div_start_w) {
            vlSelfRef.__PVT__u_muldiv__DOT__div_inst_q 
                = (0U != (3U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                        >> 0x00000033U))));
            vlSelfRef.__PVT__u_muldiv__DOT__invert_res_q 
                = (1U & ((((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                    >> 0x33U)) & ((vlSelfRef.__PVT__opcode_ra_operand_w 
                                                   >> 0x1fU) 
                                                  != 
                                                  (vlSelfRef.__PVT__opcode_rb_operand_w 
                                                   >> 0x1fU))) 
                          & (0U != vlSelfRef.__PVT__opcode_rb_operand_w)) 
                         | ((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                     >> 0x35U)) & (vlSelfRef.__PVT__opcode_ra_operand_w 
                                                   >> 0x1fU))));
            vlSelfRef.__PVT__u_muldiv__DOT__div_busy_q = 1U;
        } else if (vlSelfRef.__PVT__u_muldiv__DOT__div_complete_w) {
            vlSelfRef.__PVT__u_muldiv__DOT__div_busy_q = 0U;
        }
    }
    vlSelfRef.__PVT__csr_stall_w = ((IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_ld_q) 
                                    | (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_unaligned_st_q));
    vlSelfRef.__PVT__u_muldiv__DOT__quotient_q = vlSelfRef.__Vdly__u_muldiv__DOT__quotient_q;
    vlSelfRef.__PVT__u_muldiv__DOT__dividend_q = vlSelfRef.__Vdly__u_muldiv__DOT__dividend_q;
    vlSelfRef.__PVT__u_muldiv__DOT__mult_busy_q = (
                                                   (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i)) 
                                                   & (((IData)(vlSelfRef.__PVT__muldiv_opcode_valid_w) 
                                                       & (~ (IData)(vlSelfRef.__PVT__muldiv_stall_w))) 
                                                      & (0U 
                                                         != 
                                                         (0x0000000fU 
                                                          & (IData)(
                                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                     >> 0x0000002fU))))));
    vlSelfRef.__PVT__u_muldiv__DOT__div_complete_w 
        = ((~ (0U != vlSelfRef.__PVT__u_muldiv__DOT__q_mask_q)) 
           & (IData)(vlSelfRef.__PVT__u_muldiv__DOT__div_busy_q));
}

void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__2(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__2\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i) {
        vlSelfRef.__PVT__u_csr__DOT__branch_target_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__branch_q = 0U;
        vlSelfRef.__Vdly__u_csr__DOT__reset_q = 1U;
    } else if (vlSelfRef.__PVT__u_csr__DOT__reset_q) {
        vlSelfRef.__PVT__u_csr__DOT__branch_target_q = 0x00002000U;
        vlSelfRef.__PVT__u_csr__DOT__branch_q = 1U;
        vlSelfRef.__Vdly__u_csr__DOT__reset_q = 0U;
    } else {
        vlSelfRef.__PVT__u_csr__DOT__branch_target_q 
            = ((IData)(vlSelfRef.__PVT__u_csr__DOT__take_exception_r)
                ? vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q
                : ((IData)(vlSelfRef.__PVT__u_csr__DOT__take_intr_r)
                    ? vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q
                    : ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000026U)))
                        ? vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q
                        : ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                          >> 0x00000027U)))
                            ? vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q
                            : (vlSelfRef.__PVT__u_csr__DOT__csr_mepc_q 
                               & (- (IData)((1U & (IData)(
                                                          (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                           >> 0x00000028U))))))))));
        vlSelfRef.__PVT__u_csr__DOT__branch_q = ((IData)(vlSelfRef.__PVT__u_csr__DOT__take_exception_r) 
                                                 | ((IData)(vlSelfRef.__PVT__u_csr__DOT__take_intr_r) 
                                                    | ((1U 
                                                        & (IData)(
                                                                  (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                   >> 0x00000026U)))
                                                        ? (IData)(vlSelfRef.__PVT__csr_opcode_valid_w)
                                                        : 
                                                       ((1U 
                                                         & (IData)(
                                                                   (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                    >> 0x00000027U)))
                                                         ? (IData)(vlSelfRef.__PVT__csr_opcode_valid_w)
                                                         : 
                                                        ((IData)(
                                                                 (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                  >> 0x00000028U)) 
                                                         & (IData)(vlSelfRef.__PVT__csr_opcode_valid_w))))));
    }
    vlSelfRef.__PVT__u_csr__DOT__reset_q = vlSelfRef.__Vdly__u_csr__DOT__reset_q;
    if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_cpu_i) {
        vlSelfRef.__PVT__u_csr__DOT__csr_mepc_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mcause_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mip_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mie_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q = 3U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mcycle_q = 0U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_q = 0U;
    } else {
        if ((((IData)(vlSelfRef.__PVT__csr_opcode_valid_w) 
              & ((IData)(vlSelfRef.__PVT__u_csr__DOT__set_r) 
                 | (IData)(vlSelfRef.__PVT__u_csr__DOT__clr_r))) 
             & (0x07b2U == (0x00000fffU & vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r)))) {
            if (VL_UNLIKELY(((0U == (0xff000000U & vlSelfRef.__PVT__u_csr__DOT__data_r))))) {
                VL_FINISH_MT("../../core/rv32im/riscv_csr.v", 548, "");
                VL_FINISH_MT("../../core/rv32im/riscv_csr.v", 549, "");
            } else if (VL_UNLIKELY(((0x01000000U == 
                                     (0xff000000U & vlSelfRef.__PVT__u_csr__DOT__data_r))))) {
                VL_WRITEF_NX("%c",1, '#',8,(0x000000ffU 
                                            & vlSelfRef.__PVT__u_csr__DOT__data_r));
            }
        }
        vlSelfRef.__PVT__u_csr__DOT__csr_mepc_q = vlSelfRef.__PVT__u_csr__DOT__csr_mepc_r;
        vlSelfRef.__PVT__u_csr__DOT__csr_sr_q = vlSelfRef.__PVT__u_csr__DOT__csr_sr_r;
        vlSelfRef.__PVT__u_csr__DOT__csr_mcause_q = vlSelfRef.__PVT__u_csr__DOT__csr_mcause_r;
        vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_q = vlSelfRef.__PVT__u_csr__DOT__csr_mtvec_r;
        vlSelfRef.__PVT__u_csr__DOT__csr_mip_q = vlSelfRef.__PVT__u_csr__DOT__csr_mip_r;
        vlSelfRef.__PVT__u_csr__DOT__csr_mie_q = vlSelfRef.__PVT__u_csr__DOT__csr_mie_r;
        vlSelfRef.__PVT__u_csr__DOT__csr_mpriv_q = 3U;
        vlSelfRef.__PVT__u_csr__DOT__csr_mcycle_q = vlSelfRef.__PVT__u_csr__DOT__csr_mcycle_r;
        vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_q 
            = vlSelfRef.__PVT__u_csr__DOT__csr_mscratch_r;
    }
    vlSelfRef.__PVT__u_csr__DOT__csr_mcycle_r = ((IData)(1U) 
                                                 + vlSelfRef.__PVT__u_csr__DOT__csr_mcycle_q);
    vlSelfRef.__PVT__u_csr__DOT__irq_masked_r = ((- (IData)(
                                                            (1U 
                                                             & (vlSelfRef.__PVT__u_csr__DOT__csr_sr_q 
                                                                >> 3U)))) 
                                                 & (vlSelfRef.__PVT__u_csr__DOT__csr_mip_q 
                                                    & vlSelfRef.__PVT__u_csr__DOT__csr_mie_q));
}

void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__3(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__3\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__u_muldiv__DOT__signed_operation_w 
        = (IData)((0ULL != (0x0028000000000000ULL & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)));
    vlSelfRef.__PVT__muldiv_stall_w = (((IData)(vlSelfRef.__PVT__u_muldiv__DOT__div_busy_q) 
                                        & (0U != (0x000000ffU 
                                                  & (IData)(
                                                            (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                             >> 0x0000002fU))))) 
                                       | ((IData)(vlSelfRef.__PVT__u_muldiv__DOT__mult_busy_q) 
                                          & (0U != 
                                             (0x0000000fU 
                                              & (IData)(
                                                        (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                         >> 0x00000033U))))));
    vlSelfRef.__PVT__u_csr__DOT__set_r = (0U != (3U 
                                                 & ((IData)(
                                                            (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                             >> 0x0000002cU)) 
                                                    | (IData)(
                                                              (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                               >> 0x00000029U)))));
    vlSelfRef.__PVT__u_csr__DOT__clr_r = (IData)((0ULL 
                                                  != 
                                                  (0x00005a0000000000ULL 
                                                   & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)));
}

void Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__u_lsu__DOT__wb_result_r = 0U;
    vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r = (0x0000001fU 
                                             & (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w));
    vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r = (3U & 
                                               ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                >> 5U));
    vlSelfRef.__PVT__u_lsu__DOT__load_byte_r = (1U 
                                                & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                   >> 7U));
    vlSelfRef.__PVT__u_lsu__DOT__load_half_r = (1U 
                                                & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                   >> 8U));
    vlSelfRef.__PVT__u_lsu__DOT__load_word_r = (1U 
                                                & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                   >> 9U));
    vlSelfRef.__PVT__u_lsu__DOT__load_signed_r = (1U 
                                                  & ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w) 
                                                     >> 0x0aU));
    if ((((IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q) 
          | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_ack_w)) 
         & (((IData)(vlSelfRef.__PVT__u_lsu__DOT__load_byte_r) 
             | (IData)(vlSelfRef.__PVT__u_lsu__DOT__load_half_r)) 
            | (IData)(vlSelfRef.__PVT__u_lsu__DOT__load_word_r)))) {
        if (vlSelfRef.__PVT__u_lsu__DOT__load_byte_r) {
            vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                = ((2U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                    ? ((1U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                        ? (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                           >> 0x18U) : (0x000000ffU 
                                        & (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                                           >> 0x10U)))
                    : ((1U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                        ? (0x000000ffU & (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                                          >> 8U)) : 
                       (0x000000ffU & vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w)));
            if (((IData)(vlSelfRef.__PVT__u_lsu__DOT__load_signed_r) 
                 & (vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    >> 7U))) {
                vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    = (0xffffff00U | (0x000000ffU & vlSelfRef.__PVT__u_lsu__DOT__wb_result_r));
            }
        } else if (vlSelfRef.__PVT__u_lsu__DOT__load_half_r) {
            vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                = ((2U & (IData)(vlSelfRef.__PVT__u_lsu__DOT__addr_lsb_r))
                    ? (vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w 
                       >> 0x10U) : (0x0000ffffU & vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w));
            if (((IData)(vlSelfRef.__PVT__u_lsu__DOT__load_signed_r) 
                 & (vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    >> 0x0fU))) {
                vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                    = (0xffff0000U | (0x0000ffffU & vlSelfRef.__PVT__u_lsu__DOT__wb_result_r));
            }
        } else {
            vlSelfRef.__PVT__u_lsu__DOT__wb_result_r 
                = vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w;
        }
    } else {
        vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r = 0U;
    }
}

void Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__opcode_rb_operand_w = ((((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q) 
                                              == (0x0000001fU 
                                                  & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                     >> 0x00000014U))) 
                                             & (0U 
                                                != (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q)))
                                             ? vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__result_q
                                             : (((0U 
                                                  != (IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r)) 
                                                 & ((IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r) 
                                                    == 
                                                    (0x0000001fU 
                                                     & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x00000014U))))
                                                 ? vlSelfRef.__PVT__u_lsu__DOT__wb_result_r
                                                 : vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__rb_value_w));
    vlSelfRef.__PVT__opcode_ra_operand_w = ((((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q) 
                                              == (0x0000001fU 
                                                  & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                     >> 0x0000000fU))) 
                                             & (0U 
                                                != (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q)))
                                             ? vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__result_q
                                             : (((0U 
                                                  != (IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r)) 
                                                 & ((IData)(vlSelfRef.__PVT__u_lsu__DOT__wb_idx_r) 
                                                    == 
                                                    (0x0000001fU 
                                                     & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x0000000fU))))
                                                 ? vlSelfRef.__PVT__u_lsu__DOT__wb_result_r
                                                 : vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ra_value_w));
    vlSelfRef.__PVT__u_fetch__DOT__icache_busy_w = 
        ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_i_valid_q)) 
         & (IData)(vlSelfRef.__PVT__u_fetch__DOT__icache_fetch_q));
    vlSelfRef.__PVT__lsu_stall_w = ((~ (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_accept_w)) 
                                    & ((IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_invalidate_q) 
                                       | ((IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_flush_q) 
                                          | ((IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_rd_q) 
                                             | (0U 
                                                != (IData)(vlSelfRef.__PVT__u_lsu__DOT__mem_wr_q))))));
    vlSelfRef.__PVT__branch_pc_w = ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                   >> 0x00000015U)))
                                     ? (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q 
                                        + (((- (IData)(
                                                       (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x0000001fU))) 
                                            << 0x00000014U) 
                                           | ((((0x000001feU 
                                                 & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                    >> 0x0000000bU)) 
                                                | (1U 
                                                   & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                      >> 0x00000014U))) 
                                               << 0x0000000bU) 
                                              | (0x000007feU 
                                                 & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                    >> 0x00000014U)))))
                                     : ((1U & (IData)(
                                                      (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                       >> 0x00000016U)))
                                         ? (0xfffffffeU 
                                            & (vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r 
                                               + vlSelfRef.__PVT__opcode_ra_operand_w))
                                         : (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q 
                                            + (((- (IData)(
                                                           (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                            >> 0x0000001fU))) 
                                                << 0x0000000dU) 
                                               | ((((2U 
                                                     & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                        >> 0x0000001eU)) 
                                                    | (1U 
                                                       & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                          >> 7U))) 
                                                   << 0x0000000bU) 
                                                  | ((0x000007e0U 
                                                      & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                         >> 0x00000014U)) 
                                                     | (0x0000001eU 
                                                        & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                           >> 7U))))))));
}

void Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__4(Vriscv_tcm_top_riscv_core* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__4\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__fetch_instr_w = ((IData)(vlSelfRef.__PVT__u_fetch__DOT__skid_valid_q)
                                       ? (IData)(vlSelfRef.__PVT__u_fetch__DOT__skid_buffer_q)
                                       : vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read0_q);
}

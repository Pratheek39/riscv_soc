// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

VL_ATTR_COLD void Vriscv_tcm_top_mem_tcm___ctor_var_reset(Vriscv_tcm_top_mem_tcm* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm___ctor_var_reset\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->__PVT__clk_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11908517815223722933ull);
    vlSelf->__PVT__rst_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5726502174457611970ull);
    vlSelf->__PVT__mem_d_addr_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 2304078081650289806ull);
    vlSelf->__PVT__mem_d_data_wr_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 1383832563546677191ull);
    vlSelf->__PVT__mem_d_rd_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9663171872701606544ull);
    vlSelf->__PVT__mem_d_wr_i = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 13732973027965244985ull);
    vlSelf->__PVT__mem_d_cacheable_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13989152540158008205ull);
    vlSelf->__PVT__mem_d_req_tag_i = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 15660954842901474671ull);
    vlSelf->__PVT__mem_d_invalidate_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7254017566934013504ull);
    vlSelf->__PVT__mem_d_flush_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6642231353656565197ull);
    vlSelf->__PVT__mem_i_rd_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5920783605736545164ull);
    vlSelf->__PVT__mem_i_flush_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5397489709389247068ull);
    vlSelf->__PVT__mem_i_invalidate_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4601761118872933609ull);
    vlSelf->__PVT__mem_i_pc_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 3535400670495986075ull);
    vlSelf->__PVT__ext_wr_i = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 2634695421414729961ull);
    vlSelf->__PVT__ext_rd_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3924050788359096314ull);
    vlSelf->__PVT__ext_addr_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17178724297893301304ull);
    vlSelf->__PVT__ext_write_data_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14855461443425762870ull);
    vlSelf->__PVT__mem_out_data_rd_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 9186482687680746549ull);
    vlSelf->__PVT__mem_out_accept_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1774215791353912610ull);
    vlSelf->__PVT__mem_out_ack_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14188499939050827305ull);
    vlSelf->__PVT__mem_out_resp_tag_i = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 13623883798351938301ull);
    vlSelf->__PVT__mem_d_data_rd_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 15465652081196106920ull);
    vlSelf->__PVT__mem_d_accept_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5625784886876366328ull);
    vlSelf->__PVT__mem_d_ack_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6002915091164585049ull);
    vlSelf->__PVT__mem_d_resp_tag_o = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 11322788585826658924ull);
    vlSelf->__PVT__mem_i_accept_o = 1U;
    ;
    vlSelf->__PVT__mem_i_valid_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13405786424116236132ull);
    vlSelf->__PVT__mem_i_inst_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 9169566363050999212ull);
    vlSelf->__PVT__ext_read_data_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 17234818506436098893ull);
    vlSelf->__PVT__ext_accept_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4181026853644133550ull);
    vlSelf->__PVT__mem_out_addr_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8994240913773586220ull);
    vlSelf->__PVT__mem_out_data_wr_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 16973072728998611ull);
    vlSelf->__PVT__mem_out_rd_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17106650985875115273ull);
    vlSelf->__PVT__mem_out_wr_o = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 4095379560623038135ull);
    vlSelf->__PVT__mem_out_cacheable_o = 0U;
    ;
    vlSelf->__PVT__mem_out_req_tag_o = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 16862389950097916221ull);
    vlSelf->__PVT__mem_out_invalidate_o = 0U;
    ;
    vlSelf->__PVT__mem_out_flush_o = 0U;
    ;
    vlSelf->__PVT__mem_out_resp_accept_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1945585860281733098ull);
    vlSelf->__PVT__muxed_addr_w = VL_SCOPED_RAND_RESET_I(14, __VscopeHash, 17669373089149187073ull);
    vlSelf->__PVT__muxed_data_w = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 9958232459024897045ull);
    vlSelf->__PVT__muxed_wr_w = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 13640124599744724183ull);
    vlSelf->__PVT__mem_i_valid_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1107793777710722300ull);
    vlSelf->__PVT__mem_d_accept_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7525658550737157615ull);
    vlSelf->__PVT__mem_d_tag_q = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 15047521244567415109ull);
    vlSelf->__PVT__mem_d_ack_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9745888815095529934ull);
}

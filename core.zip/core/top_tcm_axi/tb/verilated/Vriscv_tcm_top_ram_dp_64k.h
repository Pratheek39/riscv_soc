// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vriscv_tcm_top.h for the primary calling header

#ifndef VERILATED_VRISCV_TCM_TOP_RAM_DP_64K_H_
#define VERILATED_VRISCV_TCM_TOP_RAM_DP_64K_H_  // guard

#include "verilated.h"


class Vriscv_tcm_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vriscv_tcm_top_ram_dp_64k final {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ __PVT__clk0_i;
    CData/*0:0*/ __PVT__rst0_i;
    CData/*3:0*/ __PVT__wr0_i;
    CData/*0:0*/ __PVT__clk1_i;
    CData/*0:0*/ __PVT__rst1_i;
    CData/*3:0*/ __PVT__wr1_i;
    SData/*13:0*/ __PVT__addr0_i;
    SData/*13:0*/ __PVT__addr1_i;
    IData/*31:0*/ __PVT__data0_i;
    IData/*31:0*/ __PVT__data1_i;
    IData/*31:0*/ __PVT__data0_o;
    IData/*31:0*/ __PVT__data1_o;
    IData/*31:0*/ __PVT__ram_read0_q;
    IData/*31:0*/ __PVT__ram_read1_q;
    VlUnpacked<IData/*31:0*/, 16384> ram;

    // INTERNAL VARIABLES
    Vriscv_tcm_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vriscv_tcm_top_ram_dp_64k();
    ~Vriscv_tcm_top_ram_dp_64k();
    void ctor(Vriscv_tcm_top__Syms* symsp, const char* namep);
    void dtor();
    VL_UNCOPYABLE(Vriscv_tcm_top_ram_dp_64k);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard

// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vriscv_tcm_top.h for the primary calling header

#ifndef VERILATED_VRISCV_TCM_TOP_RISCV_TCM_TOP_H_
#define VERILATED_VRISCV_TCM_TOP_RISCV_TCM_TOP_H_  // guard

#include "verilated.h"
class Vriscv_tcm_top_mem_tcm;
class Vriscv_tcm_top_riscv_core;


class Vriscv_tcm_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vriscv_tcm_top_riscv_tcm_top final {
  public:
    // CELLS
    Vriscv_tcm_top_riscv_core* u_core;
    Vriscv_tcm_top_mem_tcm* u_mem_tcm;

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*0:0*/ clk_i;
        CData/*0:0*/ rst_i;
        CData/*0:0*/ rst_cpu_i;
        CData/*0:0*/ axi_i_awready_i;
        CData/*0:0*/ axi_i_wready_i;
        CData/*0:0*/ axi_i_bvalid_i;
        CData/*1:0*/ axi_i_bresp_i;
        CData/*0:0*/ axi_i_arready_i;
        CData/*0:0*/ axi_i_rvalid_i;
        CData/*1:0*/ axi_i_rresp_i;
        CData/*0:0*/ axi_t_awvalid_i;
        CData/*3:0*/ axi_t_awid_i;
        CData/*7:0*/ axi_t_awlen_i;
        CData/*1:0*/ axi_t_awburst_i;
        CData/*0:0*/ axi_t_wvalid_i;
        CData/*3:0*/ axi_t_wstrb_i;
        CData/*0:0*/ axi_t_wlast_i;
        CData/*0:0*/ axi_t_bready_i;
        CData/*0:0*/ axi_t_arvalid_i;
        CData/*3:0*/ axi_t_arid_i;
        CData/*7:0*/ axi_t_arlen_i;
        CData/*1:0*/ axi_t_arburst_i;
        CData/*0:0*/ axi_t_rready_i;
        CData/*0:0*/ intr_i;
        CData/*0:0*/ axi_i_awvalid_o;
        CData/*0:0*/ axi_i_wvalid_o;
        CData/*3:0*/ axi_i_wstrb_o;
        CData/*0:0*/ axi_i_bready_o;
        CData/*0:0*/ axi_i_arvalid_o;
        CData/*0:0*/ axi_i_rready_o;
        CData/*0:0*/ axi_t_awready_o;
        CData/*0:0*/ axi_t_wready_o;
        CData/*0:0*/ axi_t_bvalid_o;
        CData/*1:0*/ axi_t_bresp_o;
        CData/*3:0*/ axi_t_bid_o;
        CData/*0:0*/ axi_t_arready_o;
        CData/*0:0*/ axi_t_rvalid_o;
        CData/*1:0*/ axi_t_rresp_o;
        CData/*3:0*/ axi_t_rid_o;
        CData/*0:0*/ axi_t_rlast_o;
        CData/*0:0*/ __PVT__conv_ram_rd_w;
        CData/*3:0*/ __PVT__ext_out_wr_w;
        CData/*0:0*/ __PVT__dcache_accept_w;
        CData/*3:0*/ __PVT__conv_ram_wr_w;
        CData/*0:0*/ __PVT__ext_out_rd_w;
        CData/*0:0*/ __PVT__ext_out_ack_w;
        CData/*0:0*/ __PVT__icache_rd_w;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__req_pop_w;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__req_push_w;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__res_push_w;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__awvalid_inhibit_q;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__wvalid_inhibit_q;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__u_resp__DOT__pop_i;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q;
        CData/*1:0*/ __PVT__u_mem_axi__DOT__u_resp__DOT__count_q;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q;
        CData/*0:0*/ __PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q;
        CData/*1:0*/ __PVT__u_mem_axi__DOT__u_req__DOT__count_q;
        CData/*7:0*/ __PVT__u_axi_conv__DOT__req_len_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__req_rd_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__req_wr_q;
        CData/*3:0*/ __PVT__u_axi_conv__DOT__req_id_q;
        CData/*1:0*/ __PVT__u_axi_conv__DOT__req_axburst_q;
    };
    struct {
        CData/*7:0*/ __PVT__u_axi_conv__DOT__req_axlen_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__bvalid_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__rvalid_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__rlast_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__rbuf_valid_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__rbuf_last_q;
        CData/*0:0*/ __PVT__u_axi_conv__DOT__write_active;
        CData/*0:0*/ __VdfgRegularize_hebeb780c_0_9;
        CData/*0:0*/ __VdfgRegularize_hebeb780c_0_12;
        CData/*0:0*/ __VdfgRegularize_hebeb780c_0_23;
        SData/*10:0*/ __PVT__dcache_resp_tag_w;
        IData/*31:0*/ axi_i_rdata_i;
        IData/*31:0*/ axi_t_awaddr_i;
        IData/*31:0*/ axi_t_wdata_i;
        IData/*31:0*/ axi_t_araddr_i;
        IData/*31:0*/ axi_i_awaddr_o;
        IData/*31:0*/ axi_i_wdata_o;
        IData/*31:0*/ axi_i_araddr_o;
        IData/*31:0*/ axi_t_rdata_o;
        IData/*31:0*/ __PVT__dcache_data_rd_w;
        IData/*31:0*/ __PVT__icache_pc_w;
        IData/*31:0*/ __PVT__u_axi_conv__DOT__calculate_addr_next__Vstatic__mask;
        IData/*31:0*/ __PVT__u_axi_conv__DOT__req_addr_q;
        IData/*31:0*/ __PVT__u_axi_conv__DOT__rbuf_data_q;
        VlUnpacked<SData/*10:0*/, 2> __PVT__u_mem_axi__DOT__u_resp__DOT__ram_q;
        VlUnpacked<VlWide<3>/*68:0*/, 2> __PVT__u_mem_axi__DOT__u_req__DOT__ram_q;
    };

    // INTERNAL VARIABLES
    Vriscv_tcm_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vriscv_tcm_top_riscv_tcm_top();
    ~Vriscv_tcm_top_riscv_tcm_top();
    void ctor(Vriscv_tcm_top__Syms* symsp, const char* namep);
    void dtor();
    VL_UNCOPYABLE(Vriscv_tcm_top_riscv_tcm_top);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard

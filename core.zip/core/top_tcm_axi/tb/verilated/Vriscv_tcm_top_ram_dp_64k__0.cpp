// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

void Vriscv_tcm_top_ram_dp_64k___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0(Vriscv_tcm_top_ram_dp_64k* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vriscv_tcm_top_ram_dp_64k___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*7:0*/ __VdlyVal__ram__v0;
    __VdlyVal__ram__v0 = 0;
    SData/*13:0*/ __VdlyDim0__ram__v0;
    __VdlyDim0__ram__v0 = 0;
    CData/*0:0*/ __VdlySet__ram__v0;
    __VdlySet__ram__v0 = 0;
    CData/*7:0*/ __VdlyVal__ram__v1;
    __VdlyVal__ram__v1 = 0;
    SData/*13:0*/ __VdlyDim0__ram__v1;
    __VdlyDim0__ram__v1 = 0;
    CData/*0:0*/ __VdlySet__ram__v1;
    __VdlySet__ram__v1 = 0;
    CData/*7:0*/ __VdlyVal__ram__v2;
    __VdlyVal__ram__v2 = 0;
    SData/*13:0*/ __VdlyDim0__ram__v2;
    __VdlyDim0__ram__v2 = 0;
    CData/*0:0*/ __VdlySet__ram__v2;
    __VdlySet__ram__v2 = 0;
    CData/*7:0*/ __VdlyVal__ram__v3;
    __VdlyVal__ram__v3 = 0;
    SData/*13:0*/ __VdlyDim0__ram__v3;
    __VdlyDim0__ram__v3 = 0;
    CData/*0:0*/ __VdlySet__ram__v3;
    __VdlySet__ram__v3 = 0;
    // Body
    __VdlySet__ram__v0 = 0U;
    __VdlySet__ram__v1 = 0U;
    __VdlySet__ram__v2 = 0U;
    __VdlySet__ram__v3 = 0U;
    if ((1U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_wr_w))) {
        __VdlyVal__ram__v0 = (0x000000ffU & vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_data_w);
        __VdlyDim0__ram__v0 = vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_addr_w;
        __VdlySet__ram__v0 = 1U;
    }
    if ((2U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_wr_w))) {
        __VdlyVal__ram__v1 = (0x000000ffU & (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_data_w 
                                             >> 8U));
        __VdlyDim0__ram__v1 = vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_addr_w;
        __VdlySet__ram__v1 = 1U;
    }
    if ((4U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_wr_w))) {
        __VdlyVal__ram__v2 = (0x000000ffU & (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_data_w 
                                             >> 0x10U));
        __VdlyDim0__ram__v2 = vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_addr_w;
        __VdlySet__ram__v2 = 1U;
    }
    if ((8U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_wr_w))) {
        __VdlyVal__ram__v3 = (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_data_w 
                              >> 0x18U);
        __VdlyDim0__ram__v3 = vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_addr_w;
        __VdlySet__ram__v3 = 1U;
    }
    vlSelfRef.__PVT__ram_read0_q = vlSelfRef.ram[(0x00003fffU 
                                                  & (vlSymsp->TOP__riscv_tcm_top.__PVT__icache_pc_w 
                                                     >> 2U))];
    vlSelfRef.__PVT__ram_read1_q = vlSelfRef.ram[vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_addr_w];
    if (__VdlySet__ram__v0) {
        vlSelfRef.ram[__VdlyDim0__ram__v0] = ((0xffffff00U 
                                               & vlSelfRef.ram
                                               [__VdlyDim0__ram__v0]) 
                                              | (IData)(__VdlyVal__ram__v0));
    }
    if (__VdlySet__ram__v1) {
        vlSelfRef.ram[__VdlyDim0__ram__v1] = ((0xffff00ffU 
                                               & vlSelfRef.ram
                                               [__VdlyDim0__ram__v1]) 
                                              | ((IData)(__VdlyVal__ram__v1) 
                                                 << 8U));
    }
    if (__VdlySet__ram__v2) {
        vlSelfRef.ram[__VdlyDim0__ram__v2] = ((0xff00ffffU 
                                               & vlSelfRef.ram
                                               [__VdlyDim0__ram__v2]) 
                                              | ((IData)(__VdlyVal__ram__v2) 
                                                 << 0x00000010U));
    }
    if (__VdlySet__ram__v3) {
        vlSelfRef.ram[__VdlyDim0__ram__v3] = ((0x00ffffffU 
                                               & vlSelfRef.ram
                                               [__VdlyDim0__ram__v3]) 
                                              | ((IData)(__VdlyVal__ram__v3) 
                                                 << 0x00000018U));
    }
}

// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

void Vriscv_tcm_top_ram_dp_64k___ctor_var_reset(Vriscv_tcm_top_ram_dp_64k* vlSelf);

Vriscv_tcm_top_ram_dp_64k::Vriscv_tcm_top_ram_dp_64k() = default;
Vriscv_tcm_top_ram_dp_64k::~Vriscv_tcm_top_ram_dp_64k() = default;

void Vriscv_tcm_top_ram_dp_64k::ctor(Vriscv_tcm_top__Syms* symsp, const char* namep) {
    vlSymsp = symsp;
    vlNamep = strdup(Verilated::catName(vlSymsp->name(), namep));
    // Reset structure values
    Vriscv_tcm_top_ram_dp_64k___ctor_var_reset(this);
}

void Vriscv_tcm_top_ram_dp_64k::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

void Vriscv_tcm_top_ram_dp_64k::dtor() {
    VL_DO_DANGLING(std::free(const_cast<char*>(vlNamep)), vlNamep);
}

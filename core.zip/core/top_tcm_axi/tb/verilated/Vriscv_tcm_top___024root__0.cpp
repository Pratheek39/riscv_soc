// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

void Vriscv_tcm_top___024root___eval_sample(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_sample\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
bool Vriscv_tcm_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 1> &in);
void Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top_mem_tcm* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__1(Vriscv_tcm_top_mem_tcm* vlSelf);
void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__0(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_exec___ico_sequent__TOP__riscv_tcm_top__u_core__u_exec__0(Vriscv_tcm_top_riscv_exec* vlSelf);
void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__1(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__2(Vriscv_tcm_top_riscv_core* vlSelf);

bool Vriscv_tcm_top___024root___eval_ico(Vriscv_tcm_top___024root* vlSelf, CData/*0:0*/ firstIteration) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_ico\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VicoExecute;
    // Body
    vlSelfRef.__VicoTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VicoTriggered[0U]) 
                                     | (IData)((IData)(firstIteration)));
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vriscv_tcm_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vriscv_tcm_top___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        {
            // Inlined CFunc: _eval_body__ico
            if ((1ULL & vlSelfRef.__VicoTriggered[0U])) {
                {
                    // Inlined CFunc: _ico_sequent__TOP__0
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__rst_cpu_i, vlSelfRef.rst_cpu_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__rst_i, vlSelfRef.rst_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__clk_i, vlSelfRef.clk_i);
                    VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arburst_i, vlSelfRef.axi_t_arburst_i);
                    VL_ASSIGN_ISU(8, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arlen_i, vlSelfRef.axi_t_arlen_i);
                    VL_ASSIGN_ISU(4, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arid_i, vlSelfRef.axi_t_arid_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wlast_i, vlSelfRef.axi_t_wlast_i);
                    VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awburst_i, vlSelfRef.axi_t_awburst_i);
                    VL_ASSIGN_ISU(8, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awlen_i, vlSelfRef.axi_t_awlen_i);
                    VL_ASSIGN_ISU(4, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awid_i, vlSelfRef.axi_t_awid_i);
                    VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rresp_i, vlSelfRef.axi_i_rresp_i);
                    VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bresp_i, vlSelfRef.axi_i_bresp_i);
                    VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wdata_i, vlSelfRef.axi_t_wdata_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_arready_i, vlSelfRef.axi_i_arready_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_wready_i, vlSelfRef.axi_i_wready_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_awready_i, vlSelfRef.axi_i_awready_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_rready_i, vlSelfRef.axi_t_rready_i);
                    VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_araddr_i, vlSelfRef.axi_t_araddr_i);
                    VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i, vlSelfRef.axi_t_awaddr_i);
                    VL_ASSIGN_ISU(4, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wstrb_i, vlSelfRef.axi_t_wstrb_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i, vlSelfRef.axi_t_wvalid_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i, vlSelfRef.axi_t_arvalid_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_bready_i, vlSelfRef.axi_t_bready_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__intr_i, vlSelfRef.intr_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i, vlSelfRef.axi_t_awvalid_i);
                    VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rdata_i, vlSelfRef.axi_i_rdata_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rvalid_i, vlSelfRef.axi_i_rvalid_i);
                    VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bvalid_i, vlSelfRef.axi_i_bvalid_i);
                }
                vlSelfRef.__Vm_traceActivity[1U] = 1U;
                Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__0((&vlSymsp->TOP__riscv_tcm_top__u_mem_tcm));
                Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__0((&vlSymsp->TOP__riscv_tcm_top));
                Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__1((&vlSymsp->TOP__riscv_tcm_top__u_mem_tcm));
                Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__0((&vlSymsp->TOP__riscv_tcm_top__u_core));
                {
                    // Inlined CFunc: _ico_sequent__TOP__1
                    VL_ASSIGN_SII(1, vlSelfRef.axi_t_wready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_wready_o);
                    VL_ASSIGN_SII(1, vlSelfRef.axi_t_awready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_awready_o);
                    VL_ASSIGN_SII(1, vlSelfRef.axi_t_arready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_arready_o);
                }
                Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
                Vriscv_tcm_top_riscv_exec___ico_sequent__TOP__riscv_tcm_top__u_core__u_exec__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
                Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__1((&vlSymsp->TOP__riscv_tcm_top__u_core));
                Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__1((&vlSymsp->TOP__riscv_tcm_top));
                Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__1((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
                Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__2((&vlSymsp->TOP__riscv_tcm_top__u_core));
            }
        }
    }
    return (__VicoExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
void Vriscv_tcm_top___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in);

bool Vriscv_tcm_top___024root___eval_act(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_act\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__act
        vlSelfRef.__VactTriggered[0U] = (QData)((IData)(
                                                        ((((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__rst_cpu_i) 
                                                           & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_cpu_i__0))) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__rst_i) 
                                                              & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_i__0))) 
                                                             << 1U) 
                                                            | ((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__clk_i) 
                                                               & (~ (IData)(vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__clk_i__0)))))));
        vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__clk_i__0 
            = vlSelfRef.__Vcellinp__riscv_tcm_top__clk_i;
        vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_i__0 
            = vlSelfRef.__Vcellinp__riscv_tcm_top__rst_i;
        vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_cpu_i__0 
            = vlSelfRef.__Vcellinp__riscv_tcm_top__rst_cpu_i;
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vriscv_tcm_top___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    Vriscv_tcm_top___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    return (0U);
}

bool Vriscv_tcm_top___024root___eval_inact(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_inact\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    return (0U);
}

bool Vriscv_tcm_top___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in);
void Vriscv_tcm_top___024root___eval_body__nba(Vriscv_tcm_top___024root* vlSelf);
void Vriscv_tcm_top___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out);

bool Vriscv_tcm_top___024root___eval_nba(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_nba\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = Vriscv_tcm_top___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        Vriscv_tcm_top___024root___eval_body__nba(vlSelf);
        Vriscv_tcm_top___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

bool Vriscv_tcm_top___024root___eval_obs(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_obs\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    return (0U);
}

bool Vriscv_tcm_top___024root___eval_react(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_react\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    return (0U);
}

void Vriscv_tcm_top___024root___eval_postponed(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_postponed\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

bool Vriscv_tcm_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___trigger_anySet__ico\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

bool Vriscv_tcm_top___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___trigger_anySet__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

void Vriscv_tcm_top_ram_dp_64k___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0(Vriscv_tcm_top_ram_dp_64k* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top_mem_tcm* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__0(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_exec___nba_sequent__TOP__riscv_tcm_top__u_core__u_exec__0(Vriscv_tcm_top_riscv_exec* vlSelf);
void Vriscv_tcm_top_riscv_regfile___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__u_regfile__0(Vriscv_tcm_top_riscv_regfile* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__2(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__1(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_exec___nba_sequent__TOP__riscv_tcm_top__u_core__u_exec__1(Vriscv_tcm_top_riscv_exec* vlSelf);
void Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__2(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__2(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__3(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_exec___nba_sequent__TOP__riscv_tcm_top__u_core__u_exec__2(Vriscv_tcm_top_riscv_exec* vlSelf);
void Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__3(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__1(Vriscv_tcm_top_mem_tcm* vlSelf);
void Vriscv_tcm_top_mem_tcm___nba_comb__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top_mem_tcm* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__4(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_decode___nba_comb__TOP__riscv_tcm_top__u_core__u_decode__2(Vriscv_tcm_top_riscv_decode* vlSelf);

void Vriscv_tcm_top___024root___eval_body__nba(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_body__nba\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vriscv_tcm_top_ram_dp_64k___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0((&vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram));
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__0((&vlSymsp->TOP__riscv_tcm_top));
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__0((&vlSymsp->TOP__riscv_tcm_top__u_mem_tcm));
        {
            // Inlined CFunc: _nba_sequent__TOP__0
            VL_ASSIGN_SUI(4, vlSelfRef.axi_i_wstrb_o, 
                          (0x0000000fU & vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                           [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][2U]));
            VL_ASSIGN_SUI(32, vlSelfRef.axi_i_wdata_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                          [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][1U]);
            VL_ASSIGN_SUI(4, vlSelfRef.axi_t_rid_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_id_q);
            VL_ASSIGN_SUI(4, vlSelfRef.axi_t_bid_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_id_q);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_bvalid_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__bvalid_q);
            VL_ASSIGN_SUI(32, vlSelfRef.axi_i_araddr_o, vlSymsp->TOP__riscv_tcm_top.axi_i_awaddr_o);
            VL_ASSIGN_SUI(32, vlSelfRef.axi_i_awaddr_o, vlSymsp->TOP__riscv_tcm_top.axi_i_awaddr_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_rlast_o, vlSymsp->TOP__riscv_tcm_top.axi_t_rlast_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_rvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_t_rvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_arvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_i_arvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_wvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_i_wvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_awvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_i_awvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_rready_o, 
                          (1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q))));
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_bready_o, 
                          (1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q))));
        }
        Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__1((&vlSymsp->TOP__riscv_tcm_top));
        {
            // Inlined CFunc: _ico_sequent__TOP__1
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_wready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_wready_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_awready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_awready_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_arready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_arready_o);
        }
    }
    if ((5ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__0((&vlSymsp->TOP__riscv_tcm_top__u_core));
        vlSelfRef.__Vm_traceActivity[3U] = 1U;
        Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_exec___nba_sequent__TOP__riscv_tcm_top__u_core__u_exec__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
        Vriscv_tcm_top_riscv_regfile___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__u_regfile__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile));
        Vriscv_tcm_top_riscv_tcm_top___nba_sequent__TOP__riscv_tcm_top__2((&vlSymsp->TOP__riscv_tcm_top));
        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__1((&vlSymsp->TOP__riscv_tcm_top__u_core));
        Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__1((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_exec___nba_sequent__TOP__riscv_tcm_top__u_core__u_exec__1((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
        Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__2((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__2((&vlSymsp->TOP__riscv_tcm_top__u_core));
        Vriscv_tcm_top_riscv_decode___nba_sequent__TOP__riscv_tcm_top__u_core__u_decode__3((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_exec___nba_sequent__TOP__riscv_tcm_top__u_core__u_exec__2((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
        Vriscv_tcm_top_riscv_core___nba_sequent__TOP__riscv_tcm_top__u_core__3((&vlSymsp->TOP__riscv_tcm_top__u_core));
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__0((&vlSymsp->TOP__riscv_tcm_top));
        vlSelfRef.__Vm_traceActivity[4U] = 1U;
        {
            // Inlined CFunc: _nba_comb__TOP__0
            VL_ASSIGN_SUI(32, vlSelfRef.axi_t_rdata_o, vlSymsp->TOP__riscv_tcm_top.axi_t_rdata_o);
        }
        Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__0((&vlSymsp->TOP__riscv_tcm_top__u_core));
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__1((&vlSymsp->TOP__riscv_tcm_top__u_mem_tcm));
    }
    if ((7ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vriscv_tcm_top_mem_tcm___nba_comb__TOP__riscv_tcm_top__u_mem_tcm__0((&vlSymsp->TOP__riscv_tcm_top__u_mem_tcm));
        vlSelfRef.__Vm_traceActivity[5U] = 1U;
        Vriscv_tcm_top_riscv_tcm_top___nba_comb__TOP__riscv_tcm_top__1((&vlSymsp->TOP__riscv_tcm_top));
        Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__1((&vlSymsp->TOP__riscv_tcm_top__u_core));
        Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_exec___ico_sequent__TOP__riscv_tcm_top__u_core__u_exec__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
        Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__1((&vlSymsp->TOP__riscv_tcm_top__u_core));
        Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__1((&vlSymsp->TOP__riscv_tcm_top));
        Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__1((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__2((&vlSymsp->TOP__riscv_tcm_top__u_core));
    }
    if ((5ULL & vlSelfRef.__VnbaTriggered[0U])) {
        Vriscv_tcm_top_riscv_core___nba_comb__TOP__riscv_tcm_top__u_core__4((&vlSymsp->TOP__riscv_tcm_top__u_core));
        vlSelfRef.__Vm_traceActivity[6U] = 1U;
        Vriscv_tcm_top_riscv_decode___nba_comb__TOP__riscv_tcm_top__u_core__u_decode__2((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
    }
}

void Vriscv_tcm_top___024root___trigger_orInto__act_vec_vec(VlUnpacked<QData/*63:0*/, 1> &out, const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((IData)(1U) + n);
    } while ((0U >= n));
}

void Vriscv_tcm_top___024root___trigger_clear__act(VlUnpacked<QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___trigger_clear__act\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((IData)(1U) + n);
    } while ((1U > n));
}

#ifdef VL_DEBUG
void Vriscv_tcm_top___024root___eval_debug_assertions(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_debug_assertions\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG

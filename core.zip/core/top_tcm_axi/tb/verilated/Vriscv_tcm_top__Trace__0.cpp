// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals

#include "verilated_vcd_sc.h"
#include "Vriscv_tcm_top__Syms.h"


void Vriscv_tcm_top___024root__trace_chg_0_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vriscv_tcm_top___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_chg_0\n"); );
    // Body
    Vriscv_tcm_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_tcm_top___024root*>(voidSelf);
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    Vriscv_tcm_top___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

extern const VlWide<96>/*3071:0*/ Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0;
void Vriscv_tcm_top___024root__trace_chg_dtype____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<VlWide<3>/*68:0*/, 2>& __VdtypeVar);
void Vriscv_tcm_top___024root__trace_chg_dtype____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<SData/*10:0*/, 2>& __VdtypeVar);

void Vriscv_tcm_top___024root__trace_chg_0_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_chg_0_sub_0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_3;
    VlWide<3>/*95:0*/ __Vtemp_4;
    VlWide<3>/*95:0*/ __Vtemp_6;
    VlWide<3>/*95:0*/ __Vtemp_7;
    VlWide<3>/*95:0*/ __Vtemp_9;
    VlWide<3>/*95:0*/ __Vtemp_10;
    VlWide<3>/*95:0*/ __Vtemp_11;
    IData/*31:0*/ __VExpandSel_WordIdx_1;
    IData/*31:0*/ __VExpandSel_WordIdx_2;
    IData/*31:0*/ __VExpandSel_WordIdx_3;
    IData/*31:0*/ __VExpandSel_WordIdx_4;
    IData/*31:0*/ __VExpandSel_WordIdx_5;
    IData/*31:0*/ __VExpandSel_WordIdx_6;
    IData/*31:0*/ __VExpandSel_WordIdx_7;
    IData/*31:0*/ __VExpandSel_WordIdx_8;
    IData/*31:0*/ __VExpandSel_WordIdx_9;
    IData/*31:0*/ __VExpandSel_WordIdx_10;
    IData/*31:0*/ __VExpandSel_WordIdx_11;
    IData/*31:0*/ __VExpandSel_WordIdx_12;
    // Body
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 0);
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[1U]))) {
        bufp->chgBit(oldp+0,(vlSelfRef.__Vcellinp__riscv_tcm_top__clk_i));
        bufp->chgBit(oldp+1,(vlSelfRef.__Vcellinp__riscv_tcm_top__rst_i));
        bufp->chgBit(oldp+2,(vlSelfRef.__Vcellinp__riscv_tcm_top__rst_cpu_i));
        bufp->chgBit(oldp+3,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_awready_i));
        bufp->chgBit(oldp+4,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_wready_i));
        bufp->chgBit(oldp+5,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bvalid_i));
        bufp->chgCData(oldp+6,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bresp_i),2);
        bufp->chgBit(oldp+7,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_arready_i));
        bufp->chgBit(oldp+8,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rvalid_i));
        bufp->chgIData(oldp+9,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rdata_i),32);
        bufp->chgCData(oldp+10,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rresp_i),2);
        bufp->chgBit(oldp+11,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i));
        bufp->chgIData(oldp+12,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i),32);
        bufp->chgCData(oldp+13,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awid_i),4);
        bufp->chgCData(oldp+14,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awlen_i),8);
        bufp->chgCData(oldp+15,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awburst_i),2);
        bufp->chgBit(oldp+16,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i));
        bufp->chgIData(oldp+17,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wdata_i),32);
        bufp->chgCData(oldp+18,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wstrb_i),4);
        bufp->chgBit(oldp+19,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wlast_i));
        bufp->chgBit(oldp+20,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_bready_i));
        bufp->chgBit(oldp+21,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i));
        bufp->chgIData(oldp+22,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_araddr_i),32);
        bufp->chgCData(oldp+23,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arid_i),4);
        bufp->chgCData(oldp+24,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arlen_i),8);
        bufp->chgCData(oldp+25,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arburst_i),2);
        bufp->chgBit(oldp+26,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_rready_i));
        bufp->chgBit(oldp+27,(vlSelfRef.__Vcellinp__riscv_tcm_top__intr_i));
        bufp->chgBit(oldp+28,(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_ack_w));
    }
    if (VL_UNLIKELY(((vlSelfRef.__Vm_traceActivity[1U] 
                      | vlSelfRef.__Vm_traceActivity[2U])))) {
        bufp->chgBit(oldp+29,(vlSymsp->TOP__riscv_tcm_top.axi_t_awready_o));
        bufp->chgBit(oldp+30,(vlSymsp->TOP__riscv_tcm_top.axi_t_wready_o));
        bufp->chgBit(oldp+31,(vlSymsp->TOP__riscv_tcm_top.axi_t_arready_o));
        bufp->chgIData(oldp+32,((((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_rd_q) 
                                  | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_wr_q))
                                  ? vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_addr_q
                                  : ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active)
                                      ? vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i
                                      : vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_araddr_i))),32);
        bufp->chgBit(oldp+33,(vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_rd_w));
        bufp->chgBit(oldp+34,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q) 
                               | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_ack_w))));
        bufp->chgCData(oldp+35,(vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_wr_w),4);
        bufp->chgBit(oldp+36,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active));
        bufp->chgBit(oldp+37,(((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i) 
                               & (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active))));
        bufp->chgBit(oldp+38,(((~ (IData)(vlSymsp->TOP__riscv_tcm_top.__VdfgRegularize_hebeb780c_0_9)) 
                               & (((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_wready_i) 
                                   | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__wvalid_inhibit_q)) 
                                  & ((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_awready_i) 
                                     | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__awvalid_inhibit_q))))));
        bufp->chgBit(oldp+39,(((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_arready_i) 
                               & (IData)(vlSymsp->TOP__riscv_tcm_top.axi_i_arvalid_o))));
        bufp->chgBit(oldp+40,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__req_pop_w));
        bufp->chgBit(oldp+41,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i));
    }
    if (VL_UNLIKELY((((vlSelfRef.__Vm_traceActivity[1U] 
                       | vlSelfRef.__Vm_traceActivity[3U]) 
                      | vlSelfRef.__Vm_traceActivity[5U])))) {
        bufp->chgIData(oldp+42,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_q)
                                  ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_target_q
                                  : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__branch_pc_w)),32);
        bufp->chgBit(oldp+43,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_exception_r) 
                               | ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_intr_r) 
                                  | ((1U & (IData)(
                                                   (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                    >> 0x00000026U)))
                                      ? (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w)
                                      : ((1U & (IData)(
                                                       (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                        >> 0x00000027U)))
                                          ? (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w)
                                          : ((IData)(
                                                     (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                      >> 0x00000028U)) 
                                             & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w))))))));
        bufp->chgIData(oldp+44,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_exception_r)
                                  ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                                  : ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_intr_r)
                                      ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                                      : ((1U & (IData)(
                                                       (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                        >> 0x00000026U)))
                                          ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                                          : ((1U & (IData)(
                                                           (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                            >> 0x00000027U)))
                                              ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                                              : (vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mepc_q 
                                                 & (- (IData)(
                                                              (1U 
                                                               & (IData)(
                                                                         (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                          >> 0x00000028U))))))))))),32);
        bufp->chgIData(oldp+45,(((0U != (7U & (IData)(
                                                      (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                       >> 0x00000030U))))
                                  ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_w[1U]
                                  : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_w[0U])),32);
        if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
            if ((1U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q))) {
                __Vtemp_1[0U] = 0x616e6469U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 1U)))) {
                __Vtemp_1[0U] = 0x61646469U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 2U)))) {
                __Vtemp_1[0U] = 0x736c7469U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 3U)))) {
                __Vtemp_1[0U] = 0x6c746975U;
                __Vtemp_1[1U] = 0x00000073U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 4U)))) {
                __Vtemp_1[0U] = 0x006f7269U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 5U)))) {
                __Vtemp_1[0U] = 0x786f7269U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 6U)))) {
                __Vtemp_1[0U] = 0x736c6c69U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 7U)))) {
                __Vtemp_1[0U] = 0x73726c69U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 8U)))) {
                __Vtemp_1[0U] = 0x73726169U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 9U)))) {
                __Vtemp_1[0U] = 0x006c7569U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000aU)))) {
                __Vtemp_1[0U] = 0x75697063U;
                __Vtemp_1[1U] = 0x00000061U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000bU)))) {
                __Vtemp_1[0U] = 0x00616464U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000cU)))) {
                __Vtemp_1[0U] = 0x00737562U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000dU)))) {
                __Vtemp_1[0U] = 0x00736c74U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000eU)))) {
                __Vtemp_1[0U] = 0x736c7475U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000fU)))) {
                __Vtemp_1[0U] = 0x00786f72U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000010U)))) {
                __Vtemp_1[0U] = 0x00006f72U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000011U)))) {
                __Vtemp_1[0U] = 0x00616e64U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000012U)))) {
                __Vtemp_1[0U] = 0x00736c6cU;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000013U)))) {
                __Vtemp_1[0U] = 0x0073726cU;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000014U)))) {
                __Vtemp_1[0U] = 0x00737261U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000015U)))) {
                __Vtemp_1[0U] = 0x006a616cU;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000016U)))) {
                __Vtemp_1[0U] = 0x6a616c72U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000017U)))) {
                __Vtemp_1[0U] = 0x00626571U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000018U)))) {
                __Vtemp_1[0U] = 0x00626e65U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000019U)))) {
                __Vtemp_1[0U] = 0x00626c74U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000001aU)))) {
                __Vtemp_1[0U] = 0x00626765U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000001bU)))) {
                __Vtemp_1[0U] = 0x626c7475U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000001cU)))) {
                __Vtemp_1[0U] = 0x62676575U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000001dU)))) {
                __Vtemp_1[0U] = 0x00006c62U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000001eU)))) {
                __Vtemp_1[0U] = 0x00006c68U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000001fU)))) {
                __Vtemp_1[0U] = 0x00006c77U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000020U)))) {
                __Vtemp_1[0U] = 0x006c6275U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000021U)))) {
                __Vtemp_1[0U] = 0x006c6875U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000022U)))) {
                __Vtemp_1[0U] = 0x006c7775U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000023U)))) {
                __Vtemp_1[0U] = 0x00007362U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000024U)))) {
                __Vtemp_1[0U] = 0x00007368U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000025U)))) {
                __Vtemp_1[0U] = 0x00007377U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000026U)))) {
                __Vtemp_1[0U] = 0x63616c6cU;
                __Vtemp_1[1U] = 0x00000065U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000027U)))) {
                __Vtemp_1[0U] = 0x7265616bU;
                __Vtemp_1[1U] = 0x00006562U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000028U)))) {
                __Vtemp_1[0U] = 0x65726574U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000029U)))) {
                __Vtemp_1[0U] = 0x73727277U;
                __Vtemp_1[1U] = 0x00000063U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000002aU)))) {
                __Vtemp_1[0U] = 0x73727273U;
                __Vtemp_1[1U] = 0x00000063U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000002bU)))) {
                __Vtemp_1[0U] = 0x73727263U;
                __Vtemp_1[1U] = 0x00000063U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000002cU)))) {
                __Vtemp_1[0U] = 0x72727769U;
                __Vtemp_1[1U] = 0x00006373U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000002dU)))) {
                __Vtemp_1[0U] = 0x72727369U;
                __Vtemp_1[1U] = 0x00006373U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000002eU)))) {
                __Vtemp_1[0U] = 0x72726369U;
                __Vtemp_1[1U] = 0x00006373U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000002fU)))) {
                __Vtemp_1[0U] = 0x006d756cU;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000030U)))) {
                __Vtemp_1[0U] = 0x6d756c68U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000031U)))) {
                __Vtemp_1[0U] = 0x6c687375U;
                __Vtemp_1[1U] = 0x00006d75U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000032U)))) {
                __Vtemp_1[0U] = 0x756c6875U;
                __Vtemp_1[1U] = 0x0000006dU;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000033U)))) {
                __Vtemp_1[0U] = 0x00646976U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000034U)))) {
                __Vtemp_1[0U] = 0x64697675U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000035U)))) {
                __Vtemp_1[0U] = 0x0072656dU;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000036U)))) {
                __Vtemp_1[0U] = 0x72656d75U;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000037U)))) {
                __Vtemp_1[0U] = 0x41554c54U;
                __Vtemp_1[1U] = 0x00000046U;
                __Vtemp_1[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000038U)))) {
                __Vtemp_1[0U] = 0x41554c54U;
                __Vtemp_1[1U] = 0x47455f46U;
                __Vtemp_1[2U] = 0x00005041U;
            } else {
                __Vtemp_1[0U] = 0x0000002dU;
                __Vtemp_1[1U] = 0U;
                __Vtemp_1[2U] = 0U;
            }
        } else {
            __Vtemp_1[0U] = 0x0000002dU;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        }
        bufp->chgWData(oldp+46,(__Vtemp_1),80);
        if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
            if ((0U != (0x0000003fU & ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q) 
                                       | (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x00000029U)))))) {
                __VExpandSel_WordIdx_1 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 0x0000000fU))) 
                                          >> 5U);
                __Vtemp_3[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_1];
                __Vtemp_3[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_1)];
                __Vtemp_3[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_1)];
            } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                             >> 6U))))) {
                __VExpandSel_WordIdx_2 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 0x0000000fU))) 
                                          >> 5U);
                __Vtemp_3[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_2];
                __Vtemp_3[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_2)];
                __Vtemp_3[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_2)];
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 9U)))) {
                __Vtemp_3[0U] = 0x0000002dU;
                __Vtemp_3[1U] = 0U;
                __Vtemp_3[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000aU)))) {
                __Vtemp_3[0U] = 0x00007063U;
                __Vtemp_3[1U] = 0U;
                __Vtemp_3[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000015U)))) {
                __Vtemp_3[0U] = 0x0000002dU;
                __Vtemp_3[1U] = 0U;
                __Vtemp_3[2U] = 0U;
            } else {
                __VExpandSel_WordIdx_3 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 0x0000000fU))) 
                                          >> 5U);
                __Vtemp_3[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_3];
                __Vtemp_3[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_3)];
                __Vtemp_3[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_3)];
            }
        } else {
            __Vtemp_3[0U] = 0x0000002dU;
            __Vtemp_3[1U] = 0U;
            __Vtemp_3[2U] = 0U;
        }
        __Vtemp_4[0U] = __Vtemp_3[0U];
        __Vtemp_4[1U] = __Vtemp_3[1U];
        __Vtemp_4[2U] = (0x0000ffffU & __Vtemp_3[2U]);
        bufp->chgWData(oldp+49,(__Vtemp_4),80);
        if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
            if ((0U != (0x0000003fU & ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q) 
                                       | (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x00000029U)))))) {
                __Vtemp_6[0U] = 0x0000002dU;
                __Vtemp_6[1U] = 0U;
                __Vtemp_6[2U] = 0U;
            } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                             >> 6U))))) {
                __Vtemp_6[0U] = 0x0000002dU;
                __Vtemp_6[1U] = 0U;
                __Vtemp_6[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 9U)))) {
                __Vtemp_6[0U] = 0x0000002dU;
                __Vtemp_6[1U] = 0U;
                __Vtemp_6[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000aU)))) {
                __Vtemp_6[0U] = 0x0000002dU;
                __Vtemp_6[1U] = 0U;
                __Vtemp_6[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000015U)))) {
                __Vtemp_6[0U] = 0x0000002dU;
                __Vtemp_6[1U] = 0U;
                __Vtemp_6[2U] = 0U;
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000016U)))) {
                __Vtemp_6[0U] = 0x0000002dU;
                __Vtemp_6[1U] = 0U;
                __Vtemp_6[2U] = 0U;
            } else if ((0U != (0x0000003fU & (IData)(
                                                     (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                      >> 0x0000001dU))))) {
                __Vtemp_6[0U] = 0x0000002dU;
                __Vtemp_6[1U] = 0U;
                __Vtemp_6[2U] = 0U;
            } else {
                __VExpandSel_WordIdx_4 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 0x00000014U))) 
                                          >> 5U);
                __Vtemp_6[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_4];
                __Vtemp_6[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_4)];
                __Vtemp_6[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_4)];
            }
        } else {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        }
        __Vtemp_7[0U] = __Vtemp_6[0U];
        __Vtemp_7[1U] = __Vtemp_6[1U];
        __Vtemp_7[2U] = (0x0000ffffU & __Vtemp_6[2U]);
        bufp->chgWData(oldp+52,(__Vtemp_7),80);
        if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
            if ((0U != (0x0000003fU & ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q) 
                                       | (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x00000029U)))))) {
                __VExpandSel_WordIdx_5 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 7U))) 
                                          >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_5];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_5)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_5)];
            } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                             >> 6U))))) {
                __VExpandSel_WordIdx_6 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 7U))) 
                                          >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_6];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_6)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_6)];
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 9U)))) {
                __VExpandSel_WordIdx_7 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 7U))) 
                                          >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_7];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_7)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_7)];
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x0000000aU)))) {
                __VExpandSel_WordIdx_8 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 7U))) 
                                          >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_8];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_8)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_8)];
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000015U)))) {
                __VExpandSel_WordIdx_9 = (((IData)(0x00000060U) 
                                           * (0x0000001fU 
                                              & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 7U))) 
                                          >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_9];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_9)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_9)];
            } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000016U)))) {
                __VExpandSel_WordIdx_10 = (((IData)(0x00000060U) 
                                            * (0x0000001fU 
                                               & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                  >> 7U))) 
                                           >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_10];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_10)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_10)];
            } else if ((0U != (0x0000003fU & (IData)(
                                                     (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                      >> 0x0000001dU))))) {
                __VExpandSel_WordIdx_11 = (((IData)(0x00000060U) 
                                            * (0x0000001fU 
                                               & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                  >> 7U))) 
                                           >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_11];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_11)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_11)];
            } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                             >> 0x00000023U))))) {
                __Vtemp_9[0U] = 0x0000002dU;
                __Vtemp_9[1U] = 0U;
                __Vtemp_9[2U] = 0U;
            } else {
                __VExpandSel_WordIdx_12 = (((IData)(0x00000060U) 
                                            * (0x0000001fU 
                                               & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                  >> 7U))) 
                                           >> 5U);
                __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [__VExpandSel_WordIdx_12];
                __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(1U) + __VExpandSel_WordIdx_12)];
                __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                    [((IData)(2U) + __VExpandSel_WordIdx_12)];
            }
        } else {
            __Vtemp_9[0U] = 0x0000002dU;
            __Vtemp_9[1U] = 0U;
            __Vtemp_9[2U] = 0U;
        }
        __Vtemp_10[0U] = __Vtemp_9[0U];
        __Vtemp_10[1U] = __Vtemp_9[1U];
        __Vtemp_10[2U] = (0x0000ffffU & __Vtemp_9[2U]);
        bufp->chgWData(oldp+55,(__Vtemp_10),80);
        bufp->chgIData(oldp+58,((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q 
                                 & (- (IData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r))))),32);
    }
    if (VL_UNLIKELY(((vlSelfRef.__Vm_traceActivity[1U] 
                      | vlSelfRef.__Vm_traceActivity[4U])))) {
        bufp->chgIData(oldp+59,(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w),32);
        bufp->chgCData(oldp+60,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__wb_idx_r),5);
        bufp->chgIData(oldp+61,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__wb_result_r),32);
        bufp->chgCData(oldp+62,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__addr_lsb_r),2);
        bufp->chgBit(oldp+63,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_byte_r));
        bufp->chgBit(oldp+64,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_half_r));
        bufp->chgBit(oldp+65,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_word_r));
        bufp->chgBit(oldp+66,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_signed_r));
    }
    if (VL_UNLIKELY(((vlSelfRef.__Vm_traceActivity[1U] 
                      | vlSelfRef.__Vm_traceActivity[5U])))) {
        bufp->chgIData(oldp+67,(vlSymsp->TOP__riscv_tcm_top.__PVT__icache_pc_w),32);
        bufp->chgBit(oldp+68,(vlSymsp->TOP__riscv_tcm_top.__PVT__icache_rd_w));
        bufp->chgBit(oldp+69,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_accept_w));
        bufp->chgBit(oldp+70,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__muldiv_opcode_valid_w));
        bufp->chgBit(oldp+71,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w));
        bufp->chgBit(oldp+72,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__lsu_opcode_valid_w));
        bufp->chgIData(oldp+73,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__branch_pc_w),32);
        bufp->chgBit(oldp+74,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_valid_w));
        bufp->chgBit(oldp+75,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__exec_opcode_valid_w));
        bufp->chgBit(oldp+76,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_branch_w));
        bufp->chgBit(oldp+77,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__branch_request_w));
        bufp->chgIData(oldp+78,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_rb_operand_w),32);
        bufp->chgIData(oldp+79,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_ra_operand_w),32);
        bufp->chgIData(oldp+80,(vlSymsp->TOP__riscv_tcm_top__u_core.__VdfgRegularize_hebeb780c_0_17),32);
        bufp->chgBit(oldp+81,((0U != (0x0050U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__VdfgRegularize_hebeb780c_0_17)))));
        bufp->chgIData(oldp+82,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mepc_r),32);
        bufp->chgIData(oldp+83,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcause_r),32);
        bufp->chgIData(oldp+84,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_sr_r),32);
        bufp->chgIData(oldp+85,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_r),32);
        bufp->chgIData(oldp+86,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mip_r),32);
        bufp->chgIData(oldp+87,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mie_r),32);
        bufp->chgCData(oldp+88,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mpriv_r),2);
        bufp->chgIData(oldp+89,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mscratch_r),32);
        bufp->chgBit(oldp+90,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_intr_r));
        bufp->chgBit(oldp+91,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_exception_r));
        bufp->chgIData(oldp+92,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__data_r),32);
        bufp->chgIData(oldp+93,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__result_r),32);
        bufp->chgBit(oldp+94,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__valid_unit_inst_w));
        bufp->chgBit(oldp+95,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__stall_w));
        bufp->chgBit(oldp+96,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_w));
        bufp->chgIData(oldp+97,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_pc_w),32);
        bufp->chgIData(oldp+98,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_r),32);
        bufp->chgBit(oldp+99,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_unaligned_r));
        bufp->chgWData(oldp+100,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_w),65);
        bufp->chgQData(oldp+103,((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_21)) 
                                   << 0x00000020U) 
                                  | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_rb_operand_w)))),33);
        bufp->chgQData(oldp+105,((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_22)) 
                                   << 0x00000020U) 
                                  | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_ra_operand_w)))),33);
        bufp->chgBit(oldp+107,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_start_w));
        bufp->chgSData(oldp+108,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_addr_w),14);
        bufp->chgIData(oldp+109,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_data_w),32);
        bufp->chgCData(oldp+110,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_wr_w),4);
        bufp->chgIData(oldp+111,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__alu_input_a_r),32);
        bufp->chgIData(oldp+112,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__alu_input_b_r),32);
        bufp->chgIData(oldp+113,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__less_than_signed__Vstatic__v),32);
        bufp->chgIData(oldp+114,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__greater_than_signed__Vstatic__v),32);
        bufp->chgBit(oldp+115,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__branch_r));
        bufp->chgIData(oldp+116,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__result_r),32);
        bufp->chgSData(oldp+117,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_fill_r),16);
        bufp->chgIData(oldp+118,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_1_r),32);
        bufp->chgIData(oldp+119,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_2_r),32);
        bufp->chgIData(oldp+120,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_4_r),32);
        bufp->chgIData(oldp+121,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_8_r),32);
        bufp->chgIData(oldp+122,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_1_r),32);
        bufp->chgIData(oldp+123,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_2_r),32);
        bufp->chgIData(oldp+124,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_4_r),32);
        bufp->chgIData(oldp+125,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_8_r),32);
        bufp->chgIData(oldp+126,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__sub_res_w),32);
        bufp->chgBit(oldp+127,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__stall_scoreboard_r));
        bufp->chgBit(oldp+128,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__stall_input_w));
        bufp->chgIData(oldp+129,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__scoreboard_r),32);
        bufp->chgBit(oldp+130,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r));
        bufp->chgIData(oldp+131,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__current_scoreboard_r),32);
        bufp->chgIData(oldp+132,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__dbg_inst_imm),32);
        bufp->chgSData(oldp+133,((0x00003fffU & (vlSymsp->TOP__riscv_tcm_top.__PVT__icache_pc_w 
                                                 >> 2U))),14);
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[2U]))) {
        bufp->chgBit(oldp+134,(vlSymsp->TOP__riscv_tcm_top.axi_i_awvalid_o));
        bufp->chgIData(oldp+135,(vlSymsp->TOP__riscv_tcm_top.axi_i_awaddr_o),32);
        bufp->chgBit(oldp+136,(vlSymsp->TOP__riscv_tcm_top.axi_i_wvalid_o));
        bufp->chgIData(oldp+137,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                                 [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][1U]),32);
        bufp->chgCData(oldp+138,((0x0000000fU & vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                                  [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][2U])),4);
        bufp->chgBit(oldp+139,((1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)))));
        bufp->chgBit(oldp+140,(vlSymsp->TOP__riscv_tcm_top.axi_i_arvalid_o));
        bufp->chgBit(oldp+141,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__bvalid_q));
        bufp->chgCData(oldp+142,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_id_q),4);
        bufp->chgBit(oldp+143,(vlSymsp->TOP__riscv_tcm_top.axi_t_rvalid_o));
        bufp->chgBit(oldp+144,(vlSymsp->TOP__riscv_tcm_top.axi_t_rlast_o));
        bufp->chgSData(oldp+145,(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w),11);
        bufp->chgBit(oldp+146,(((2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)) 
                                & (2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))));
        bufp->chgSData(oldp+147,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q
                                 [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q]),11);
        bufp->chgBit(oldp+148,((1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)))));
        bufp->chgIData(oldp+149,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__calculate_addr_next__Vstatic__mask),32);
        bufp->chgCData(oldp+150,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_len_q),8);
        bufp->chgIData(oldp+151,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_addr_q),32);
        bufp->chgBit(oldp+152,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_rd_q));
        bufp->chgBit(oldp+153,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_wr_q));
        bufp->chgCData(oldp+154,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_axburst_q),2);
        bufp->chgCData(oldp+155,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_axlen_q),8);
        bufp->chgBit(oldp+156,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rvalid_q));
        bufp->chgBit(oldp+157,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rlast_q));
        bufp->chgBit(oldp+158,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rbuf_valid_q));
        bufp->chgIData(oldp+159,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rbuf_data_q),32);
        bufp->chgBit(oldp+160,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rbuf_last_q));
        bufp->chgBit(oldp+161,((2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q))));
        bufp->chgBit(oldp+162,((2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q))));
        bufp->chgBit(oldp+163,((0U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q))));
        bufp->chgWData(oldp+164,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                                 [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q]),69);
        bufp->chgBit(oldp+167,((1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top.__VdfgRegularize_hebeb780c_0_9)))));
        bufp->chgBit(oldp+168,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__awvalid_inhibit_q));
        bufp->chgBit(oldp+169,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__wvalid_inhibit_q));
        Vriscv_tcm_top___024root__trace_chg_dtype____0(vlSelf, bufp, 170, vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q);
        bufp->chgBit(oldp+176,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q));
        bufp->chgBit(oldp+177,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q));
        bufp->chgCData(oldp+178,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q),2);
        bufp->chgBit(oldp+179,((0U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q))));
        Vriscv_tcm_top___024root__trace_chg_dtype____1(vlSelf, bufp, 180, vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q);
        bufp->chgBit(oldp+182,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q));
        bufp->chgBit(oldp+183,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q));
        bufp->chgCData(oldp+184,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q),2);
        bufp->chgBit(oldp+185,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q));
        bufp->chgSData(oldp+186,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_tag_q),11);
        bufp->chgBit(oldp+187,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q));
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[3U]))) {
        bufp->chgSData(oldp+188,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_req_tag_q),11);
        bufp->chgBit(oldp+189,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_invalidate_q) 
                                | (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ifence_q))));
        bufp->chgBit(oldp+190,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_flush_q));
        bufp->chgBit(oldp+191,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_invalidate_q));
        bufp->chgCData(oldp+192,(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_wr_w),4);
        bufp->chgBit(oldp+193,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_rd_q));
        bufp->chgIData(oldp+194,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q),32);
        bufp->chgIData(oldp+195,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q),32);
        bufp->chgBit(oldp+196,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_cacheable_q));
        bufp->chgBit(oldp+197,(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_rd_w));
        bufp->chgCData(oldp+198,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q),4);
        __Vtemp_11[0U] = (IData)((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                   << 0x00000020U) 
                                  | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
        __Vtemp_11[1U] = (IData)(((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                    << 0x00000020U) 
                                   | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))) 
                                  >> 0x00000020U));
        __Vtemp_11[2U] = (((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_rd_w) 
                           << 4U) | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_wr_w));
        bufp->chgWData(oldp+199,(__Vtemp_11),69);
        bufp->chgBit(oldp+202,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ifence_q));
        bufp->chgBit(oldp+203,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_stall_w));
        bufp->chgQData(oldp+204,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q),58);
        bufp->chgIData(oldp+206,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_pc_w),32);
        bufp->chgCData(oldp+207,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__wb_rd_q),5);
        bufp->chgBit(oldp+208,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_unaligned_st_q));
        bufp->chgBit(oldp+209,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_q));
        bufp->chgCData(oldp+210,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q),5);
        bufp->chgIData(oldp+211,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q),32);
        bufp->chgBit(oldp+212,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_squash_q));
        bufp->chgBit(oldp+213,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__muldiv_stall_w));
        bufp->chgCData(oldp+214,((0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 0x0000000fU))),5);
        bufp->chgCData(oldp+215,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__writeback_csr_idx_w),5);
        bufp->chgCData(oldp+216,((0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 7U))),5);
        bufp->chgIData(oldp+217,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q),32);
        bufp->chgCData(oldp+218,((0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                 >> 0x00000014U))),5);
        bufp->chgBit(oldp+219,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_unaligned_ld_q));
        bufp->chgIData(oldp+220,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__wb_result_q),32);
        bufp->chgIData(oldp+221,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__result_q),32);
        bufp->chgIData(oldp+222,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_target_q),32);
        bufp->chgIData(oldp+223,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_value_q),32);
        bufp->chgIData(oldp+224,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mepc_q),32);
        bufp->chgIData(oldp+225,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcause_q),32);
        bufp->chgIData(oldp+226,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_sr_q),32);
        bufp->chgIData(oldp+227,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q),32);
        bufp->chgIData(oldp+228,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mip_q),32);
        bufp->chgIData(oldp+229,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mie_q),32);
        bufp->chgCData(oldp+230,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mpriv_q),2);
        bufp->chgIData(oldp+231,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcycle_q),32);
        bufp->chgIData(oldp+232,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mscratch_q),32);
        bufp->chgIData(oldp+233,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__pc_m_q),32);
        bufp->chgIData(oldp+234,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r),32);
        bufp->chgCData(oldp+235,((3U & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                        >> 0x0000001cU))),2);
        bufp->chgBit(oldp+236,((3U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                       >> 0x0000001eU))));
        bufp->chgBit(oldp+237,((1U & (IData)(((0ULL 
                                               != (0x0000120000000000ULL 
                                                   & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)) 
                                              | (0U 
                                                 != 
                                                 (0x000f8000U 
                                                  & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q)))))));
        bufp->chgBit(oldp+238,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__set_r));
        bufp->chgBit(oldp+239,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__clr_r));
        bufp->chgIData(oldp+240,(((IData)(1U) + vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcycle_q)),32);
        bufp->chgBit(oldp+241,((0U != (0x0000003fU 
                                       & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x0000001dU))))));
        bufp->chgBit(oldp+242,((0U != (7U & (IData)(
                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                     >> 0x00000023U))))));
        bufp->chgIData(oldp+243,((vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mip_q 
                                  & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mie_q)),32);
        bufp->chgIData(oldp+244,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__irq_masked_r),32);
        bufp->chgBit(oldp+245,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_en_q));
        bufp->chgCData(oldp+246,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_idx_q),5);
        bufp->chgBit(oldp+247,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__reset_q));
        bufp->chgBit(oldp+248,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__active_q));
        bufp->chgIData(oldp+249,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__fetch_pc_q),32);
        bufp->chgIData(oldp+250,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_pc_q),32);
        bufp->chgBit(oldp+251,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_valid_q));
        bufp->chgBit(oldp+252,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_fetch_q));
        bufp->chgBit(oldp+253,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_invalidate_q));
        bufp->chgQData(oldp+254,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__skid_buffer_q),64);
        bufp->chgBit(oldp+256,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__skid_valid_q));
        bufp->chgIData(oldp+257,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__pc_d_q),32);
        bufp->chgBit(oldp+258,((0U != (7U & (IData)(
                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                     >> 0x0000001dU))))));
        bufp->chgBit(oldp+259,(((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                         >> 0x00000029U)) 
                                & (0x03a0U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                               >> 0x00000014U)))));
        bufp->chgBit(oldp+260,(((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                         >> 0x00000029U)) 
                                & (0x03a1U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                               >> 0x00000014U)))));
        bufp->chgBit(oldp+261,(((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                         >> 0x00000029U)) 
                                & (0x03a2U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                               >> 0x00000014U)))));
        bufp->chgCData(oldp+262,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__rd_q),5);
        bufp->chgIData(oldp+263,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_q),32);
        bufp->chgBit(oldp+264,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_busy_q));
        bufp->chgBit(oldp+265,((0U != (0x0000000fU 
                                       & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x0000002fU))))));
        bufp->chgBit(oldp+266,((0U != (0x0000000fU 
                                       & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x00000033U))))));
        bufp->chgBit(oldp+267,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__signed_operation_w));
        bufp->chgBit(oldp+268,((0U != (3U & (IData)(
                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                     >> 0x00000033U))))));
        bufp->chgIData(oldp+269,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__dividend_q),32);
        bufp->chgQData(oldp+270,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__divisor_q),63);
        bufp->chgIData(oldp+272,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__quotient_q),32);
        bufp->chgIData(oldp+273,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__q_mask_q),32);
        bufp->chgBit(oldp+274,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_inst_q));
        bufp->chgBit(oldp+275,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_busy_q));
        bufp->chgBit(oldp+276,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__invert_res_q));
        bufp->chgBit(oldp+277,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_complete_w));
        bufp->chgIData(oldp+278,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_inst_q)
                                   ? ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__invert_res_q)
                                       ? (- vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__quotient_q)
                                       : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__quotient_q)
                                   : ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__invert_res_q)
                                       ? (- vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__dividend_q)
                                       : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__dividend_q))),32);
        bufp->chgBit(oldp+279,((0x80000000U <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q)));
        bufp->chgIData(oldp+280,((0xfffff000U & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q)),32);
        bufp->chgIData(oldp+281,((((- (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                               >> 0x0000001fU))) 
                                   << 0x0000000dU) 
                                  | ((((2U & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 0x0000001eU)) 
                                       | (1U & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                >> 7U))) 
                                      << 0x0000000bU) 
                                     | ((0x000007e0U 
                                         & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                            >> 0x00000014U)) 
                                        | (0x0000001eU 
                                           & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 7U)))))),32);
        bufp->chgIData(oldp+282,((((- (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                               >> 0x0000001fU))) 
                                   << 0x00000014U) 
                                  | ((((0x000001feU 
                                        & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                           >> 0x0000000bU)) 
                                       | (1U & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                >> 0x00000014U))) 
                                      << 0x0000000bU) 
                                     | (0x000007feU 
                                        & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                           >> 0x00000014U))))),32);
        bufp->chgIData(oldp+283,((((- (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                               >> 0x0000001fU))) 
                                   << 0x0000000cU) 
                                  | ((0x00000fe0U & 
                                      (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                       >> 0x00000014U)) 
                                     | (0x0000001fU 
                                        & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                           >> 7U))))),32);
        bufp->chgCData(oldp+284,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__alu_func_r),4);
        bufp->chgBit(oldp+285,((1U & (IData)(((0ULL 
                                               != (0x0000000000649fffULL 
                                                   & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)) 
                                              | (0U 
                                                 != 
                                                 (3U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                              >> 0x0000000dU)) 
                                                     | ((IData)(
                                                                (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                 >> 0x00000010U)) 
                                                        | (IData)(
                                                                  (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                   >> 0x00000013U)))))))))));
        bufp->chgBit(oldp+286,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__v_dbg_valid_q));
        bufp->chgIData(oldp+287,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__v_dbg_pc_q),32);
        bufp->chgBit(oldp+288,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__valid_q));
        bufp->chgIData(oldp+289,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__scoreboard_q),32);
        bufp->chgIData(oldp+290,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ra_value_w),32);
        bufp->chgIData(oldp+291,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__rb_value_w),32);
        bufp->chgCData(oldp+292,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__wb_csr_rd_w),5);
        bufp->chgBit(oldp+293,((IData)((0ULL != (0x007ffe07e0000000ULL 
                                                 & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)))));
        bufp->chgIData(oldp+294,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r1_q),32);
        bufp->chgIData(oldp+295,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r2_q),32);
        bufp->chgIData(oldp+296,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r3_q),32);
        bufp->chgIData(oldp+297,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r4_q),32);
        bufp->chgIData(oldp+298,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r5_q),32);
        bufp->chgIData(oldp+299,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r6_q),32);
        bufp->chgIData(oldp+300,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r7_q),32);
        bufp->chgIData(oldp+301,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r8_q),32);
        bufp->chgIData(oldp+302,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r9_q),32);
        bufp->chgIData(oldp+303,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r10_q),32);
        bufp->chgIData(oldp+304,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r11_q),32);
        bufp->chgIData(oldp+305,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r12_q),32);
        bufp->chgIData(oldp+306,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r13_q),32);
        bufp->chgIData(oldp+307,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r14_q),32);
        bufp->chgIData(oldp+308,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r15_q),32);
        bufp->chgIData(oldp+309,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r16_q),32);
        bufp->chgIData(oldp+310,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r17_q),32);
        bufp->chgIData(oldp+311,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r18_q),32);
        bufp->chgIData(oldp+312,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r19_q),32);
        bufp->chgIData(oldp+313,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r20_q),32);
        bufp->chgIData(oldp+314,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r21_q),32);
        bufp->chgIData(oldp+315,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r22_q),32);
        bufp->chgIData(oldp+316,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r23_q),32);
        bufp->chgIData(oldp+317,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r24_q),32);
        bufp->chgIData(oldp+318,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r25_q),32);
        bufp->chgIData(oldp+319,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r26_q),32);
        bufp->chgIData(oldp+320,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r27_q),32);
        bufp->chgIData(oldp+321,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r28_q),32);
        bufp->chgIData(oldp+322,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r29_q),32);
        bufp->chgIData(oldp+323,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r30_q),32);
        bufp->chgIData(oldp+324,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r31_q),32);
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[5U]))) {
        bufp->chgBit(oldp+325,(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_accept_w));
        bufp->chgBit(oldp+326,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__req_push_w));
        bufp->chgBit(oldp+327,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__res_push_w));
        bufp->chgBit(oldp+328,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__lsu_stall_w));
        bufp->chgBit(oldp+329,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_busy_w));
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[6U]))) {
        bufp->chgIData(oldp+330,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w),32);
        bufp->chgQData(oldp+331,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_w),58);
        bufp->chgBit(oldp+333,(((0x10500073U == (0xffff8fffU 
                                                 & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)) 
                                | ((0x0000000fU == 
                                    (0x0000707fU & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)) 
                                   | ((0x12000073U 
                                       == (0xfe007fffU 
                                           & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)) 
                                      | (0x0000100fU 
                                         == (0x0000707fU 
                                             & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)))))));
        bufp->chgBit(oldp+334,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__invalid_inst_w));
    }
    bufp->chgIData(oldp+335,(vlSymsp->TOP__riscv_tcm_top.axi_t_rdata_o),32);
    bufp->chgIData(oldp+336,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read1_q),32);
    bufp->chgIData(oldp+337,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read0_q),32);
    bufp->chgBit(oldp+338,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_i_valid_q));
}

void Vriscv_tcm_top___024root__trace_chg_dtype____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<VlWide<3>/*68:0*/, 2>& __VdtypeVar) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_chg_dtype____0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode +  offset);
    bufp->chgWData(oldp+0,(__VdtypeVar[1]),69);
    bufp->chgWData(oldp+3,(__VdtypeVar[0]),69);
}

void Vriscv_tcm_top___024root__trace_chg_dtype____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<SData/*10:0*/, 2>& __VdtypeVar) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_chg_dtype____1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode +  offset);
    bufp->chgSData(oldp+0,(__VdtypeVar[1]),11);
    bufp->chgSData(oldp+1,(__VdtypeVar[0]),11);
}

void Vriscv_tcm_top___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_cleanup\n"); );
    // Body
    Vriscv_tcm_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_tcm_top___024root*>(voidSelf);
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[4U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[5U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[6U] = 0U;
}

// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

VL_ATTR_COLD void Vriscv_tcm_top_riscv_tcm_top___eval_static__TOP__riscv_tcm_top(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
VL_ATTR_COLD void Vriscv_tcm_top_riscv_exec___eval_static__TOP__riscv_tcm_top__u_core__u_exec(Vriscv_tcm_top_riscv_exec* vlSelf);

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_static(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_static\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vriscv_tcm_top_riscv_tcm_top___eval_static__TOP__riscv_tcm_top((&vlSymsp->TOP__riscv_tcm_top));
    {
        // Inlined CFunc: __Vm_traceActivitySetAll
        vlSelfRef.__Vm_traceActivity[0U] = 1U;
        vlSelfRef.__Vm_traceActivity[1U] = 1U;
        vlSelfRef.__Vm_traceActivity[2U] = 1U;
        vlSelfRef.__Vm_traceActivity[3U] = 1U;
        vlSelfRef.__Vm_traceActivity[4U] = 1U;
        vlSelfRef.__Vm_traceActivity[5U] = 1U;
        vlSelfRef.__Vm_traceActivity[6U] = 1U;
    }
    Vriscv_tcm_top_riscv_exec___eval_static__TOP__riscv_tcm_top__u_core__u_exec((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
    vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__clk_i__0 
        = vlSelfRef.__Vcellinp__riscv_tcm_top__clk_i;
    vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_i__0 
        = vlSelfRef.__Vcellinp__riscv_tcm_top__rst_i;
    vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_cpu_i__0 
        = vlSelfRef.__Vcellinp__riscv_tcm_top__rst_cpu_i;
}

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_initial(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_initial\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    {
        // Inlined CFunc: _eval_initial__TOP
        VL_ASSIGN_SUI(2, vlSelfRef.axi_t_rresp_o, 0U);
        VL_ASSIGN_SUI(2, vlSelfRef.axi_t_bresp_o, 0U);
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vriscv_tcm_top___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in);
VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_body__stl(Vriscv_tcm_top___024root* vlSelf);

VL_ATTR_COLD bool Vriscv_tcm_top___024root___eval_stl(Vriscv_tcm_top___024root* vlSelf, CData/*0:0*/ firstIteration) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_stl\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VstlExecute;
    // Body
    vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VstlTriggered[0U]) 
                                     | (IData)((IData)(firstIteration)));
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vriscv_tcm_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = Vriscv_tcm_top___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        Vriscv_tcm_top___024root___eval_body__stl(vlSelf);
    }
    return (__VstlExecute);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_dump_triggers__stl(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_dump_triggers__stl\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vriscv_tcm_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_dump_triggers__ico(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_dump_triggers__ico\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vriscv_tcm_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag);
#endif  // VL_DEBUG

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_dump_triggers__act(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_dump_triggers__act\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vriscv_tcm_top___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
}

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_dump_triggers__nba(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_dump_triggers__nba\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vriscv_tcm_top___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
}

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_dump_triggers__obs(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_dump_triggers__obs\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_dump_triggers__react(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_dump_triggers__react\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_final(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_final\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__stl(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(Vriscv_tcm_top___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool Vriscv_tcm_top___024root___trigger_anySet__stl(const VlUnpacked<QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___trigger_anySet__stl\n"); );
    // Locals
    IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

VL_ATTR_COLD void Vriscv_tcm_top_riscv_core___stl_sequent__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top_riscv_core* vlSelf);
VL_ATTR_COLD void Vriscv_tcm_top_riscv_tcm_top___stl_sequent__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
VL_ATTR_COLD void Vriscv_tcm_top_riscv_exec___stl_sequent__TOP__riscv_tcm_top__u_core__u_exec__0(Vriscv_tcm_top_riscv_exec* vlSelf);
VL_ATTR_COLD void Vriscv_tcm_top_riscv_decode___stl_sequent__TOP__riscv_tcm_top__u_core__u_decode__0(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_mem_tcm___nba_comb__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top_mem_tcm* vlSelf);
VL_ATTR_COLD void Vriscv_tcm_top_riscv_core___stl_sequent__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__0(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_exec___ico_sequent__TOP__riscv_tcm_top__u_core__u_exec__0(Vriscv_tcm_top_riscv_exec* vlSelf);
void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__1(Vriscv_tcm_top_riscv_core* vlSelf);
void Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__1(Vriscv_tcm_top_riscv_tcm_top* vlSelf);
void Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__1(Vriscv_tcm_top_riscv_decode* vlSelf);
void Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__2(Vriscv_tcm_top_riscv_core* vlSelf);

VL_ATTR_COLD void Vriscv_tcm_top___024root___eval_body__stl(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___eval_body__stl\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered[0U])) {
        {
            // Inlined CFunc: _stl_sequent__TOP__0
            VL_ASSIGN_SUI(4, vlSelfRef.axi_t_rid_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_id_q);
            VL_ASSIGN_SUI(4, vlSelfRef.axi_t_bid_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_id_q);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_bvalid_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__bvalid_q);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_rready_o, 
                          (1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q))));
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_bready_o, 
                          (1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q))));
            VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arburst_i, vlSelfRef.axi_t_arburst_i);
            VL_ASSIGN_ISU(8, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arlen_i, vlSelfRef.axi_t_arlen_i);
            VL_ASSIGN_ISU(4, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arid_i, vlSelfRef.axi_t_arid_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wlast_i, vlSelfRef.axi_t_wlast_i);
            VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awburst_i, vlSelfRef.axi_t_awburst_i);
            VL_ASSIGN_ISU(8, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awlen_i, vlSelfRef.axi_t_awlen_i);
            VL_ASSIGN_ISU(4, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awid_i, vlSelfRef.axi_t_awid_i);
            VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rresp_i, vlSelfRef.axi_i_rresp_i);
            VL_ASSIGN_ISU(2, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bresp_i, vlSelfRef.axi_i_bresp_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__rst_cpu_i, vlSelfRef.rst_cpu_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__rst_i, vlSelfRef.rst_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__clk_i, vlSelfRef.clk_i);
            VL_ASSIGN_SUI(4, vlSelfRef.axi_i_wstrb_o, 
                          (0x0000000fU & vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                           [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][2U]));
            VL_ASSIGN_SUI(32, vlSelfRef.axi_i_wdata_o, vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                          [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][1U]);
            VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wdata_i, vlSelfRef.axi_t_wdata_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_arready_i, vlSelfRef.axi_i_arready_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_wready_i, vlSelfRef.axi_i_wready_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_awready_i, vlSelfRef.axi_i_awready_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_rready_i, vlSelfRef.axi_t_rready_i);
            VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_araddr_i, vlSelfRef.axi_t_araddr_i);
            VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i, vlSelfRef.axi_t_awaddr_i);
            VL_ASSIGN_ISU(4, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wstrb_i, vlSelfRef.axi_t_wstrb_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i, vlSelfRef.axi_t_wvalid_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i, vlSelfRef.axi_t_arvalid_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_bready_i, vlSelfRef.axi_t_bready_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__intr_i, vlSelfRef.intr_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i, vlSelfRef.axi_t_awvalid_i);
            VL_ASSIGN_ISU(32, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rdata_i, vlSelfRef.axi_i_rdata_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rvalid_i, vlSelfRef.axi_i_rvalid_i);
            VL_ASSIGN_ISI(1, vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bvalid_i, vlSelfRef.axi_i_bvalid_i);
        }
        {
            // Inlined CFunc: __Vm_traceActivitySetAll
            vlSelfRef.__Vm_traceActivity[0U] = 1U;
            vlSelfRef.__Vm_traceActivity[1U] = 1U;
            vlSelfRef.__Vm_traceActivity[2U] = 1U;
            vlSelfRef.__Vm_traceActivity[3U] = 1U;
            vlSelfRef.__Vm_traceActivity[4U] = 1U;
            vlSelfRef.__Vm_traceActivity[5U] = 1U;
            vlSelfRef.__Vm_traceActivity[6U] = 1U;
        }
        Vriscv_tcm_top_riscv_core___stl_sequent__TOP__riscv_tcm_top__u_core__0((&vlSymsp->TOP__riscv_tcm_top__u_core));
        Vriscv_tcm_top_riscv_tcm_top___stl_sequent__TOP__riscv_tcm_top__0((&vlSymsp->TOP__riscv_tcm_top));
        Vriscv_tcm_top_riscv_exec___stl_sequent__TOP__riscv_tcm_top__u_core__u_exec__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
        Vriscv_tcm_top_riscv_decode___stl_sequent__TOP__riscv_tcm_top__u_core__u_decode__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_mem_tcm___nba_comb__TOP__riscv_tcm_top__u_mem_tcm__0((&vlSymsp->TOP__riscv_tcm_top__u_mem_tcm));
        {
            // Inlined CFunc: _stl_sequent__TOP__1
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_rlast_o, vlSymsp->TOP__riscv_tcm_top.axi_t_rlast_o);
            VL_ASSIGN_SUI(32, vlSelfRef.axi_t_rdata_o, vlSymsp->TOP__riscv_tcm_top.axi_t_rdata_o);
            VL_ASSIGN_SUI(32, vlSelfRef.axi_i_araddr_o, vlSymsp->TOP__riscv_tcm_top.axi_i_awaddr_o);
            VL_ASSIGN_SUI(32, vlSelfRef.axi_i_awaddr_o, vlSymsp->TOP__riscv_tcm_top.axi_i_awaddr_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_rvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_t_rvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_arvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_i_arvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_wready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_wready_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_awready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_awready_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_wvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_i_wvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_i_awvalid_o, vlSymsp->TOP__riscv_tcm_top.axi_i_awvalid_o);
            VL_ASSIGN_SII(1, vlSelfRef.axi_t_arready_o, vlSymsp->TOP__riscv_tcm_top.axi_t_arready_o);
        }
        Vriscv_tcm_top_riscv_core___stl_sequent__TOP__riscv_tcm_top__u_core__1((&vlSymsp->TOP__riscv_tcm_top__u_core));
        Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_exec___ico_sequent__TOP__riscv_tcm_top__u_core__u_exec__0((&vlSymsp->TOP__riscv_tcm_top__u_core__u_exec));
        Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__1((&vlSymsp->TOP__riscv_tcm_top__u_core));
        Vriscv_tcm_top_riscv_tcm_top___ico_sequent__TOP__riscv_tcm_top__1((&vlSymsp->TOP__riscv_tcm_top));
        Vriscv_tcm_top_riscv_decode___ico_sequent__TOP__riscv_tcm_top__u_core__u_decode__1((&vlSymsp->TOP__riscv_tcm_top__u_core__u_decode));
        Vriscv_tcm_top_riscv_core___ico_sequent__TOP__riscv_tcm_top__u_core__2((&vlSymsp->TOP__riscv_tcm_top__u_core));
    }
}

bool Vriscv_tcm_top___024root___trigger_anySet__ico(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__ico(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___dump_triggers__ico\n"); );
    // Body
    if ((1U & (~ (IData)(Vriscv_tcm_top___024root___trigger_anySet__ico(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

bool Vriscv_tcm_top___024root___trigger_anySet__act(const VlUnpacked<QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vriscv_tcm_top___024root___dump_triggers__act(const VlUnpacked<QData/*63:0*/, 1> &triggers, const std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(Vriscv_tcm_top___024root___trigger_anySet__act(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @(posedge __Vcellinp__riscv_tcm_top__clk_i)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @(posedge __Vcellinp__riscv_tcm_top__rst_i)\n");
    }
    if ((1U & (IData)((triggers[0U] >> 2U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 2 is active: @(posedge __Vcellinp__riscv_tcm_top__rst_cpu_i)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vriscv_tcm_top___024root___ctor_var_reset(Vriscv_tcm_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root___ctor_var_reset\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelf->__Vcellinp__riscv_tcm_top__intr_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_rready_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_arburst_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_arlen_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_arid_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_araddr_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_arvalid_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_bready_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_wlast_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_wstrb_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_wdata_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_wvalid_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_awburst_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_awlen_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_awid_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_awaddr_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_t_awvalid_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_rresp_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_rdata_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_rvalid_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_arready_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_bresp_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_bvalid_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_wready_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__axi_i_awready_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__rst_cpu_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__rst_i = 0;
    vlSelf->__Vcellinp__riscv_tcm_top__clk_i = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VicoTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggered[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__clk_i__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_i__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP____Vcellinp__riscv_tcm_top__rst_cpu_i__0 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VnbaTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 7; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = 0;
    }
}

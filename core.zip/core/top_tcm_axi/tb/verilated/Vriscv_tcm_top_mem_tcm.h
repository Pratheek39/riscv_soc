// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vriscv_tcm_top.h for the primary calling header

#ifndef VERILATED_VRISCV_TCM_TOP_MEM_TCM_H_
#define VERILATED_VRISCV_TCM_TOP_MEM_TCM_H_  // guard

#include "verilated.h"
class Vriscv_tcm_top_ram_dp_64k;


class Vriscv_tcm_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vriscv_tcm_top_mem_tcm final {
  public:
    // CELLS
    Vriscv_tcm_top_ram_dp_64k* u_ram;

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ __PVT__clk_i;
    CData/*0:0*/ __PVT__rst_i;
    CData/*0:0*/ __PVT__mem_d_rd_i;
    CData/*3:0*/ __PVT__mem_d_wr_i;
    CData/*0:0*/ __PVT__mem_d_cacheable_i;
    CData/*0:0*/ __PVT__mem_d_invalidate_i;
    CData/*0:0*/ __PVT__mem_d_flush_i;
    CData/*0:0*/ __PVT__mem_i_rd_i;
    CData/*0:0*/ __PVT__mem_i_flush_i;
    CData/*0:0*/ __PVT__mem_i_invalidate_i;
    CData/*3:0*/ __PVT__ext_wr_i;
    CData/*0:0*/ __PVT__ext_rd_i;
    CData/*0:0*/ __PVT__mem_out_accept_i;
    CData/*0:0*/ __PVT__mem_out_ack_i;
    CData/*0:0*/ __PVT__mem_d_accept_o;
    CData/*0:0*/ __PVT__mem_d_ack_o;
    CData/*0:0*/ __PVT__mem_i_accept_o;
    CData/*0:0*/ __PVT__mem_i_valid_o;
    CData/*0:0*/ __PVT__ext_accept_o;
    CData/*0:0*/ __PVT__mem_out_rd_o;
    CData/*3:0*/ __PVT__mem_out_wr_o;
    CData/*0:0*/ __PVT__mem_out_cacheable_o;
    CData/*0:0*/ __PVT__mem_out_invalidate_o;
    CData/*0:0*/ __PVT__mem_out_flush_o;
    CData/*0:0*/ __PVT__mem_out_resp_accept_o;
    CData/*3:0*/ __PVT__muxed_wr_w;
    CData/*0:0*/ __PVT__mem_i_valid_q;
    CData/*0:0*/ __PVT__mem_d_accept_q;
    CData/*0:0*/ __PVT__mem_d_ack_q;
    SData/*10:0*/ __PVT__mem_d_req_tag_i;
    SData/*10:0*/ __PVT__mem_out_resp_tag_i;
    SData/*10:0*/ __PVT__mem_d_resp_tag_o;
    SData/*10:0*/ __PVT__mem_out_req_tag_o;
    SData/*13:0*/ __PVT__muxed_addr_w;
    SData/*10:0*/ __PVT__mem_d_tag_q;
    IData/*31:0*/ __PVT__mem_d_addr_i;
    IData/*31:0*/ __PVT__mem_d_data_wr_i;
    IData/*31:0*/ __PVT__mem_i_pc_i;
    IData/*31:0*/ __PVT__ext_addr_i;
    IData/*31:0*/ __PVT__ext_write_data_i;
    IData/*31:0*/ __PVT__mem_out_data_rd_i;
    IData/*31:0*/ __PVT__mem_d_data_rd_o;
    IData/*31:0*/ __PVT__mem_i_inst_o;
    IData/*31:0*/ __PVT__ext_read_data_o;
    IData/*31:0*/ __PVT__mem_out_addr_o;
    IData/*31:0*/ __PVT__mem_out_data_wr_o;
    IData/*31:0*/ __PVT__muxed_data_w;

    // INTERNAL VARIABLES
    Vriscv_tcm_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vriscv_tcm_top_mem_tcm();
    ~Vriscv_tcm_top_mem_tcm();
    void ctor(Vriscv_tcm_top__Syms* symsp, const char* namep);
    void dtor();
    VL_UNCOPYABLE(Vriscv_tcm_top_mem_tcm);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
    uint32_t read(uint32_t addr);
    bool write(uint32_t addr, uint32_t data);
};


#endif  // guard

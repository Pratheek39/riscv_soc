// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

VL_ATTR_COLD void Vriscv_tcm_top_riscv_tcm_top___eval_static__TOP__riscv_tcm_top(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___eval_static__TOP__riscv_tcm_top\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelfRef.__PVT__u_axi_conv__DOT__calculate_addr_next__Vstatic__mask = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 11557797706019011974ull);
}

VL_ATTR_COLD void Vriscv_tcm_top_riscv_tcm_top___stl_sequent__TOP__riscv_tcm_top__0(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___stl_sequent__TOP__riscv_tcm_top__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    CData/*0:0*/ __VdfgRegularize_hebeb780c_0_10;
    __VdfgRegularize_hebeb780c_0_10 = 0;
    // Body
    if (vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_valid_q) {
        vlSelfRef.axi_t_rlast_o = vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_last_q;
        vlSelfRef.axi_t_rdata_o = vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_data_q;
    } else {
        vlSelfRef.axi_t_rlast_o = vlSelfRef.__PVT__u_axi_conv__DOT__rlast_q;
        vlSelfRef.axi_t_rdata_o = vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read1_q;
    }
    vlSelfRef.axi_i_awaddr_o = (0xfffffffcU & vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                                [vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][0U]);
    vlSelfRef.__PVT__ext_out_wr_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q) 
                                     & (- (IData)((0x80000000U 
                                                   <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
    vlSelfRef.__PVT__ext_out_rd_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_rd_q) 
                                     & (0x80000000U 
                                        <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q));
    vlSelfRef.axi_t_rvalid_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rvalid_q) 
                                | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__rbuf_valid_q));
    __VdfgRegularize_hebeb780c_0_10 = (1U & (vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                                             [vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][2U] 
                                             >> 4U));
    vlSelfRef.__PVT__dcache_accept_w = ((0x80000000U 
                                         <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q)
                                         ? ((2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)) 
                                            & (2U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))
                                         : (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q));
    if (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q) {
        vlSelfRef.__PVT__dcache_resp_tag_w = vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_tag_q;
        vlSelfRef.__PVT__dcache_data_rd_w = vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read1_q;
    } else {
        vlSelfRef.__PVT__dcache_resp_tag_w = vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q
            [vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q];
        vlSelfRef.__PVT__dcache_data_rd_w = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_rdata_i;
    }
    vlSelfRef.__VdfgRegularize_hebeb780c_0_12 = (1U 
                                                 & ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__bvalid_q)) 
                                                    | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_bready_i)));
    vlSelfRef.__PVT__u_axi_conv__DOT__write_active 
        = ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)) 
           & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i) 
              | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q)));
    vlSelfRef.__PVT__ext_out_ack_w = ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_rvalid_i) 
                                      | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_bvalid_i));
    vlSelfRef.__VdfgRegularize_hebeb780c_0_23 = ((0U 
                                                  != (IData)(vlSelfRef.__PVT__ext_out_wr_w)) 
                                                 | (IData)(vlSelfRef.__PVT__ext_out_rd_w));
    vlSelfRef.axi_i_arvalid_o = ((IData)(__VdfgRegularize_hebeb780c_0_10) 
                                 & (0U != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)));
    vlSelfRef.__VdfgRegularize_hebeb780c_0_9 = ((IData)(__VdfgRegularize_hebeb780c_0_10) 
                                                | (0U 
                                                   == (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)));
    vlSelfRef.axi_t_wready_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active) 
                                & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)) 
                                   & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_12)));
    vlSelfRef.axi_t_awready_o = ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active) 
                                 & ((~ ((IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_wr_q) 
                                        | (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q))) 
                                    & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_12)));
    vlSelfRef.__PVT__conv_ram_wr_w = ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wstrb_i) 
                                      & (- (IData)(
                                                   ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i) 
                                                    & (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active)))));
    vlSelfRef.__PVT__conv_ram_rd_w = ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__write_active)) 
                                      & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i) 
                                         | (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)));
    vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i 
        = ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)) 
           & (IData)(vlSelfRef.__PVT__ext_out_ack_w));
    vlSelfRef.__PVT__u_mem_axi__DOT__req_push_w = (
                                                   (2U 
                                                    != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)) 
                                                   & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_23));
    vlSelfRef.__PVT__u_mem_axi__DOT__res_push_w = (
                                                   (2U 
                                                    != (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)) 
                                                   & (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_23));
    vlSelfRef.axi_i_wvalid_o = (1U & (~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q) 
                                         | (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_9))));
    vlSelfRef.axi_i_awvalid_o = (1U & (~ ((IData)(vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q) 
                                          | (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_9))));
    vlSelfRef.__PVT__u_mem_axi__DOT__req_pop_w = (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_arready_i) 
                                                   & (IData)(vlSelfRef.axi_i_arvalid_o)) 
                                                  | ((~ (IData)(vlSelfRef.__VdfgRegularize_hebeb780c_0_9)) 
                                                     & (((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_wready_i) 
                                                         | (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__wvalid_inhibit_q)) 
                                                        & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_i_awready_i) 
                                                           | (IData)(vlSelfRef.__PVT__u_mem_axi__DOT__awvalid_inhibit_q)))));
    vlSelfRef.axi_t_arready_o = ((IData)(vlSelfRef.__PVT__conv_ram_rd_w) 
                                 & ((~ (IData)(vlSelfRef.__PVT__u_axi_conv__DOT__req_rd_q)) 
                                    & ((~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)) 
                                       & ((~ (IData)(vlSelfRef.axi_t_rvalid_o)) 
                                          | (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_rready_i)))));
}

VL_ATTR_COLD void Vriscv_tcm_top_riscv_tcm_top___ctor_var_reset(Vriscv_tcm_top_riscv_tcm_top* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vriscv_tcm_top_riscv_tcm_top___ctor_var_reset\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->clk_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11908517815223722933ull);
    vlSelf->rst_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5726502174457611970ull);
    vlSelf->rst_cpu_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13191268749260761433ull);
    vlSelf->axi_i_awready_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14766025047644636657ull);
    vlSelf->axi_i_wready_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8269567476437713517ull);
    vlSelf->axi_i_bvalid_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11329908568622999426ull);
    vlSelf->axi_i_bresp_i = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 1381934594416018020ull);
    vlSelf->axi_i_arready_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15287678307954382679ull);
    vlSelf->axi_i_rvalid_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16780052360933930440ull);
    vlSelf->axi_i_rdata_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 34627238731027321ull);
    vlSelf->axi_i_rresp_i = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 14012055248941750316ull);
    vlSelf->axi_t_awvalid_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13687209168250578002ull);
    vlSelf->axi_t_awaddr_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 15888161007493592345ull);
    vlSelf->axi_t_awid_i = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 14340923670377248239ull);
    vlSelf->axi_t_awlen_i = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 6544348249595948759ull);
    vlSelf->axi_t_awburst_i = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 3207178583004640562ull);
    vlSelf->axi_t_wvalid_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4371199546057610856ull);
    vlSelf->axi_t_wdata_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 16155192413597055901ull);
    vlSelf->axi_t_wstrb_i = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 11916823345899949218ull);
    vlSelf->axi_t_wlast_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14293783090367187538ull);
    vlSelf->axi_t_bready_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8661596346835542229ull);
    vlSelf->axi_t_arvalid_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4652065586511735509ull);
    vlSelf->axi_t_araddr_i = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 9506363447144617ull);
    vlSelf->axi_t_arid_i = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 17059568818705195726ull);
    vlSelf->axi_t_arlen_i = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 13835562063832043325ull);
    vlSelf->axi_t_arburst_i = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 14691994497975290075ull);
    vlSelf->axi_t_rready_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7305171721960650860ull);
    vlSelf->intr_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9031270550293618600ull);
    vlSelf->axi_i_awvalid_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8953460724627675499ull);
    vlSelf->axi_i_awaddr_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 12700232976703890470ull);
    vlSelf->axi_i_wvalid_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14471593029846896749ull);
    vlSelf->axi_i_wdata_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 14121924870517785077ull);
    vlSelf->axi_i_wstrb_o = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 906629656694248098ull);
    vlSelf->axi_i_bready_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10271323141225379946ull);
    vlSelf->axi_i_arvalid_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17702331295171327655ull);
    vlSelf->axi_i_araddr_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 5073211200885827957ull);
    vlSelf->axi_i_rready_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8486195148602698772ull);
    vlSelf->axi_t_awready_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11181139950384731239ull);
    vlSelf->axi_t_wready_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14643339404587124910ull);
    vlSelf->axi_t_bvalid_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16403076520387282723ull);
    vlSelf->axi_t_bresp_o = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 11852897030161612834ull);
    vlSelf->axi_t_bid_o = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 6201996228347639470ull);
    vlSelf->axi_t_arready_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 143587587711694196ull);
    vlSelf->axi_t_rvalid_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16074429169620158204ull);
    vlSelf->axi_t_rdata_o = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10739154840456641477ull);
    vlSelf->axi_t_rresp_o = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 1294929813764683790ull);
    vlSelf->axi_t_rid_o = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 9432395700557730319ull);
    vlSelf->axi_t_rlast_o = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7869645439388484178ull);
    vlSelf->__PVT__conv_ram_rd_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12786485443749640114ull);
    vlSelf->__PVT__ext_out_wr_w = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 15903120236228335070ull);
    vlSelf->__PVT__dcache_resp_tag_w = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 6723976937406055534ull);
    vlSelf->__PVT__dcache_data_rd_w = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 16301741309575182382ull);
    vlSelf->__PVT__dcache_accept_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17299147548704962728ull);
    vlSelf->__PVT__conv_ram_wr_w = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 3228740831174402729ull);
    vlSelf->__PVT__ext_out_rd_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8368692386220350053ull);
    vlSelf->__PVT__ext_out_ack_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14060856648568153238ull);
    vlSelf->__PVT__icache_pc_w = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 13188624741496613158ull);
    vlSelf->__PVT__icache_rd_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1027462849533309677ull);
    vlSelf->__PVT__u_mem_axi__DOT__req_pop_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18177696992783548670ull);
    vlSelf->__PVT__u_mem_axi__DOT__req_push_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9907665631217531248ull);
    vlSelf->__PVT__u_mem_axi__DOT__res_push_w = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16934905182490406806ull);
    vlSelf->__PVT__u_mem_axi__DOT__awvalid_inhibit_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15750419809951969978ull);
    vlSelf->__PVT__u_mem_axi__DOT__wvalid_inhibit_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18293298948679659901ull);
    vlSelf->__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4709921699239620880ull);
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        vlSelf->__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q[__Vi0] = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 1870242462294213619ull);
    }
    vlSelf->__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16051872979595425335ull);
    vlSelf->__PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17039204206429011091ull);
    vlSelf->__PVT__u_mem_axi__DOT__u_resp__DOT__count_q = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 1886152486722603344ull);
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        VL_SCOPED_RAND_RESET_W(69, vlSelf->__PVT__u_mem_axi__DOT__u_req__DOT__ram_q[__Vi0], __VscopeHash, 8123436712478887992ull);
    }
    vlSelf->__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17661060045364283791ull);
    vlSelf->__PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6898598941653236687ull);
    vlSelf->__PVT__u_mem_axi__DOT__u_req__DOT__count_q = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 17585199241212060766ull);
    vlSelf->__PVT__u_axi_conv__DOT__req_len_q = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 12647901252496155986ull);
    vlSelf->__PVT__u_axi_conv__DOT__req_addr_q = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 10751992589631299375ull);
    vlSelf->__PVT__u_axi_conv__DOT__req_rd_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16210668572014307420ull);
    vlSelf->__PVT__u_axi_conv__DOT__req_wr_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13771543187121834958ull);
    vlSelf->__PVT__u_axi_conv__DOT__req_id_q = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 15138351291521841663ull);
    vlSelf->__PVT__u_axi_conv__DOT__req_axburst_q = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 14966216631307242242ull);
    vlSelf->__PVT__u_axi_conv__DOT__req_axlen_q = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 6730430978741770174ull);
    vlSelf->__PVT__u_axi_conv__DOT__bvalid_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7393500672516658992ull);
    vlSelf->__PVT__u_axi_conv__DOT__rvalid_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1094715468579540887ull);
    vlSelf->__PVT__u_axi_conv__DOT__rlast_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4334116087610162746ull);
    vlSelf->__PVT__u_axi_conv__DOT__rbuf_valid_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7076479607523202804ull);
    vlSelf->__PVT__u_axi_conv__DOT__rbuf_data_q = VL_SCOPED_RAND_RESET_I(32, __VscopeHash, 8321095760403075195ull);
    vlSelf->__PVT__u_axi_conv__DOT__rbuf_last_q = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17310687861333685194ull);
    vlSelf->__PVT__u_axi_conv__DOT__write_active = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15073416108508522139ull);
    vlSelf->__VdfgRegularize_hebeb780c_0_9 = 0;
    vlSelf->__VdfgRegularize_hebeb780c_0_12 = 0;
    vlSelf->__VdfgRegularize_hebeb780c_0_23 = 0;
}

// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vriscv_tcm_top.h for the primary calling header

#include "Vriscv_tcm_top__pch.h"

bool Vriscv_tcm_top_mem_tcm::write(uint32_t addr, uint32_t data) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm::write\n"); );
    CData/*0:0*/ write__Vfuncrtn;
    // Body
    vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram[(0x00003fffU 
                                                       & (addr 
                                                          >> 2U))] 
        = ((2U & addr) ? ((1U & addr) ? ((0x00ffffffU 
                                          & vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                                          [(0x00003fffU 
                                            & (addr 
                                               >> 2U))]) 
                                         | ((IData)(data) 
                                            << 0x00000018U))
                           : ((0xff00ffffU & vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                               [(0x00003fffU & (addr 
                                                >> 2U))]) 
                              | ((IData)(data) << 0x00000010U)))
            : ((1U & addr) ? ((0xffff00ffU & vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                               [(0x00003fffU & (addr 
                                                >> 2U))]) 
                              | ((IData)(data) << 8U))
                : ((0xffffff00U & vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                    [(0x00003fffU & (addr >> 2U))]) 
                   | (IData)(data))));
    return (write__Vfuncrtn);
}

uint32_t Vriscv_tcm_top_mem_tcm::read(uint32_t addr) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm::read\n"); );
    CData/*7:0*/ read__Vfuncrtn;
    // Body
    read__Vfuncrtn = (0x000000ffU & ((2U & addr) ? 
                                     ((1U & addr) ? 
                                      (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                                       [(0x00003fffU 
                                         & (addr >> 2U))] 
                                       >> 0x18U) : 
                                      (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                                       [(0x00003fffU 
                                         & (addr >> 2U))] 
                                       >> 0x10U)) : 
                                     ((1U & addr) ? 
                                      (vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                                       [(0x00003fffU 
                                         & (addr >> 2U))] 
                                       >> 8U) : vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.ram
                                      [(0x00003fffU 
                                        & (addr >> 2U))])));
    return (read__Vfuncrtn);
}

void Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top_mem_tcm* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__muxed_data_w = ((IData)(vlSelfRef.__PVT__mem_d_accept_q)
                                      ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q
                                      : vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wdata_i);
}

void Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__1(Vriscv_tcm_top_mem_tcm* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm___ico_sequent__TOP__riscv_tcm_top__u_mem_tcm__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.__PVT__mem_d_accept_q) {
        vlSelfRef.__PVT__muxed_addr_w = (0x00003fffU 
                                         & (vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q 
                                            >> 2U));
        vlSelfRef.__PVT__muxed_wr_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q) 
                                       & (- (IData)(
                                                    (0x80000000U 
                                                     > vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
    } else {
        vlSelfRef.__PVT__muxed_addr_w = (0x00003fffU 
                                         & ((((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_rd_q) 
                                              | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_wr_q))
                                              ? vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_addr_q
                                              : ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active)
                                                  ? vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i
                                                  : vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_araddr_i)) 
                                            >> 2U));
        vlSelfRef.__PVT__muxed_wr_w = vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_wr_w;
    }
}

void Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top_mem_tcm* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__mem_d_ack_q = ((1U & (~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_i))) 
                                    && ((((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_rd_q) 
                                          | (0U != (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q))) 
                                         & (0x80000000U 
                                            > vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                                        & (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_accept_w)));
    if (vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_i) {
        vlSelfRef.__PVT__mem_d_tag_q = 0U;
    } else if (((((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_rd_q) 
                  | (0U != (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q))) 
                 & (0x80000000U > vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q)) 
                & (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_accept_w))) {
        vlSelfRef.__PVT__mem_d_tag_q = vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_req_tag_q;
    }
    vlSelfRef.__PVT__mem_d_accept_q = (1U & ((IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_i) 
                                             | (~ ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_rd_w) 
                                                   | (0U 
                                                      != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_wr_w))))));
}

void Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__1(Vriscv_tcm_top_mem_tcm* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm___nba_sequent__TOP__riscv_tcm_top__u_mem_tcm__1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__PVT__mem_i_valid_q = ((~ (IData)(vlSymsp->TOP.__Vcellinp__riscv_tcm_top__rst_i)) 
                                      & (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__icache_rd_w));
}

void Vriscv_tcm_top_mem_tcm___nba_comb__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top_mem_tcm* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vriscv_tcm_top_mem_tcm___nba_comb__TOP__riscv_tcm_top__u_mem_tcm__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.__PVT__mem_d_accept_q) {
        vlSelfRef.__PVT__muxed_data_w = vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q;
        vlSelfRef.__PVT__muxed_addr_w = (0x00003fffU 
                                         & (vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q 
                                            >> 2U));
        vlSelfRef.__PVT__muxed_wr_w = ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q) 
                                       & (- (IData)(
                                                    (0x80000000U 
                                                     > vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
    } else {
        vlSelfRef.__PVT__muxed_data_w = vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_wdata_i;
        vlSelfRef.__PVT__muxed_addr_w = (0x00003fffU 
                                         & ((((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_rd_q) 
                                              | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_wr_q))
                                              ? vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_addr_q
                                              : ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active)
                                                  ? vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i
                                                  : vlSymsp->TOP.__Vcellinp__riscv_tcm_top__axi_t_araddr_i)) 
                                            >> 2U));
        vlSelfRef.__PVT__muxed_wr_w = vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_wr_w;
    }
}

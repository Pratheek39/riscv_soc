// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vriscv_tcm_top__pch.h"

extern const VlVarTableEntry Vriscv_tcm_top_ram_dp_64k__VpiVarTable0[];
extern const VlScopeTableEntry Vriscv_tcm_top__Syms__VpiScopeTable[];


// VPI VARIABLE/SCOPE TABLES
#if defined(__GNUC__)
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Winvalid-offsetof"
#endif
extern const VlVarTableEntry Vriscv_tcm_top_ram_dp_64k__VpiVarTable0[] = {
    {"ram", offsetof(Vriscv_tcm_top_ram_dp_64k, ram), VLVT_UINT32, (VLVD_NODIR|VLVF_PUB_RW), 1, 1, {16383, 0, 31, 0, 0, 0}},
};
extern const VlScopeTableEntry Vriscv_tcm_top__Syms__VpiScopeTable[] = {
    {offsetof(Vriscv_tcm_top__Syms, __Vscopep_riscv_tcm_top__u_mem_tcm__u_ram), "riscv_tcm_top.u_mem_tcm.u_ram", "u_ram", "<null>", 0, VerilatedScope::SCOPE_OTHER},
};
#if defined(__GNUC__)
# pragma GCC diagnostic pop
#endif
Vriscv_tcm_top__Syms::Vriscv_tcm_top__Syms(VerilatedContext* contextp, const char* namep, Vriscv_tcm_top* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    , __Vm_didInit{modelp->m_didInit}
    // Setup top module instance
    , TOP{this, namep}
{
    // Check resources
    Verilated::stackCheck(426);
    // Setup sub module instances
    TOP__riscv_tcm_top.ctor(this, "riscv_tcm_top");
    TOP__riscv_tcm_top__u_core.ctor(this, "riscv_tcm_top.u_core");
    TOP__riscv_tcm_top__u_core__u_decode.ctor(this, "riscv_tcm_top.u_core.u_decode");
    TOP__riscv_tcm_top__u_core__u_decode__u_regfile.ctor(this, "riscv_tcm_top.u_core.u_decode.u_regfile");
    TOP__riscv_tcm_top__u_core__u_exec.ctor(this, "riscv_tcm_top.u_core.u_exec");
    TOP__riscv_tcm_top__u_mem_tcm.ctor(this, "riscv_tcm_top.u_mem_tcm");
    TOP__riscv_tcm_top__u_mem_tcm__u_ram.ctor(this, "riscv_tcm_top.u_mem_tcm.u_ram");
    // Configure time unit / time precision
    _vm_contextp__->timeunit(-12);
    _vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    TOP.riscv_tcm_top = &TOP__riscv_tcm_top;
    TOP__riscv_tcm_top.u_core = &TOP__riscv_tcm_top__u_core;
    TOP__riscv_tcm_top__u_core.u_decode = &TOP__riscv_tcm_top__u_core__u_decode;
    TOP__riscv_tcm_top__u_core__u_decode.u_regfile = &TOP__riscv_tcm_top__u_core__u_decode__u_regfile;
    TOP__riscv_tcm_top__u_core.u_exec = &TOP__riscv_tcm_top__u_core__u_exec;
    TOP__riscv_tcm_top.u_mem_tcm = &TOP__riscv_tcm_top__u_mem_tcm;
    TOP__riscv_tcm_top__u_mem_tcm.u_ram = &TOP__riscv_tcm_top__u_mem_tcm__u_ram;
    // Setup each module's pointer back to symbol table (for public functions)
    TOP.__Vconfigure(true);
    TOP__riscv_tcm_top.__Vconfigure(true);
    TOP__riscv_tcm_top__u_core.__Vconfigure(true);
    TOP__riscv_tcm_top__u_core__u_decode.__Vconfigure(true);
    TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__Vconfigure(true);
    TOP__riscv_tcm_top__u_core__u_exec.__Vconfigure(true);
    TOP__riscv_tcm_top__u_mem_tcm.__Vconfigure(true);
    TOP__riscv_tcm_top__u_mem_tcm__u_ram.__Vconfigure(true);
    // Setup scopes
    VerilatedScope::scopesConstructFromTable(Vriscv_tcm_top__Syms__VpiScopeTable, 1, this);
    // Setup export functions - final: 0
    // Setup export functions - final: 1
    // Setup public variables
    __Vscopep_riscv_tcm_top__u_mem_tcm__u_ram->varsInsertFromTable(Vriscv_tcm_top_ram_dp_64k__VpiVarTable0, 1, &(TOP__riscv_tcm_top__u_mem_tcm__u_ram));
}

Vriscv_tcm_top__Syms::~Vriscv_tcm_top__Syms() {
    // Tear down scopes
    VL_DO_CLEAR(delete __Vscopep_riscv_tcm_top__u_mem_tcm__u_ram, __Vscopep_riscv_tcm_top__u_mem_tcm__u_ram = nullptr);
    // Tear down sub module instances
    TOP__riscv_tcm_top__u_mem_tcm__u_ram.dtor();
    TOP__riscv_tcm_top__u_mem_tcm.dtor();
    TOP__riscv_tcm_top__u_core__u_exec.dtor();
    TOP__riscv_tcm_top__u_core__u_decode__u_regfile.dtor();
    TOP__riscv_tcm_top__u_core__u_decode.dtor();
    TOP__riscv_tcm_top__u_core.dtor();
    TOP__riscv_tcm_top.dtor();
}

// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals

#include "verilated_vcd_sc.h"
#include "Vriscv_tcm_top__Syms.h"


VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_PUSH_PREFIX(tracep, "riscv_tcm_top", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__0(vlSelf, tracep);
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep);
VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction);
VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction);
VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_cpu_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+3,0,"axi_i_awready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+4,0,"axi_i_wready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+5,0,"axi_i_bvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+6,0,"axi_i_bresp_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+7,0,"axi_i_arready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+8,0,"axi_i_rvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+9,0,"axi_i_rdata_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+10,0,"axi_i_rresp_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+11,0,"axi_t_awvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+12,0,"axi_t_awaddr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+13,0,"axi_t_awid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+14,0,"axi_t_awlen_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 7,0);
    VL_TRACE_DECL_BUS(tracep,c+15,0,"axi_t_awburst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+16,0,"axi_t_wvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+17,0,"axi_t_wdata_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+18,0,"axi_t_wstrb_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+19,0,"axi_t_wlast_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+20,0,"axi_t_bready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+21,0,"axi_t_arvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+22,0,"axi_t_araddr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+23,0,"axi_t_arid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+24,0,"axi_t_arlen_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 7,0);
    VL_TRACE_DECL_BUS(tracep,c+25,0,"axi_t_arburst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+26,0,"axi_t_rready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+27,0,"intr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+134,0,"axi_i_awvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+135,0,"axi_i_awaddr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+136,0,"axi_i_wvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+137,0,"axi_i_wdata_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+138,0,"axi_i_wstrb_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+139,0,"axi_i_bready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+140,0,"axi_i_arvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+135,0,"axi_i_araddr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+139,0,"axi_i_rready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+29,0,"axi_t_awready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+30,0,"axi_t_wready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+141,0,"axi_t_bvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+339,0,"axi_t_bresp_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+142,0,"axi_t_bid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+31,0,"axi_t_arready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+143,0,"axi_t_rvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+335,0,"axi_t_rdata_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+339,0,"axi_t_rresp_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+142,0,"axi_t_rid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+144,0,"axi_t_rlast_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+17,0,"conv_ram_write_data_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+340,0,"ext_out_flush_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"ext_out_req_tag_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BUS(tracep,c+32,0,"conv_ram_addr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+189,0,"icache_flush_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+33,0,"conv_ram_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+139,0,"mem_out_resp_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+340,0,"ext_out_cacheable_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+190,0,"dcache_flush_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+191,0,"dcache_invalidate_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+192,0,"ext_out_wr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+336,0,"conv_ram_read_data_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+34,0,"dcache_ack_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+145,0,"dcache_resp_tag_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"icache_invalidate_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+337,0,"icache_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+146,0,"ext_out_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+340,0,"ext_out_invalidate_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+193,0,"dcache_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"dcache_addr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+59,0,"dcache_data_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+147,0,"ext_out_resp_tag_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+338,0,"icache_valid_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"ext_out_data_wr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"dcache_req_tag_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+196,0,"dcache_cacheable_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+325,0,"dcache_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+342,0,"icache_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+35,0,"conv_ram_wr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+148,0,"conv_ram_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"ext_out_addr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+197,0,"ext_out_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+28,0,"ext_out_ack_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+198,0,"dcache_wr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+343,0,"boot_vector_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+67,0,"icache_pc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+68,0,"icache_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+9,0,"ext_out_data_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"dcache_data_wr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_PUSH_PREFIX(tracep, "u_axi_conv", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+11,0,"axi_awvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+12,0,"axi_awaddr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+13,0,"axi_awid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+14,0,"axi_awlen_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 7,0);
    VL_TRACE_DECL_BUS(tracep,c+15,0,"axi_awburst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+16,0,"axi_wvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+17,0,"axi_wdata_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+18,0,"axi_wstrb_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+19,0,"axi_wlast_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+20,0,"axi_bready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+21,0,"axi_arvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+22,0,"axi_araddr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+23,0,"axi_arid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+24,0,"axi_arlen_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 7,0);
    VL_TRACE_DECL_BUS(tracep,c+25,0,"axi_arburst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+26,0,"axi_rready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+336,0,"ram_read_data_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+148,0,"ram_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+29,0,"axi_awready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+30,0,"axi_wready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+141,0,"axi_bvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+339,0,"axi_bresp_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+142,0,"axi_bid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+31,0,"axi_arready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+143,0,"axi_rvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+335,0,"axi_rdata_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+339,0,"axi_rresp_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+142,0,"axi_rid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+144,0,"axi_rlast_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+35,0,"ram_wr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+33,0,"ram_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+32,0,"ram_addr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+17,0,"ram_write_data_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+149,0,"calculate_addr_next__Vstatic__mask",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+150,0,"req_len_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 7,0);
    VL_TRACE_DECL_BUS(tracep,c+151,0,"req_addr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+152,0,"req_rd_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+153,0,"req_wr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+142,0,"req_id_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+154,0,"req_axburst_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+155,0,"req_axlen_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 7,0);
    VL_TRACE_DECL_BIT(tracep,c+141,0,"bvalid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+156,0,"rvalid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+157,0,"rlast_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+158,0,"rbuf_valid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+159,0,"rbuf_data_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+160,0,"rbuf_last_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+36,0,"write_active",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+33,0,"read_active",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+32,0,"addr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+37,0,"wr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+33,0,"rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_core", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__0(vlSelf, tracep);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_mem_axi", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"mem_addr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"mem_data_wr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+197,0,"mem_rd_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+192,0,"mem_wr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_cacheable_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"mem_req_tag_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_invalidate_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_flush_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+139,0,"mem_resp_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+3,0,"axi_awready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+4,0,"axi_wready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+5,0,"axi_bvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+6,0,"axi_bresp_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+7,0,"axi_arready_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+8,0,"axi_rvalid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+9,0,"axi_rdata_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+10,0,"axi_rresp_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+9,0,"mem_data_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+146,0,"mem_accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+28,0,"mem_ack_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+147,0,"mem_resp_tag_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+134,0,"axi_awvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+135,0,"axi_awaddr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+136,0,"axi_wvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+137,0,"axi_wdata_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+138,0,"axi_wstrb_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+139,0,"axi_bready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+140,0,"axi_arvalid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+135,0,"axi_araddr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+139,0,"axi_rready_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+161,0,"res_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+162,0,"req_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+38,0,"write_complete_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+39,0,"read_complete_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+40,0,"req_pop_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+163,0,"req_valid_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_WIDE(tracep,c+164,0,"req_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 68,0);
    VL_TRACE_DECL_BIT(tracep,c+326,0,"req_push_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+327,0,"res_push_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+140,0,"req_is_read_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+167,0,"req_is_write_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+168,0,"awvalid_inhibit_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+169,0,"wvalid_inhibit_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_PUSH_PREFIX(tracep, "u_req", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BUS(tracep,c+344,0,"WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_WIDE(tracep,c+199,0,"data_in_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 68,0);
    VL_TRACE_DECL_BIT(tracep,c+326,0,"push_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+40,0,"pop_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_WIDE(tracep,c+164,0,"data_out_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 68,0);
    VL_TRACE_DECL_BIT(tracep,c+162,0,"accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+163,0,"valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);

    Vriscv_tcm_top___024root__trace_init_dtype____0(vlSelf, tracep, "ram_q", 0, c+170, VerilatedTraceSigDirection::NONE);
    VL_TRACE_DECL_BUS(tracep,c+176,0,"rd_ptr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 0,0);
    VL_TRACE_DECL_BUS(tracep,c+177,0,"wr_ptr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 0,0);
    VL_TRACE_DECL_BUS(tracep,c+178,0,"count_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_resp", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BUS(tracep,c+345,0,"WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"data_in_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+327,0,"push_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+41,0,"pop_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+147,0,"data_out_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+161,0,"accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+179,0,"valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);

    Vriscv_tcm_top___024root__trace_init_dtype____1(vlSelf, tracep, "ram_q", 0, c+180, VerilatedTraceSigDirection::NONE);
    VL_TRACE_DECL_BUS(tracep,c+182,0,"rd_ptr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 0,0);
    VL_TRACE_DECL_BUS(tracep,c+183,0,"wr_ptr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 0,0);
    VL_TRACE_DECL_BUS(tracep,c+184,0,"count_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_mem_tcm", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__0(vlSelf, tracep);
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype_sub____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_dtype____0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vriscv_tcm_top___024root__trace_init_dtype_sub____0(vlSelf, tracep, name, fidx, c, direction);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype_sub____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_dtype_sub____0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VL_TRACE_PUSH_PREFIX(tracep, name, VerilatedTracePrefixType::ARRAY_UNPACKED, 1, 0);
    for (int i = 0; i < 2; ++i) {
        VL_TRACE_DECL_WIDE_ARRAY(tracep,c+0+i*3,fidx,"",-1, direction, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, (1 - i), 68,0);
    }
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype_sub____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_dtype____1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vriscv_tcm_top___024root__trace_init_dtype_sub____1(vlSelf, tracep, name, fidx, c, direction);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_dtype_sub____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep, const char* name, uint32_t fidx, uint32_t c, VerilatedTraceSigDirection direction) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_dtype_sub____1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VL_TRACE_PUSH_PREFIX(tracep, name, VerilatedTracePrefixType::ARRAY_UNPACKED, 1, 0);
    for (int i = 0; i < 2; ++i) {
        VL_TRACE_DECL_BUS_ARRAY(tracep,c+0+i*1,fidx,"",-1, direction, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, (1 - i), 10,0);
    }
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep);
VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_exec__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+59,0,"mem_d_data_rd_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+325,0,"mem_d_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+34,0,"mem_d_ack_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_d_error_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+145,0,"mem_d_resp_tag_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+346,0,"mem_i_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+338,0,"mem_i_valid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_i_error_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+337,0,"mem_i_inst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+27,0,"intr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+343,0,"reset_vector_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+347,0,"cpu_id_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"mem_d_addr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"mem_d_data_wr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+193,0,"mem_d_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+198,0,"mem_d_wr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+196,0,"mem_d_cacheable_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"mem_d_req_tag_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+191,0,"mem_d_invalidate_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+190,0,"mem_d_flush_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+68,0,"mem_i_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+189,0,"mem_i_flush_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_i_invalidate_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+67,0,"mem_i_pc_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+202,0,"fetch_invalidate_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+42,0,"fetch_branch_pc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_page_load_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+203,0,"csr_stall_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+69,0,"fetch_accept_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+347,0,"fault_addr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_QUAD(tracep,c+204,0,"opcode_instr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BUS(tracep,c+206,0,"fetch_pc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_load_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+340,0,"exec_stall_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+70,0,"muldiv_opcode_valid_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+207,0,"writeback_muldiv_idx_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+71,0,"csr_opcode_valid_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+208,0,"fault_misaligned_store_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+209,0,"branch_csr_request_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+210,0,"writeback_exec_idx_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+60,0,"writeback_mem_idx_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+211,0,"opcode_pc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_page_store_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+72,0,"lsu_opcode_valid_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+212,0,"writeback_csr_squash_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+73,0,"branch_pc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+213,0,"muldiv_stall_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+74,0,"fetch_valid_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+328,0,"lsu_stall_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_store_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+214,0,"opcode_ra_idx_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+75,0,"exec_opcode_valid_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+215,0,"writeback_csr_idx_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+61,0,"writeback_mem_value_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+216,0,"opcode_rd_idx_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+340,0,"writeback_exec_squash_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+217,0,"opcode_opcode_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_muldiv_squash_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"opcode_rb_idx_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+76,0,"fetch_branch_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+219,0,"fault_misaligned_load_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+220,0,"writeback_muldiv_value_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+221,0,"writeback_exec_value_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+222,0,"branch_csr_pc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+223,0,"writeback_csr_value_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+77,0,"branch_request_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_mem_squash_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+330,0,"fetch_instr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+78,0,"opcode_rb_operand_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+79,0,"opcode_ra_operand_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_PUSH_PREFIX(tracep, "u_csr", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+27,0,"intr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+71,0,"opcode_valid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+204,0,"opcode_instr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BUS(tracep,c+217,0,"opcode_opcode_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+211,0,"opcode_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+216,0,"opcode_rd_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+214,0,"opcode_ra_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"opcode_rb_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+79,0,"opcode_ra_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+78,0,"opcode_rb_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+77,0,"branch_exec_request_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+73,0,"branch_exec_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+347,0,"cpu_id_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+343,0,"reset_vector_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_store_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_load_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+208,0,"fault_misaligned_store_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+219,0,"fault_misaligned_load_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_page_store_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_page_load_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+347,0,"fault_addr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+215,0,"writeback_idx_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+212,0,"writeback_squash_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+223,0,"writeback_value_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+203,0,"stall_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+209,0,"branch_csr_request_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+222,0,"branch_csr_pc_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+224,0,"csr_mepc_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+225,0,"csr_mcause_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+226,0,"csr_sr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+227,0,"csr_mtvec_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+228,0,"csr_mip_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+229,0,"csr_mie_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+230,0,"csr_mpriv_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+231,0,"csr_mcycle_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+232,0,"csr_mscratch_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+233,0,"pc_m_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+80,0,"exc_src_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"csr_access_fault_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+81,0,"exception_m_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+234,0,"imm12_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+235,0,"priv_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+236,0,"readonly_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+237,0,"write_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+238,0,"set_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+239,0,"clr_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+82,0,"csr_mepc_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+83,0,"csr_mcause_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+84,0,"csr_sr_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+85,0,"csr_mtvec_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+86,0,"csr_mip_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+87,0,"csr_mie_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+348,0,"csr_mtime_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+349,0,"csr_mtimecmp_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+88,0,"csr_mpriv_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BUS(tracep,c+240,0,"csr_mcycle_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+89,0,"csr_mscratch_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+90,0,"take_intr_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+91,0,"take_exception_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+92,0,"data_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+93,0,"result_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+94,0,"valid_unit_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+241,0,"load_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+242,0,"store_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+243,0,"irq_pending_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+244,0,"irq_masked_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+245,0,"writeback_en_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+246,0,"writeback_idx_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+223,0,"writeback_value_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+212,0,"writeback_squash_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+43,0,"branch_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+44,0,"branch_target_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+209,0,"branch_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+222,0,"branch_target_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+247,0,"reset_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_decode", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__0(vlSelf, tracep);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_exec", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_exec__0(vlSelf, tracep);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_fetch", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+76,0,"fetch_branch_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+42,0,"fetch_branch_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+69,0,"fetch_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+346,0,"icache_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+338,0,"icache_valid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"icache_error_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+337,0,"icache_inst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+202,0,"fetch_invalidate_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+74,0,"fetch_valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+330,0,"fetch_instr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+206,0,"fetch_pc_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+68,0,"icache_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+189,0,"icache_flush_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"icache_invalidate_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+67,0,"icache_pc_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+248,0,"active_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+249,0,"fetch_pc_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+250,0,"branch_pc_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+251,0,"branch_valid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+252,0,"icache_fetch_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+253,0,"icache_invalidate_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+254,0,"skid_buffer_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 63,0);
    VL_TRACE_DECL_BIT(tracep,c+256,0,"skid_valid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+329,0,"icache_busy_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+95,0,"stall_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+96,0,"branch_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+97,0,"branch_pc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+257,0,"pc_d_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+337,0,"instruction_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_lsu", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+72,0,"opcode_valid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+204,0,"opcode_instr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BUS(tracep,c+217,0,"opcode_opcode_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+211,0,"opcode_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+216,0,"opcode_rd_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+214,0,"opcode_ra_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"opcode_rb_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+79,0,"opcode_ra_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+78,0,"opcode_rb_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+59,0,"mem_data_rd_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+325,0,"mem_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+34,0,"mem_ack_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_error_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+145,0,"mem_resp_tag_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"mem_addr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"mem_data_wr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+193,0,"mem_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+198,0,"mem_wr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+196,0,"mem_cacheable_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"mem_req_tag_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+191,0,"mem_invalidate_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+190,0,"mem_flush_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+60,0,"writeback_idx_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_squash_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+61,0,"writeback_value_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_store_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_load_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+208,0,"fault_misaligned_store_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+219,0,"fault_misaligned_load_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_page_store_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"fault_page_load_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+347,0,"fault_addr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+328,0,"stall_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"mem_addr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"mem_data_wr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+193,0,"mem_rd_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+198,0,"mem_wr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+196,0,"mem_cacheable_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"mem_req_tag_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+191,0,"mem_invalidate_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+190,0,"mem_flush_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+219,0,"mem_unaligned_ld_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+208,0,"mem_unaligned_st_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+241,0,"load_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+258,0,"load_signed_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+242,0,"store_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+98,0,"mem_addr_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+99,0,"mem_unaligned_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+259,0,"dcache_flush_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+260,0,"dcache_writeback_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+261,0,"dcache_invalidate_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+62,0,"addr_lsb_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 1,0);
    VL_TRACE_DECL_BIT(tracep,c+63,0,"load_byte_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+64,0,"load_half_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+65,0,"load_word_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+66,0,"load_signed_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+60,0,"wb_idx_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+61,0,"wb_result_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_POP_PREFIX(tracep);
    VL_TRACE_PUSH_PREFIX(tracep, "u_muldiv", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+70,0,"opcode_valid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+204,0,"opcode_instr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BUS(tracep,c+217,0,"opcode_opcode_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+211,0,"opcode_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+216,0,"opcode_rd_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+214,0,"opcode_ra_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"opcode_rb_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+79,0,"opcode_ra_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+78,0,"opcode_rb_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+207,0,"writeback_idx_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_squash_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+220,0,"writeback_value_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+213,0,"stall_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+262,0,"rd_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+220,0,"wb_result_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+207,0,"wb_rd_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_WIDE(tracep,c+100,0,"mult_result_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 64,0);
    VL_TRACE_DECL_QUAD(tracep,c+103,0,"operand_b_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 32,0);
    VL_TRACE_DECL_QUAD(tracep,c+105,0,"operand_a_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 32,0);
    VL_TRACE_DECL_BUS(tracep,c+45,0,"result_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+263,0,"mult_result_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+264,0,"mult_busy_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+265,0,"mult_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+266,0,"div_rem_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+267,0,"signed_operation_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+268,0,"div_operation_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+269,0,"dividend_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_QUAD(tracep,c+270,0,"divisor_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 62,0);
    VL_TRACE_DECL_BUS(tracep,c+272,0,"quotient_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+273,0,"q_mask_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+274,0,"div_inst_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+275,0,"div_busy_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+276,0,"invert_res_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+107,0,"div_start_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+277,0,"div_complete_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+278,0,"div_result_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"mem_d_addr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"mem_d_data_wr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+193,0,"mem_d_rd_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+198,0,"mem_d_wr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+196,0,"mem_d_cacheable_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"mem_d_req_tag_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+191,0,"mem_d_invalidate_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+190,0,"mem_d_flush_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+68,0,"mem_i_rd_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+189,0,"mem_i_flush_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_i_invalidate_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+67,0,"mem_i_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+35,0,"ext_wr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+33,0,"ext_rd_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+32,0,"ext_addr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+17,0,"ext_write_data_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+9,0,"mem_out_data_rd_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+146,0,"mem_out_accept_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+28,0,"mem_out_ack_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+147,0,"mem_out_resp_tag_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BUS(tracep,c+59,0,"mem_d_data_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+325,0,"mem_d_accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+34,0,"mem_d_ack_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+145,0,"mem_d_resp_tag_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+346,0,"mem_i_accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+338,0,"mem_i_valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+337,0,"mem_i_inst_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+336,0,"ext_read_data_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+148,0,"ext_accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+194,0,"mem_out_addr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+195,0,"mem_out_data_wr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+197,0,"mem_out_rd_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+192,0,"mem_out_wr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_out_cacheable_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+188,0,"mem_out_req_tag_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_out_invalidate_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"mem_out_flush_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+139,0,"mem_out_resp_accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+279,0,"mem_d_external_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+108,0,"muxed_addr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 13,0);
    VL_TRACE_DECL_BUS(tracep,c+109,0,"muxed_data_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+110,0,"muxed_wr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+336,0,"data_r_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+338,0,"mem_i_valid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+185,0,"mem_d_accept_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+186,0,"mem_d_tag_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 10,0);
    VL_TRACE_DECL_BIT(tracep,c+187,0,"mem_d_ack_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_PUSH_PREFIX(tracep, "u_ram", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0(vlSelf, tracep);
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_exec__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_exec__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+75,0,"opcode_valid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+204,0,"opcode_instr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BUS(tracep,c+217,0,"opcode_opcode_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+211,0,"opcode_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+216,0,"opcode_rd_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+214,0,"opcode_ra_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"opcode_rb_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+79,0,"opcode_ra_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+78,0,"opcode_rb_operand_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+77,0,"branch_request_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+73,0,"branch_pc_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+210,0,"writeback_idx_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_squash_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+221,0,"writeback_value_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"stall_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+210,0,"rd_x_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+280,0,"imm20_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+234,0,"imm12_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+281,0,"bimm_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+282,0,"jimm20_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"shamt_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+283,0,"storeimm_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+284,0,"alu_func_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+111,0,"alu_input_a_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+112,0,"alu_input_b_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+285,0,"write_rd_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+113,0,"less_than_signed__Vstatic__v",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+114,0,"greater_than_signed__Vstatic__v",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+115,0,"branch_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+73,0,"branch_target_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+116,0,"alu_p_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+221,0,"result_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+286,0,"v_dbg_valid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+287,0,"v_dbg_pc_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_PUSH_PREFIX(tracep, "u_alu", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    VL_TRACE_DECL_BUS(tracep,c+284,0,"alu_op_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+111,0,"alu_a_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+112,0,"alu_b_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+116,0,"alu_p_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+116,0,"result_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+117,0,"shift_right_fill_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,16);
    VL_TRACE_DECL_BUS(tracep,c+118,0,"shift_right_1_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+119,0,"shift_right_2_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+120,0,"shift_right_4_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+121,0,"shift_right_8_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+122,0,"shift_left_1_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+123,0,"shift_left_2_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+124,0,"shift_left_4_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+125,0,"shift_left_8_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+126,0,"sub_res_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__u_regfile__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+74,0,"fetch_valid_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+330,0,"fetch_instr_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+206,0,"fetch_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+77,0,"branch_request_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+73,0,"branch_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+209,0,"branch_csr_request_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+222,0,"branch_csr_pc_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+210,0,"writeback_exec_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_exec_squash_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+221,0,"writeback_exec_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+60,0,"writeback_mem_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_mem_squash_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+61,0,"writeback_mem_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+215,0,"writeback_csr_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+212,0,"writeback_csr_squash_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+223,0,"writeback_csr_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+207,0,"writeback_muldiv_idx_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"writeback_muldiv_squash_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+220,0,"writeback_muldiv_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+341,0,"exec_stall_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+328,0,"lsu_stall_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+203,0,"csr_stall_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+213,0,"muldiv_stall_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+76,0,"fetch_branch_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+42,0,"fetch_branch_pc_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+69,0,"fetch_accept_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+75,0,"exec_opcode_valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+72,0,"lsu_opcode_valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+71,0,"csr_opcode_valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+70,0,"muldiv_opcode_valid_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+204,0,"opcode_instr_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BUS(tracep,c+217,0,"opcode_opcode_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+211,0,"opcode_pc_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+216,0,"opcode_rd_idx_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+214,0,"opcode_ra_idx_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"opcode_rb_idx_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+79,0,"opcode_ra_operand_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+78,0,"opcode_rb_operand_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+202,0,"fetch_invalidate_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+288,0,"valid_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+211,0,"pc_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+217,0,"inst_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+350,0,"fault_fetch_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+289,0,"scoreboard_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+127,0,"stall_scoreboard_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+290,0,"ra_value_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+291,0,"rb_value_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+128,0,"stall_input_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+210,0,"wb_exec_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+60,0,"wb_mem_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+292,0,"wb_csr_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+207,0,"wb_muldiv_rd_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+210,0,"wb_rd_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+221,0,"wb_res_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+202,0,"ifence_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+129,0,"scoreboard_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+293,0,"sb_alloc_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+331,0,"opcode_instr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BIT(tracep,c+333,0,"nop_instr_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+334,0,"invalid_inst_w",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_QUAD(tracep,c+204,0,"opcode_instr_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 57,0);
    VL_TRACE_DECL_BUS(tracep,c+79,0,"opcode_ra_operand_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+78,0,"opcode_rb_operand_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BIT(tracep,c+130,0,"opcode_valid_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+131,0,"current_scoreboard_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_WIDE(tracep,c+46,0,"dbg_inst_str",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 79,0);
    VL_TRACE_DECL_WIDE(tracep,c+49,0,"dbg_inst_ra",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 79,0);
    VL_TRACE_DECL_WIDE(tracep,c+52,0,"dbg_inst_rb",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 79,0);
    VL_TRACE_DECL_WIDE(tracep,c+55,0,"dbg_inst_rd",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 79,0);
    VL_TRACE_DECL_BUS(tracep,c+132,0,"dbg_inst_imm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+58,0,"dbg_inst_pc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_PUSH_PREFIX(tracep, "u_regfile", VerilatedTracePrefixType::SCOPE_MODULE, 0, 0);
    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__u_regfile__0(vlSelf, tracep);
    VL_TRACE_POP_PREFIX(tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_mem_tcm__u_ram__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk0_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst0_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+133,0,"addr0_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 13,0);
    VL_TRACE_DECL_BUS(tracep,c+347,0,"data0_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+351,0,"wr0_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk1_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+1,0,"rst1_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+108,0,"addr1_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 13,0);
    VL_TRACE_DECL_BUS(tracep,c+109,0,"data1_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+110,0,"wr1_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 3,0);
    VL_TRACE_DECL_BUS(tracep,c+337,0,"data0_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+336,0,"data1_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+337,0,"ram_read0_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+336,0,"ram_read1_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__u_regfile__0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_sub__TOP__riscv_tcm_top__u_core__u_decode__u_regfile__0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const int c = vlSymsp->__Vm_baseCode;
    VL_TRACE_DECL_BIT(tracep,c+0,0,"clk_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BIT(tracep,c+2,0,"rst_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC);
    VL_TRACE_DECL_BUS(tracep,c+210,0,"rd0_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+60,0,"rd1_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+292,0,"rd2_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+207,0,"rd3_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+221,0,"rd0_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+61,0,"rd1_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+223,0,"rd2_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+220,0,"rd3_value_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+214,0,"ra_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+218,0,"rb_i",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 4,0);
    VL_TRACE_DECL_BUS(tracep,c+290,0,"ra_value_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+291,0,"rb_value_o",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+294,0,"reg_r1_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+295,0,"reg_r2_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+296,0,"reg_r3_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+297,0,"reg_r4_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+298,0,"reg_r5_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+299,0,"reg_r6_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+300,0,"reg_r7_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+301,0,"reg_r8_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+302,0,"reg_r9_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+303,0,"reg_r10_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+304,0,"reg_r11_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+305,0,"reg_r12_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+306,0,"reg_r13_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+307,0,"reg_r14_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+308,0,"reg_r15_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+309,0,"reg_r16_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+310,0,"reg_r17_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+311,0,"reg_r18_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+312,0,"reg_r19_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+313,0,"reg_r20_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+314,0,"reg_r21_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+315,0,"reg_r22_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+316,0,"reg_r23_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+317,0,"reg_r24_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+318,0,"reg_r25_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+319,0,"reg_r26_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+320,0,"reg_r27_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+321,0,"reg_r28_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+322,0,"reg_r29_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+323,0,"reg_r30_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+324,0,"reg_r31_q",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+290,0,"ra_value_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
    VL_TRACE_DECL_BUS(tracep,c+291,0,"rb_value_r",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, 31,0);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_init_top(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_init_top\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vriscv_tcm_top___024root__trace_init_sub__TOP__0(vlSelf, tracep);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void Vriscv_tcm_top___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void Vriscv_tcm_top___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_register(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_register\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    tracep->addConstCb(&Vriscv_tcm_top___024root__trace_const_0, 0, vlSelf);
    tracep->addFullCb(&Vriscv_tcm_top___024root__trace_full_0, 0, vlSelf);
    tracep->addChgCb(&Vriscv_tcm_top___024root__trace_chg_0, 0, vlSelf);
    tracep->addCleanupCb(&Vriscv_tcm_top___024root__trace_cleanup, vlSelf);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_const_0_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_const_0\n"); );
    // Body
    Vriscv_tcm_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_tcm_top___024root*>(voidSelf);
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    Vriscv_tcm_top___024root__trace_const_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_const_0_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_const_0_sub_0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    bufp->fullCData(oldp+339,(0U),2);
    bufp->fullBit(oldp+340,(0U));
    bufp->fullBit(oldp+341,(0U));
    bufp->fullBit(oldp+342,(1U));
    bufp->fullIData(oldp+343,(0x00002000U),32);
    bufp->fullIData(oldp+344,(0x00000045U),32);
    bufp->fullIData(oldp+345,(0x0000000bU),32);
    bufp->fullBit(oldp+346,(1U));
    bufp->fullIData(oldp+347,(0U),32);
    bufp->fullIData(oldp+348,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtime_r),32);
    bufp->fullIData(oldp+349,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtimecmp_r),32);
    bufp->fullBit(oldp+350,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__fault_fetch_q));
    bufp->fullCData(oldp+351,(0U),4);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_0_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_full_0\n"); );
    // Body
    Vriscv_tcm_top___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vriscv_tcm_top___024root*>(voidSelf);
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    Vriscv_tcm_top___024root__trace_full_0_sub_0((&vlSymsp->TOP), bufp);
}

extern const VlWide<96>/*3071:0*/ Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0;
VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_dtype____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<VlWide<3>/*68:0*/, 2>& __VdtypeVar);
VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_dtype____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<SData/*10:0*/, 2>& __VdtypeVar);

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_0_sub_0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_full_0_sub_0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_3;
    VlWide<3>/*95:0*/ __Vtemp_4;
    VlWide<3>/*95:0*/ __Vtemp_6;
    VlWide<3>/*95:0*/ __Vtemp_7;
    VlWide<3>/*95:0*/ __Vtemp_9;
    VlWide<3>/*95:0*/ __Vtemp_10;
    VlWide<3>/*95:0*/ __Vtemp_11;
    IData/*31:0*/ __VExpandSel_WordIdx_1;
    IData/*31:0*/ __VExpandSel_WordIdx_2;
    IData/*31:0*/ __VExpandSel_WordIdx_3;
    IData/*31:0*/ __VExpandSel_WordIdx_4;
    IData/*31:0*/ __VExpandSel_WordIdx_5;
    IData/*31:0*/ __VExpandSel_WordIdx_6;
    IData/*31:0*/ __VExpandSel_WordIdx_7;
    IData/*31:0*/ __VExpandSel_WordIdx_8;
    IData/*31:0*/ __VExpandSel_WordIdx_9;
    IData/*31:0*/ __VExpandSel_WordIdx_10;
    IData/*31:0*/ __VExpandSel_WordIdx_11;
    IData/*31:0*/ __VExpandSel_WordIdx_12;
    // Body
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    bufp->fullBit(oldp+0,(vlSelfRef.__Vcellinp__riscv_tcm_top__clk_i));
    bufp->fullBit(oldp+1,(vlSelfRef.__Vcellinp__riscv_tcm_top__rst_i));
    bufp->fullBit(oldp+2,(vlSelfRef.__Vcellinp__riscv_tcm_top__rst_cpu_i));
    bufp->fullBit(oldp+3,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_awready_i));
    bufp->fullBit(oldp+4,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_wready_i));
    bufp->fullBit(oldp+5,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bvalid_i));
    bufp->fullCData(oldp+6,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_bresp_i),2);
    bufp->fullBit(oldp+7,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_arready_i));
    bufp->fullBit(oldp+8,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rvalid_i));
    bufp->fullIData(oldp+9,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rdata_i),32);
    bufp->fullCData(oldp+10,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_rresp_i),2);
    bufp->fullBit(oldp+11,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awvalid_i));
    bufp->fullIData(oldp+12,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i),32);
    bufp->fullCData(oldp+13,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awid_i),4);
    bufp->fullCData(oldp+14,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awlen_i),8);
    bufp->fullCData(oldp+15,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awburst_i),2);
    bufp->fullBit(oldp+16,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i));
    bufp->fullIData(oldp+17,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wdata_i),32);
    bufp->fullCData(oldp+18,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wstrb_i),4);
    bufp->fullBit(oldp+19,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wlast_i));
    bufp->fullBit(oldp+20,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_bready_i));
    bufp->fullBit(oldp+21,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arvalid_i));
    bufp->fullIData(oldp+22,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_araddr_i),32);
    bufp->fullCData(oldp+23,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arid_i),4);
    bufp->fullCData(oldp+24,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arlen_i),8);
    bufp->fullCData(oldp+25,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_arburst_i),2);
    bufp->fullBit(oldp+26,(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_rready_i));
    bufp->fullBit(oldp+27,(vlSelfRef.__Vcellinp__riscv_tcm_top__intr_i));
    bufp->fullBit(oldp+28,(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_ack_w));
    bufp->fullBit(oldp+29,(vlSymsp->TOP__riscv_tcm_top.axi_t_awready_o));
    bufp->fullBit(oldp+30,(vlSymsp->TOP__riscv_tcm_top.axi_t_wready_o));
    bufp->fullBit(oldp+31,(vlSymsp->TOP__riscv_tcm_top.axi_t_arready_o));
    bufp->fullIData(oldp+32,((((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_rd_q) 
                               | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_wr_q))
                               ? vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_addr_q
                               : ((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active)
                                   ? vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_awaddr_i
                                   : vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_araddr_i))),32);
    bufp->fullBit(oldp+33,(vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_rd_w));
    bufp->fullBit(oldp+34,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q) 
                            | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_ack_w))));
    bufp->fullCData(oldp+35,(vlSymsp->TOP__riscv_tcm_top.__PVT__conv_ram_wr_w),4);
    bufp->fullBit(oldp+36,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active));
    bufp->fullBit(oldp+37,(((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_t_wvalid_i) 
                            & (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__write_active))));
    bufp->fullBit(oldp+38,(((~ (IData)(vlSymsp->TOP__riscv_tcm_top.__VdfgRegularize_hebeb780c_0_9)) 
                            & (((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_wready_i) 
                                | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__wvalid_inhibit_q)) 
                               & ((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_awready_i) 
                                  | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__awvalid_inhibit_q))))));
    bufp->fullBit(oldp+39,(((IData)(vlSelfRef.__Vcellinp__riscv_tcm_top__axi_i_arready_i) 
                            & (IData)(vlSymsp->TOP__riscv_tcm_top.axi_i_arvalid_o))));
    bufp->fullBit(oldp+40,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__req_pop_w));
    bufp->fullBit(oldp+41,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__pop_i));
    bufp->fullIData(oldp+42,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_q)
                               ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_target_q
                               : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__branch_pc_w)),32);
    bufp->fullBit(oldp+43,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_exception_r) 
                            | ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_intr_r) 
                               | ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                 >> 0x00000026U)))
                                   ? (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w)
                                   : ((1U & (IData)(
                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                     >> 0x00000027U)))
                                       ? (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w)
                                       : ((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                   >> 0x00000028U)) 
                                          & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w))))))));
    bufp->fullIData(oldp+44,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_exception_r)
                               ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                               : ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_intr_r)
                                   ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                                   : ((1U & (IData)(
                                                    (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                     >> 0x00000026U)))
                                       ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                                       : ((1U & (IData)(
                                                        (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                         >> 0x00000027U)))
                                           ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q
                                           : (vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mepc_q 
                                              & (- (IData)(
                                                           (1U 
                                                            & (IData)(
                                                                      (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                                       >> 0x00000028U))))))))))),32);
    bufp->fullIData(oldp+45,(((0U != (7U & (IData)(
                                                   (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                    >> 0x00000030U))))
                               ? vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_w[1U]
                               : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_w[0U])),32);
    if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
        if ((1U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q))) {
            __Vtemp_1[0U] = 0x616e6469U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 1U)))) {
            __Vtemp_1[0U] = 0x61646469U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 2U)))) {
            __Vtemp_1[0U] = 0x736c7469U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 3U)))) {
            __Vtemp_1[0U] = 0x6c746975U;
            __Vtemp_1[1U] = 0x00000073U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 4U)))) {
            __Vtemp_1[0U] = 0x006f7269U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 5U)))) {
            __Vtemp_1[0U] = 0x786f7269U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 6U)))) {
            __Vtemp_1[0U] = 0x736c6c69U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 7U)))) {
            __Vtemp_1[0U] = 0x73726c69U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 8U)))) {
            __Vtemp_1[0U] = 0x73726169U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 9U)))) {
            __Vtemp_1[0U] = 0x006c7569U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000aU)))) {
            __Vtemp_1[0U] = 0x75697063U;
            __Vtemp_1[1U] = 0x00000061U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000bU)))) {
            __Vtemp_1[0U] = 0x00616464U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000cU)))) {
            __Vtemp_1[0U] = 0x00737562U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000dU)))) {
            __Vtemp_1[0U] = 0x00736c74U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000eU)))) {
            __Vtemp_1[0U] = 0x736c7475U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000fU)))) {
            __Vtemp_1[0U] = 0x00786f72U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000010U)))) {
            __Vtemp_1[0U] = 0x00006f72U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000011U)))) {
            __Vtemp_1[0U] = 0x00616e64U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000012U)))) {
            __Vtemp_1[0U] = 0x00736c6cU;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000013U)))) {
            __Vtemp_1[0U] = 0x0073726cU;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000014U)))) {
            __Vtemp_1[0U] = 0x00737261U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000015U)))) {
            __Vtemp_1[0U] = 0x006a616cU;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000016U)))) {
            __Vtemp_1[0U] = 0x6a616c72U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000017U)))) {
            __Vtemp_1[0U] = 0x00626571U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000018U)))) {
            __Vtemp_1[0U] = 0x00626e65U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000019U)))) {
            __Vtemp_1[0U] = 0x00626c74U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000001aU)))) {
            __Vtemp_1[0U] = 0x00626765U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000001bU)))) {
            __Vtemp_1[0U] = 0x626c7475U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000001cU)))) {
            __Vtemp_1[0U] = 0x62676575U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000001dU)))) {
            __Vtemp_1[0U] = 0x00006c62U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000001eU)))) {
            __Vtemp_1[0U] = 0x00006c68U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000001fU)))) {
            __Vtemp_1[0U] = 0x00006c77U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000020U)))) {
            __Vtemp_1[0U] = 0x006c6275U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000021U)))) {
            __Vtemp_1[0U] = 0x006c6875U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000022U)))) {
            __Vtemp_1[0U] = 0x006c7775U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000023U)))) {
            __Vtemp_1[0U] = 0x00007362U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000024U)))) {
            __Vtemp_1[0U] = 0x00007368U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000025U)))) {
            __Vtemp_1[0U] = 0x00007377U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000026U)))) {
            __Vtemp_1[0U] = 0x63616c6cU;
            __Vtemp_1[1U] = 0x00000065U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000027U)))) {
            __Vtemp_1[0U] = 0x7265616bU;
            __Vtemp_1[1U] = 0x00006562U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000028U)))) {
            __Vtemp_1[0U] = 0x65726574U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000029U)))) {
            __Vtemp_1[0U] = 0x73727277U;
            __Vtemp_1[1U] = 0x00000063U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000002aU)))) {
            __Vtemp_1[0U] = 0x73727273U;
            __Vtemp_1[1U] = 0x00000063U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000002bU)))) {
            __Vtemp_1[0U] = 0x73727263U;
            __Vtemp_1[1U] = 0x00000063U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000002cU)))) {
            __Vtemp_1[0U] = 0x72727769U;
            __Vtemp_1[1U] = 0x00006373U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000002dU)))) {
            __Vtemp_1[0U] = 0x72727369U;
            __Vtemp_1[1U] = 0x00006373U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000002eU)))) {
            __Vtemp_1[0U] = 0x72726369U;
            __Vtemp_1[1U] = 0x00006373U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000002fU)))) {
            __Vtemp_1[0U] = 0x006d756cU;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000030U)))) {
            __Vtemp_1[0U] = 0x6d756c68U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000031U)))) {
            __Vtemp_1[0U] = 0x6c687375U;
            __Vtemp_1[1U] = 0x00006d75U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000032U)))) {
            __Vtemp_1[0U] = 0x756c6875U;
            __Vtemp_1[1U] = 0x0000006dU;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000033U)))) {
            __Vtemp_1[0U] = 0x00646976U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000034U)))) {
            __Vtemp_1[0U] = 0x64697675U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000035U)))) {
            __Vtemp_1[0U] = 0x0072656dU;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000036U)))) {
            __Vtemp_1[0U] = 0x72656d75U;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000037U)))) {
            __Vtemp_1[0U] = 0x41554c54U;
            __Vtemp_1[1U] = 0x00000046U;
            __Vtemp_1[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000038U)))) {
            __Vtemp_1[0U] = 0x41554c54U;
            __Vtemp_1[1U] = 0x47455f46U;
            __Vtemp_1[2U] = 0x00005041U;
        } else {
            __Vtemp_1[0U] = 0x0000002dU;
            __Vtemp_1[1U] = 0U;
            __Vtemp_1[2U] = 0U;
        }
    } else {
        __Vtemp_1[0U] = 0x0000002dU;
        __Vtemp_1[1U] = 0U;
        __Vtemp_1[2U] = 0U;
    }
    bufp->fullWData(oldp+46,(__Vtemp_1),80);
    if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
        if ((0U != (0x0000003fU & ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q) 
                                   | (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                              >> 0x00000029U)))))) {
            __VExpandSel_WordIdx_1 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 0x0000000fU))) 
                                      >> 5U);
            __Vtemp_3[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_1];
            __Vtemp_3[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_1)];
            __Vtemp_3[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_1)];
        } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                         >> 6U))))) {
            __VExpandSel_WordIdx_2 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 0x0000000fU))) 
                                      >> 5U);
            __Vtemp_3[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_2];
            __Vtemp_3[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_2)];
            __Vtemp_3[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_2)];
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 9U)))) {
            __Vtemp_3[0U] = 0x0000002dU;
            __Vtemp_3[1U] = 0U;
            __Vtemp_3[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000aU)))) {
            __Vtemp_3[0U] = 0x00007063U;
            __Vtemp_3[1U] = 0U;
            __Vtemp_3[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000015U)))) {
            __Vtemp_3[0U] = 0x0000002dU;
            __Vtemp_3[1U] = 0U;
            __Vtemp_3[2U] = 0U;
        } else {
            __VExpandSel_WordIdx_3 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 0x0000000fU))) 
                                      >> 5U);
            __Vtemp_3[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_3];
            __Vtemp_3[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_3)];
            __Vtemp_3[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_3)];
        }
    } else {
        __Vtemp_3[0U] = 0x0000002dU;
        __Vtemp_3[1U] = 0U;
        __Vtemp_3[2U] = 0U;
    }
    __Vtemp_4[0U] = __Vtemp_3[0U];
    __Vtemp_4[1U] = __Vtemp_3[1U];
    __Vtemp_4[2U] = (0x0000ffffU & __Vtemp_3[2U]);
    bufp->fullWData(oldp+49,(__Vtemp_4),80);
    if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
        if ((0U != (0x0000003fU & ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q) 
                                   | (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                              >> 0x00000029U)))))) {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                         >> 6U))))) {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 9U)))) {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000aU)))) {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000015U)))) {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000016U)))) {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        } else if ((0U != (0x0000003fU & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x0000001dU))))) {
            __Vtemp_6[0U] = 0x0000002dU;
            __Vtemp_6[1U] = 0U;
            __Vtemp_6[2U] = 0U;
        } else {
            __VExpandSel_WordIdx_4 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 0x00000014U))) 
                                      >> 5U);
            __Vtemp_6[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_4];
            __Vtemp_6[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_4)];
            __Vtemp_6[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_4)];
        }
    } else {
        __Vtemp_6[0U] = 0x0000002dU;
        __Vtemp_6[1U] = 0U;
        __Vtemp_6[2U] = 0U;
    }
    __Vtemp_7[0U] = __Vtemp_6[0U];
    __Vtemp_7[1U] = __Vtemp_6[1U];
    __Vtemp_7[2U] = (0x0000ffffU & __Vtemp_6[2U]);
    bufp->fullWData(oldp+52,(__Vtemp_7),80);
    if (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r) {
        if ((0U != (0x0000003fU & ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q) 
                                   | (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                              >> 0x00000029U)))))) {
            __VExpandSel_WordIdx_5 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 7U))) 
                                      >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_5];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_5)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_5)];
        } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                         >> 6U))))) {
            __VExpandSel_WordIdx_6 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 7U))) 
                                      >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_6];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_6)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_6)];
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 9U)))) {
            __VExpandSel_WordIdx_7 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 7U))) 
                                      >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_7];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_7)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_7)];
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x0000000aU)))) {
            __VExpandSel_WordIdx_8 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 7U))) 
                                      >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_8];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_8)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_8)];
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000015U)))) {
            __VExpandSel_WordIdx_9 = (((IData)(0x00000060U) 
                                       * (0x0000001fU 
                                          & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                             >> 7U))) 
                                      >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_9];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_9)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_9)];
        } else if ((1U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                  >> 0x00000016U)))) {
            __VExpandSel_WordIdx_10 = (((IData)(0x00000060U) 
                                        * (0x0000001fU 
                                           & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 7U))) 
                                       >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_10];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_10)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_10)];
        } else if ((0U != (0x0000003fU & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x0000001dU))))) {
            __VExpandSel_WordIdx_11 = (((IData)(0x00000060U) 
                                        * (0x0000001fU 
                                           & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 7U))) 
                                       >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_11];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_11)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_11)];
        } else if ((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                         >> 0x00000023U))))) {
            __Vtemp_9[0U] = 0x0000002dU;
            __Vtemp_9[1U] = 0U;
            __Vtemp_9[2U] = 0U;
        } else {
            __VExpandSel_WordIdx_12 = (((IData)(0x00000060U) 
                                        * (0x0000001fU 
                                           & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 7U))) 
                                       >> 5U);
            __Vtemp_9[0U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [__VExpandSel_WordIdx_12];
            __Vtemp_9[1U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(1U) + __VExpandSel_WordIdx_12)];
            __Vtemp_9[2U] = Vriscv_tcm_top__ConstPool__CONST_hcd7cc0f2_0
                [((IData)(2U) + __VExpandSel_WordIdx_12)];
        }
    } else {
        __Vtemp_9[0U] = 0x0000002dU;
        __Vtemp_9[1U] = 0U;
        __Vtemp_9[2U] = 0U;
    }
    __Vtemp_10[0U] = __Vtemp_9[0U];
    __Vtemp_10[1U] = __Vtemp_9[1U];
    __Vtemp_10[2U] = (0x0000ffffU & __Vtemp_9[2U]);
    bufp->fullWData(oldp+55,(__Vtemp_10),80);
    bufp->fullIData(oldp+58,((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q 
                              & (- (IData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r))))),32);
    bufp->fullIData(oldp+59,(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_data_rd_w),32);
    bufp->fullCData(oldp+60,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__wb_idx_r),5);
    bufp->fullIData(oldp+61,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__wb_result_r),32);
    bufp->fullCData(oldp+62,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__addr_lsb_r),2);
    bufp->fullBit(oldp+63,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_byte_r));
    bufp->fullBit(oldp+64,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_half_r));
    bufp->fullBit(oldp+65,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_word_r));
    bufp->fullBit(oldp+66,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__load_signed_r));
    bufp->fullIData(oldp+67,(vlSymsp->TOP__riscv_tcm_top.__PVT__icache_pc_w),32);
    bufp->fullBit(oldp+68,(vlSymsp->TOP__riscv_tcm_top.__PVT__icache_rd_w));
    bufp->fullBit(oldp+69,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_accept_w));
    bufp->fullBit(oldp+70,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__muldiv_opcode_valid_w));
    bufp->fullBit(oldp+71,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_opcode_valid_w));
    bufp->fullBit(oldp+72,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__lsu_opcode_valid_w));
    bufp->fullIData(oldp+73,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__branch_pc_w),32);
    bufp->fullBit(oldp+74,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_valid_w));
    bufp->fullBit(oldp+75,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__exec_opcode_valid_w));
    bufp->fullBit(oldp+76,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_branch_w));
    bufp->fullBit(oldp+77,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__branch_request_w));
    bufp->fullIData(oldp+78,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_rb_operand_w),32);
    bufp->fullIData(oldp+79,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_ra_operand_w),32);
    bufp->fullIData(oldp+80,(vlSymsp->TOP__riscv_tcm_top__u_core.__VdfgRegularize_hebeb780c_0_17),32);
    bufp->fullBit(oldp+81,((0U != (0x0050U & (IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__VdfgRegularize_hebeb780c_0_17)))));
    bufp->fullIData(oldp+82,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mepc_r),32);
    bufp->fullIData(oldp+83,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcause_r),32);
    bufp->fullIData(oldp+84,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_sr_r),32);
    bufp->fullIData(oldp+85,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_r),32);
    bufp->fullIData(oldp+86,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mip_r),32);
    bufp->fullIData(oldp+87,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mie_r),32);
    bufp->fullCData(oldp+88,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mpriv_r),2);
    bufp->fullIData(oldp+89,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mscratch_r),32);
    bufp->fullBit(oldp+90,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_intr_r));
    bufp->fullBit(oldp+91,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__take_exception_r));
    bufp->fullIData(oldp+92,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__data_r),32);
    bufp->fullIData(oldp+93,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__result_r),32);
    bufp->fullBit(oldp+94,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__valid_unit_inst_w));
    bufp->fullBit(oldp+95,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__stall_w));
    bufp->fullBit(oldp+96,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_w));
    bufp->fullIData(oldp+97,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_pc_w),32);
    bufp->fullIData(oldp+98,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_r),32);
    bufp->fullBit(oldp+99,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_unaligned_r));
    bufp->fullWData(oldp+100,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_w),65);
    bufp->fullQData(oldp+103,((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_21)) 
                                << 0x00000020U) | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_rb_operand_w)))),33);
    bufp->fullQData(oldp+105,((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__VdfgRegularize_hebeb780c_0_22)) 
                                << 0x00000020U) | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__opcode_ra_operand_w)))),33);
    bufp->fullBit(oldp+107,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_start_w));
    bufp->fullSData(oldp+108,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_addr_w),14);
    bufp->fullIData(oldp+109,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_data_w),32);
    bufp->fullCData(oldp+110,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__muxed_wr_w),4);
    bufp->fullIData(oldp+111,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__alu_input_a_r),32);
    bufp->fullIData(oldp+112,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__alu_input_b_r),32);
    bufp->fullIData(oldp+113,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__less_than_signed__Vstatic__v),32);
    bufp->fullIData(oldp+114,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__greater_than_signed__Vstatic__v),32);
    bufp->fullBit(oldp+115,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__branch_r));
    bufp->fullIData(oldp+116,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__result_r),32);
    bufp->fullSData(oldp+117,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_fill_r),16);
    bufp->fullIData(oldp+118,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_1_r),32);
    bufp->fullIData(oldp+119,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_2_r),32);
    bufp->fullIData(oldp+120,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_4_r),32);
    bufp->fullIData(oldp+121,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_right_8_r),32);
    bufp->fullIData(oldp+122,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_1_r),32);
    bufp->fullIData(oldp+123,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_2_r),32);
    bufp->fullIData(oldp+124,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_4_r),32);
    bufp->fullIData(oldp+125,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__shift_left_8_r),32);
    bufp->fullIData(oldp+126,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__u_alu__DOT__sub_res_w),32);
    bufp->fullBit(oldp+127,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__stall_scoreboard_r));
    bufp->fullBit(oldp+128,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__stall_input_w));
    bufp->fullIData(oldp+129,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__scoreboard_r),32);
    bufp->fullBit(oldp+130,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_valid_r));
    bufp->fullIData(oldp+131,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__current_scoreboard_r),32);
    bufp->fullIData(oldp+132,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__dbg_inst_imm),32);
    bufp->fullSData(oldp+133,((0x00003fffU & (vlSymsp->TOP__riscv_tcm_top.__PVT__icache_pc_w 
                                              >> 2U))),14);
    bufp->fullBit(oldp+134,(vlSymsp->TOP__riscv_tcm_top.axi_i_awvalid_o));
    bufp->fullIData(oldp+135,(vlSymsp->TOP__riscv_tcm_top.axi_i_awaddr_o),32);
    bufp->fullBit(oldp+136,(vlSymsp->TOP__riscv_tcm_top.axi_i_wvalid_o));
    bufp->fullIData(oldp+137,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                              [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][1U]),32);
    bufp->fullCData(oldp+138,((0x0000000fU & vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                               [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q][2U])),4);
    bufp->fullBit(oldp+139,((1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q)))));
    bufp->fullBit(oldp+140,(vlSymsp->TOP__riscv_tcm_top.axi_i_arvalid_o));
    bufp->fullBit(oldp+141,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__bvalid_q));
    bufp->fullCData(oldp+142,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_id_q),4);
    bufp->fullBit(oldp+143,(vlSymsp->TOP__riscv_tcm_top.axi_t_rvalid_o));
    bufp->fullBit(oldp+144,(vlSymsp->TOP__riscv_tcm_top.axi_t_rlast_o));
    bufp->fullSData(oldp+145,(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_resp_tag_w),11);
    bufp->fullBit(oldp+146,(((2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q)) 
                             & (2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q)))));
    bufp->fullSData(oldp+147,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q
                              [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q]),11);
    bufp->fullBit(oldp+148,((1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q)))));
    bufp->fullIData(oldp+149,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__calculate_addr_next__Vstatic__mask),32);
    bufp->fullCData(oldp+150,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_len_q),8);
    bufp->fullIData(oldp+151,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_addr_q),32);
    bufp->fullBit(oldp+152,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_rd_q));
    bufp->fullBit(oldp+153,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_wr_q));
    bufp->fullCData(oldp+154,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_axburst_q),2);
    bufp->fullCData(oldp+155,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__req_axlen_q),8);
    bufp->fullBit(oldp+156,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rvalid_q));
    bufp->fullBit(oldp+157,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rlast_q));
    bufp->fullBit(oldp+158,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rbuf_valid_q));
    bufp->fullIData(oldp+159,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rbuf_data_q),32);
    bufp->fullBit(oldp+160,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_axi_conv__DOT__rbuf_last_q));
    bufp->fullBit(oldp+161,((2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q))));
    bufp->fullBit(oldp+162,((2U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q))));
    bufp->fullBit(oldp+163,((0U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q))));
    bufp->fullWData(oldp+164,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q
                              [vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q]),69);
    bufp->fullBit(oldp+167,((1U & (~ (IData)(vlSymsp->TOP__riscv_tcm_top.__VdfgRegularize_hebeb780c_0_9)))));
    bufp->fullBit(oldp+168,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__awvalid_inhibit_q));
    bufp->fullBit(oldp+169,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__wvalid_inhibit_q));
    Vriscv_tcm_top___024root__trace_full_dtype____0(vlSelf, bufp, 170, vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__ram_q);
    bufp->fullBit(oldp+176,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__rd_ptr_q));
    bufp->fullBit(oldp+177,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__wr_ptr_q));
    bufp->fullCData(oldp+178,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_req__DOT__count_q),2);
    bufp->fullBit(oldp+179,((0U != (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q))));
    Vriscv_tcm_top___024root__trace_full_dtype____1(vlSelf, bufp, 180, vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__ram_q);
    bufp->fullBit(oldp+182,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__rd_ptr_q));
    bufp->fullBit(oldp+183,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__wr_ptr_q));
    bufp->fullCData(oldp+184,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__u_resp__DOT__count_q),2);
    bufp->fullBit(oldp+185,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_accept_q));
    bufp->fullSData(oldp+186,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_tag_q),11);
    bufp->fullBit(oldp+187,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_d_ack_q));
    bufp->fullSData(oldp+188,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_req_tag_q),11);
    bufp->fullBit(oldp+189,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_invalidate_q) 
                             | (IData)(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ifence_q))));
    bufp->fullBit(oldp+190,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_flush_q));
    bufp->fullBit(oldp+191,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_invalidate_q));
    bufp->fullCData(oldp+192,(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_wr_w),4);
    bufp->fullBit(oldp+193,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_rd_q));
    bufp->fullIData(oldp+194,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q),32);
    bufp->fullIData(oldp+195,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q),32);
    bufp->fullBit(oldp+196,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_cacheable_q));
    bufp->fullBit(oldp+197,(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_rd_w));
    bufp->fullCData(oldp+198,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_wr_q),4);
    __Vtemp_11[0U] = (IData)((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                               << 0x00000020U) | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))));
    __Vtemp_11[1U] = (IData)(((((QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_data_wr_q)) 
                                << 0x00000020U) | (QData)((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q))) 
                              >> 0x00000020U));
    __Vtemp_11[2U] = (((IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_rd_w) 
                       << 4U) | (IData)(vlSymsp->TOP__riscv_tcm_top.__PVT__ext_out_wr_w));
    bufp->fullWData(oldp+199,(__Vtemp_11),69);
    bufp->fullBit(oldp+202,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ifence_q));
    bufp->fullBit(oldp+203,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__csr_stall_w));
    bufp->fullQData(oldp+204,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q),58);
    bufp->fullIData(oldp+206,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_pc_w),32);
    bufp->fullCData(oldp+207,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__wb_rd_q),5);
    bufp->fullBit(oldp+208,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_unaligned_st_q));
    bufp->fullBit(oldp+209,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_q));
    bufp->fullCData(oldp+210,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__rd_x_q),5);
    bufp->fullIData(oldp+211,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__pc_q),32);
    bufp->fullBit(oldp+212,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_squash_q));
    bufp->fullBit(oldp+213,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__muldiv_stall_w));
    bufp->fullCData(oldp+214,((0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 0x0000000fU))),5);
    bufp->fullCData(oldp+215,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__writeback_csr_idx_w),5);
    bufp->fullCData(oldp+216,((0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 7U))),5);
    bufp->fullIData(oldp+217,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q),32);
    bufp->fullCData(oldp+218,((0x0000001fU & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                              >> 0x00000014U))),5);
    bufp->fullBit(oldp+219,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_unaligned_ld_q));
    bufp->fullIData(oldp+220,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__wb_result_q),32);
    bufp->fullIData(oldp+221,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__result_q),32);
    bufp->fullIData(oldp+222,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__branch_target_q),32);
    bufp->fullIData(oldp+223,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_value_q),32);
    bufp->fullIData(oldp+224,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mepc_q),32);
    bufp->fullIData(oldp+225,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcause_q),32);
    bufp->fullIData(oldp+226,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_sr_q),32);
    bufp->fullIData(oldp+227,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mtvec_q),32);
    bufp->fullIData(oldp+228,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mip_q),32);
    bufp->fullIData(oldp+229,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mie_q),32);
    bufp->fullCData(oldp+230,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mpriv_q),2);
    bufp->fullIData(oldp+231,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcycle_q),32);
    bufp->fullIData(oldp+232,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mscratch_q),32);
    bufp->fullIData(oldp+233,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__pc_m_q),32);
    bufp->fullIData(oldp+234,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__imm12_r),32);
    bufp->fullCData(oldp+235,((3U & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                     >> 0x0000001cU))),2);
    bufp->fullBit(oldp+236,((3U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                    >> 0x0000001eU))));
    bufp->fullBit(oldp+237,((1U & (IData)(((0ULL != 
                                            (0x0000120000000000ULL 
                                             & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)) 
                                           | (0U != 
                                              (0x000f8000U 
                                               & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q)))))));
    bufp->fullBit(oldp+238,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__set_r));
    bufp->fullBit(oldp+239,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__clr_r));
    bufp->fullIData(oldp+240,(((IData)(1U) + vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mcycle_q)),32);
    bufp->fullBit(oldp+241,((0U != (0x0000003fU & (IData)(
                                                          (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                           >> 0x0000001dU))))));
    bufp->fullBit(oldp+242,((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x00000023U))))));
    bufp->fullIData(oldp+243,((vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mip_q 
                               & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__csr_mie_q)),32);
    bufp->fullIData(oldp+244,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__irq_masked_r),32);
    bufp->fullBit(oldp+245,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_en_q));
    bufp->fullCData(oldp+246,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__writeback_idx_q),5);
    bufp->fullBit(oldp+247,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_csr__DOT__reset_q));
    bufp->fullBit(oldp+248,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__active_q));
    bufp->fullIData(oldp+249,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__fetch_pc_q),32);
    bufp->fullIData(oldp+250,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_pc_q),32);
    bufp->fullBit(oldp+251,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__branch_valid_q));
    bufp->fullBit(oldp+252,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_fetch_q));
    bufp->fullBit(oldp+253,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_invalidate_q));
    bufp->fullQData(oldp+254,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__skid_buffer_q),64);
    bufp->fullBit(oldp+256,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__skid_valid_q));
    bufp->fullIData(oldp+257,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__pc_d_q),32);
    bufp->fullBit(oldp+258,((0U != (7U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x0000001dU))))));
    bufp->fullBit(oldp+259,(((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000029U)) 
                             & (0x03a0U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                            >> 0x00000014U)))));
    bufp->fullBit(oldp+260,(((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000029U)) 
                             & (0x03a1U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                            >> 0x00000014U)))));
    bufp->fullBit(oldp+261,(((IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                      >> 0x00000029U)) 
                             & (0x03a2U == (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                            >> 0x00000014U)))));
    bufp->fullCData(oldp+262,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__rd_q),5);
    bufp->fullIData(oldp+263,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_result_q),32);
    bufp->fullBit(oldp+264,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__mult_busy_q));
    bufp->fullBit(oldp+265,((0U != (0x0000000fU & (IData)(
                                                          (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                           >> 0x0000002fU))))));
    bufp->fullBit(oldp+266,((0U != (0x0000000fU & (IData)(
                                                          (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                           >> 0x00000033U))))));
    bufp->fullBit(oldp+267,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__signed_operation_w));
    bufp->fullBit(oldp+268,((0U != (3U & (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                  >> 0x00000033U))))));
    bufp->fullIData(oldp+269,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__dividend_q),32);
    bufp->fullQData(oldp+270,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__divisor_q),63);
    bufp->fullIData(oldp+272,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__quotient_q),32);
    bufp->fullIData(oldp+273,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__q_mask_q),32);
    bufp->fullBit(oldp+274,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_inst_q));
    bufp->fullBit(oldp+275,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_busy_q));
    bufp->fullBit(oldp+276,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__invert_res_q));
    bufp->fullBit(oldp+277,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_complete_w));
    bufp->fullIData(oldp+278,(((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__div_inst_q)
                                ? ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__invert_res_q)
                                    ? (- vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__quotient_q)
                                    : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__quotient_q)
                                : ((IData)(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__invert_res_q)
                                    ? (- vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__dividend_q)
                                    : vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_muldiv__DOT__dividend_q))),32);
    bufp->fullBit(oldp+279,((0x80000000U <= vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_lsu__DOT__mem_addr_q)));
    bufp->fullIData(oldp+280,((0xfffff000U & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q)),32);
    bufp->fullIData(oldp+281,((((- (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                            >> 0x0000001fU))) 
                                << 0x0000000dU) | (
                                                   (((2U 
                                                      & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                         >> 0x0000001eU)) 
                                                     | (1U 
                                                        & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                           >> 7U))) 
                                                    << 0x0000000bU) 
                                                   | ((0x000007e0U 
                                                       & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                          >> 0x00000014U)) 
                                                      | (0x0000001eU 
                                                         & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                            >> 7U)))))),32);
    bufp->fullIData(oldp+282,((((- (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                            >> 0x0000001fU))) 
                                << 0x00000014U) | (
                                                   (((0x000001feU 
                                                      & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                         >> 0x0000000bU)) 
                                                     | (1U 
                                                        & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                           >> 0x00000014U))) 
                                                    << 0x0000000bU) 
                                                   | (0x000007feU 
                                                      & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                         >> 0x00000014U))))),32);
    bufp->fullIData(oldp+283,((((- (IData)((vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                            >> 0x0000001fU))) 
                                << 0x0000000cU) | (
                                                   (0x00000fe0U 
                                                    & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                       >> 0x00000014U)) 
                                                   | (0x0000001fU 
                                                      & (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__inst_q 
                                                         >> 7U))))),32);
    bufp->fullCData(oldp+284,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__alu_func_r),4);
    bufp->fullBit(oldp+285,((1U & (IData)(((0ULL != 
                                            (0x0000000000649fffULL 
                                             & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)) 
                                           | (0U != 
                                              (3U & 
                                               ((IData)(
                                                        (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                         >> 0x0000000dU)) 
                                                | ((IData)(
                                                           (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                            >> 0x00000010U)) 
                                                   | (IData)(
                                                             (vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q 
                                                              >> 0x00000013U)))))))))));
    bufp->fullBit(oldp+286,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__v_dbg_valid_q));
    bufp->fullIData(oldp+287,(vlSymsp->TOP__riscv_tcm_top__u_core__u_exec.__PVT__v_dbg_pc_q),32);
    bufp->fullBit(oldp+288,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__valid_q));
    bufp->fullIData(oldp+289,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__scoreboard_q),32);
    bufp->fullIData(oldp+290,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__ra_value_w),32);
    bufp->fullIData(oldp+291,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__rb_value_w),32);
    bufp->fullCData(oldp+292,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__wb_csr_rd_w),5);
    bufp->fullBit(oldp+293,((IData)((0ULL != (0x007ffe07e0000000ULL 
                                              & vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_q)))));
    bufp->fullIData(oldp+294,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r1_q),32);
    bufp->fullIData(oldp+295,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r2_q),32);
    bufp->fullIData(oldp+296,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r3_q),32);
    bufp->fullIData(oldp+297,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r4_q),32);
    bufp->fullIData(oldp+298,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r5_q),32);
    bufp->fullIData(oldp+299,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r6_q),32);
    bufp->fullIData(oldp+300,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r7_q),32);
    bufp->fullIData(oldp+301,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r8_q),32);
    bufp->fullIData(oldp+302,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r9_q),32);
    bufp->fullIData(oldp+303,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r10_q),32);
    bufp->fullIData(oldp+304,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r11_q),32);
    bufp->fullIData(oldp+305,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r12_q),32);
    bufp->fullIData(oldp+306,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r13_q),32);
    bufp->fullIData(oldp+307,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r14_q),32);
    bufp->fullIData(oldp+308,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r15_q),32);
    bufp->fullIData(oldp+309,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r16_q),32);
    bufp->fullIData(oldp+310,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r17_q),32);
    bufp->fullIData(oldp+311,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r18_q),32);
    bufp->fullIData(oldp+312,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r19_q),32);
    bufp->fullIData(oldp+313,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r20_q),32);
    bufp->fullIData(oldp+314,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r21_q),32);
    bufp->fullIData(oldp+315,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r22_q),32);
    bufp->fullIData(oldp+316,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r23_q),32);
    bufp->fullIData(oldp+317,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r24_q),32);
    bufp->fullIData(oldp+318,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r25_q),32);
    bufp->fullIData(oldp+319,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r26_q),32);
    bufp->fullIData(oldp+320,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r27_q),32);
    bufp->fullIData(oldp+321,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r28_q),32);
    bufp->fullIData(oldp+322,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r29_q),32);
    bufp->fullIData(oldp+323,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r30_q),32);
    bufp->fullIData(oldp+324,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode__u_regfile.__PVT__reg_r31_q),32);
    bufp->fullBit(oldp+325,(vlSymsp->TOP__riscv_tcm_top.__PVT__dcache_accept_w));
    bufp->fullBit(oldp+326,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__req_push_w));
    bufp->fullBit(oldp+327,(vlSymsp->TOP__riscv_tcm_top.__PVT__u_mem_axi__DOT__res_push_w));
    bufp->fullBit(oldp+328,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__lsu_stall_w));
    bufp->fullBit(oldp+329,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__u_fetch__DOT__icache_busy_w));
    bufp->fullIData(oldp+330,(vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w),32);
    bufp->fullQData(oldp+331,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__opcode_instr_w),58);
    bufp->fullBit(oldp+333,(((0x10500073U == (0xffff8fffU 
                                              & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)) 
                             | ((0x0000000fU == (0x0000707fU 
                                                 & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)) 
                                | ((0x12000073U == 
                                    (0xfe007fffU & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)) 
                                   | (0x0000100fU == 
                                      (0x0000707fU 
                                       & vlSymsp->TOP__riscv_tcm_top__u_core.__PVT__fetch_instr_w)))))));
    bufp->fullBit(oldp+334,(vlSymsp->TOP__riscv_tcm_top__u_core__u_decode.__PVT__invalid_inst_w));
    bufp->fullIData(oldp+335,(vlSymsp->TOP__riscv_tcm_top.axi_t_rdata_o),32);
    bufp->fullIData(oldp+336,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read1_q),32);
    bufp->fullIData(oldp+337,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm__u_ram.__PVT__ram_read0_q),32);
    bufp->fullBit(oldp+338,(vlSymsp->TOP__riscv_tcm_top__u_mem_tcm.__PVT__mem_i_valid_q));
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_dtype____0(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<VlWide<3>/*68:0*/, 2>& __VdtypeVar) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_full_dtype____0\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + offset);
    bufp->fullWData(oldp+0,(__VdtypeVar[1]),69);
    bufp->fullWData(oldp+3,(__VdtypeVar[0]),69);
}

VL_ATTR_COLD void Vriscv_tcm_top___024root__trace_full_dtype____1(Vriscv_tcm_top___024root* vlSelf, VerilatedVcd::Buffer* bufp, uint32_t offset, const VlUnpacked<SData/*10:0*/, 2>& __VdtypeVar) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vriscv_tcm_top___024root__trace_full_dtype____1\n"); );
    Vriscv_tcm_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + offset);
    bufp->fullSData(oldp+0,(__VdtypeVar[1]),11);
    bufp->fullSData(oldp+1,(__VdtypeVar[0]),11);
}

# mem_tcm — Port Reference

`mem_tcm` (`mem_tcm.v`) is the memory controller between the CPU and the 64KB dual-port RAM (`ram_dp_64k`).
It routes CPU accesses to RAM or to peripherals (via `mem_axi`), and shares RAM port 1 with the external
AXI slave (`axi4_ram_bridge`).

"Connects to" is where each port is wired in `riscv_tcm_top.v`.

## Clock and reset

| Port | Dir | Width | Connects to | Meaning |
|---|---|---|---|---|
| `clk_i` | in | 1 | top `clk_i` | Clock for all logic and both RAM ports |
| `rst_i` | in | 1 | top `rst_i` | Async active-high reset of control registers. RAM contents are not cleared. |

## Instruction port: CPU fetch (`mem_i_*`)

| Port | Dir | Width | Connects to | Meaning |
|---|---|---|---|---|
| `mem_i_rd_i` | in | 1 | `riscv_core` | Fetch request |
| `mem_i_pc_i` | in | 32 | `riscv_core` | Fetch address. Bits `[15:2]` go to RAM port 0. |
| `mem_i_flush_i` | in | 1 | `riscv_core` | Cache flush. **Unused.** |
| `mem_i_invalidate_i` | in | 1 | `riscv_core` | Cache invalidate. **Unused.** |
| `mem_i_accept_o` | out | 1 | `riscv_core` | Fetch accepted. Always `1`. |
| `mem_i_valid_o` | out | 1 | `riscv_core` | Instruction ready, one cycle after `mem_i_rd_i` |
| `mem_i_inst_o` | out | 32 | `riscv_core` | Instruction word from RAM port 0 |

## Data port: CPU loads and stores (`mem_d_*`)

| Port | Dir | Width | Connects to | Meaning |
|---|---|---|---|---|
| `mem_d_addr_i` | in | 32 | `riscv_core` | Load/store address. `≥ 0x8000_0000` goes to peripherals, below that goes to RAM. |
| `mem_d_data_wr_i` | in | 32 | `riscv_core` | Store data |
| `mem_d_rd_i` | in | 1 | `riscv_core` | Load request |
| `mem_d_wr_i` | in | 4 | `riscv_core` | Store request with byte enables (`0000` = no store) |
| `mem_d_req_tag_i` | in | 11 | `riscv_core` | Request ID, sent back on the response |
| `mem_d_cacheable_i` | in | 1 | `riscv_core` | Cacheable hint. **Unused.** |
| `mem_d_invalidate_i` | in | 1 | `riscv_core` | Cache invalidate. **Unused.** |
| `mem_d_flush_i` | in | 1 | `riscv_core` | Cache flush. **Unused.** |
| `mem_d_accept_o` | out | 1 | `riscv_core` | Request accepted. For RAM: `0` while the external AXI port holds port 1. For peripherals: passes through `mem_out_accept_i`. |
| `mem_d_ack_o` | out | 1 | `riscv_core` | Response ready (RAM ack OR peripheral ack) |
| `mem_d_data_rd_o` | out | 32 | `riscv_core` | Load data, from RAM port 1 or from the peripheral response |
| `mem_d_resp_tag_o` | out | 11 | `riscv_core` | Tag of the request this response belongs to |

## External access: AXI slave into RAM (`ext_*`)

| Port | Dir | Width | Connects to | Meaning |
|---|---|---|---|---|
| `ext_rd_i` | in | 1 | `axi4_ram_bridge` | External read request |
| `ext_wr_i` | in | 4 | `axi4_ram_bridge` | External write with byte enables (from AXI `wstrb`) |
| `ext_addr_i` | in | 32 | `axi4_ram_bridge` | Address. Only bits `[15:2]` are used, so it wraps every 64KB. |
| `ext_write_data_i` | in | 32 | `axi4_ram_bridge` | Write data |
| `ext_accept_o` | out | 1 | `axi4_ram_bridge` | Port 1 is granted to the external side this cycle. It goes high the cycle *after* a request and stays high while requests continue. |
| `ext_read_data_o` | out | 32 | `axi4_ram_bridge` | RAM port 1 read data, valid one cycle after the access |

## Peripheral path: to `mem_axi` (`mem_out_*`)

| Port | Dir | Width | Connects to | Meaning |
|---|---|---|---|---|
| `mem_out_addr_o` | out | 32 | `mem_axi` | Copy of `mem_d_addr_i` |
| `mem_out_data_wr_o` | out | 32 | `mem_axi` | Copy of `mem_d_data_wr_i` |
| `mem_out_rd_o` | out | 1 | `mem_axi` | `mem_d_rd_i`, only when address `≥ 0x8000_0000` |
| `mem_out_wr_o` | out | 4 | `mem_axi` | `mem_d_wr_i`, only when address `≥ 0x8000_0000` |
| `mem_out_req_tag_o` | out | 11 | `mem_axi` | Copy of `mem_d_req_tag_i` |
| `mem_out_cacheable_o` | out | 1 | `mem_axi` | Tied to `0` |
| `mem_out_invalidate_o` | out | 1 | `mem_axi` | Tied to `0` |
| `mem_out_flush_o` | out | 1 | `mem_axi` | Tied to `0` |
| `mem_out_resp_accept_o` | out | 1 | `mem_axi` | Allows a peripheral response. Low while a RAM response is being returned, so the two never collide on `mem_d_ack_o`. |
| `mem_out_accept_i` | in | 1 | `mem_axi` | Peripheral request accepted |
| `mem_out_ack_i` | in | 1 | `mem_axi` | Peripheral response ready |
| `mem_out_data_rd_i` | in | 32 | `mem_axi` | Peripheral read data |
| `mem_out_resp_tag_i` | in | 11 | `mem_axi` | Tag of the peripheral response |

## Notes

- **Unused ports:** 5 of the 38 ports (all `flush`, `invalidate` and `cacheable` inputs) do nothing. They exist
  only so the port list matches the core's cache-capable interface.
- **Pass-through:** most `mem_out_*` outputs are wires straight from the `mem_d_*` inputs. Only `rd` and `wr`
  are gated by the address check (`mem_tcm.v:183-184`).
- **One response path:** RAM and peripheral responses share `mem_d_ack_o`, `mem_d_data_rd_o` and
  `mem_d_resp_tag_o`. RAM wins when both arrive together, and `mem_out_resp_accept_o` makes the peripheral
  side wait.
